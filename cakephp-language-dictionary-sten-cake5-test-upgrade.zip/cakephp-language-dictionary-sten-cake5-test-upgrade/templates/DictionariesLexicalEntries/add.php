<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $dictionariesLexicalEntry
 * @var \Cake\Collection\CollectionInterface|string[] $dictionaries
 * @var \Cake\Collection\CollectionInterface|string[] $lexicalEntries
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('List Dictionaries Lexical Entries'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="dictionariesLexicalEntries form content">
            <?= $this->Form->create($dictionariesLexicalEntry) ?>
            <fieldset>
                <legend><?= __('Add Dictionaries Lexical Entry') ?></legend>
                <?php
                    echo $this->Form->control('dictionary_id', ['options' => $dictionaries]);
                    echo $this->Form->control('lexical_entry_id', ['options' => $lexicalEntries]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
