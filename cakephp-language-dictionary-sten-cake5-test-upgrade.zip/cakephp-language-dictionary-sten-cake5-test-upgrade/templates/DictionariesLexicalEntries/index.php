<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\Cake\Datasource\EntityInterface> $dictionariesLexicalEntries
 */
?>
<div class="dictionariesLexicalEntries index content">
    <?= $this->Html->link(__('New Dictionaries Lexical Entry'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Dictionaries Lexical Entries') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('dictionary_id') ?></th>
                    <th><?= $this->Paginator->sort('lexical_entry_id') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($dictionariesLexicalEntries as $dictionariesLexicalEntry): ?>
                <tr>
                    <td><?= $this->Number->format($dictionariesLexicalEntry->id) ?></td>
                    <td><?= $dictionariesLexicalEntry->hasValue('dictionary') ? $this->Html->link($dictionariesLexicalEntry->dictionary->name, ['controller' => 'Dictionaries', 'action' => 'view', $dictionariesLexicalEntry->dictionary->id]) : '' ?></td>
                    <td><?= $dictionariesLexicalEntry->hasValue('lexical_entry') ? $this->Html->link($dictionariesLexicalEntry->lexical_entry->name, ['controller' => 'LexicalEntries', 'action' => 'view', $dictionariesLexicalEntry->lexical_entry->id]) : '' ?></td>
                    <td><?= h($dictionariesLexicalEntry->created) ?></td>
                    <td><?= h($dictionariesLexicalEntry->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $dictionariesLexicalEntry->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $dictionariesLexicalEntry->id]) ?>
                        <?= $this->Form->postLink(
                            __('Delete'),
                            ['action' => 'delete', $dictionariesLexicalEntry->id],
                            [
                                'method' => 'delete',
                                'confirm' => __('Are you sure you want to delete # {0}?', $dictionariesLexicalEntry->id),
                            ]
                        ) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>