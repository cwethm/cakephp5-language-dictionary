<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $dictionariesLexicalEntry
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Dictionaries Lexical Entry'), ['action' => 'edit', $dictionariesLexicalEntry->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Dictionaries Lexical Entry'), ['action' => 'delete', $dictionariesLexicalEntry->id], ['confirm' => __('Are you sure you want to delete # {0}?', $dictionariesLexicalEntry->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Dictionaries Lexical Entries'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Dictionaries Lexical Entry'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="dictionariesLexicalEntries view content">
            <h3><?= h($dictionariesLexicalEntry->id) ?></h3>
            <table>
                <tr>
                    <th><?= __('Dictionary') ?></th>
                    <td><?= $dictionariesLexicalEntry->hasValue('dictionary') ? $this->Html->link($dictionariesLexicalEntry->dictionary->name, ['controller' => 'Dictionaries', 'action' => 'view', $dictionariesLexicalEntry->dictionary->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Lexical Entry') ?></th>
                    <td><?= $dictionariesLexicalEntry->hasValue('lexical_entry') ? $this->Html->link($dictionariesLexicalEntry->lexical_entry->name, ['controller' => 'LexicalEntries', 'action' => 'view', $dictionariesLexicalEntry->lexical_entry->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($dictionariesLexicalEntry->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($dictionariesLexicalEntry->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($dictionariesLexicalEntry->modified) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>