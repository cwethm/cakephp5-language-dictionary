<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $dictionariesLexicalEntry
 * @var string[]|\Cake\Collection\CollectionInterface $dictionaries
 * @var string[]|\Cake\Collection\CollectionInterface $lexicalEntries
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', $dictionariesLexicalEntry->id],
                ['confirm' => __('Are you sure you want to delete # {0}?', $dictionariesLexicalEntry->id), 'class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List Dictionaries Lexical Entries'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="dictionariesLexicalEntries form content">
            <?= $this->Form->create($dictionariesLexicalEntry) ?>
            <fieldset>
                <legend><?= __('Edit Dictionaries Lexical Entry') ?></legend>
                <?php
                    echo $this->Form->control('dictionary_id', ['options' => $dictionaries]);
                    echo $this->Form->control('lexical_entry_id', ['options' => $lexicalEntries]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
