<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $lemonValueSet
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Lemon Value Set'), ['action' => 'edit', $lemonValueSet->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Lemon Value Set'), ['action' => 'delete', $lemonValueSet->id], ['confirm' => __('Are you sure you want to delete # {0}?', $lemonValueSet->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Lemon Value Sets'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Lemon Value Set'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="lemonValueSets view content">
            <h3><?= h($lemonValueSet->name) ?></h3>
            <table>
                <tr>
                    <th><?= __('Lemon Attribute') ?></th>
                    <td><?= $lemonValueSet->hasValue('lemon_attribute') ? $this->Html->link($lemonValueSet->lemon_attribute->name, ['controller' => 'LemonAttributes', 'action' => 'view', $lemonValueSet->lemon_attribute->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Set Name') ?></th>
                    <td><?= h($lemonValueSet->set_name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Name') ?></th>
                    <td><?= h($lemonValueSet->name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Label') ?></th>
                    <td><?= h($lemonValueSet->label) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($lemonValueSet->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($lemonValueSet->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($lemonValueSet->modified) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>