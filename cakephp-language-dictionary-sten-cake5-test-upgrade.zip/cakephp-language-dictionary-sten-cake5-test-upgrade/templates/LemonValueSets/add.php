<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $lemonValueSet
 * @var \Cake\Collection\CollectionInterface|string[] $lemonAttributes
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('List Lemon Value Sets'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="lemonValueSets form content">
            <?= $this->Form->create($lemonValueSet) ?>
            <fieldset>
                <legend><?= __('Add Lemon Value Set') ?></legend>
                <?php
                    echo $this->Form->control('lemon_attribute_id', ['options' => $lemonAttributes]);
                    echo $this->Form->control('set_name');
                    echo $this->Form->control('name');
                    echo $this->Form->control('label');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
