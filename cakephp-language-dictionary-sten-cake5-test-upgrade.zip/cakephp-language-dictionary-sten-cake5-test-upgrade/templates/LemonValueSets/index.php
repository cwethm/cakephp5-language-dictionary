<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\Cake\Datasource\EntityInterface> $lemonValueSets
 */
?>
<div class="lemonValueSets index content">
    <?= $this->Html->link(__('New Lemon Value Set'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Lemon Value Sets') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('lemon_attribute_id') ?></th>
                    <th><?= $this->Paginator->sort('set_name') ?></th>
                    <th><?= $this->Paginator->sort('name') ?></th>
                    <th><?= $this->Paginator->sort('label') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($lemonValueSets as $lemonValueSet): ?>
                <tr>
                    <td><?= $this->Number->format($lemonValueSet->id) ?></td>
                    <td><?= $lemonValueSet->hasValue('lemon_attribute') ? $this->Html->link($lemonValueSet->lemon_attribute->name, ['controller' => 'LemonAttributes', 'action' => 'view', $lemonValueSet->lemon_attribute->id]) : '' ?></td>
                    <td><?= h($lemonValueSet->set_name) ?></td>
                    <td><?= h($lemonValueSet->name) ?></td>
                    <td><?= h($lemonValueSet->label) ?></td>
                    <td><?= h($lemonValueSet->created) ?></td>
                    <td><?= h($lemonValueSet->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $lemonValueSet->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $lemonValueSet->id]) ?>
                        <?= $this->Form->postLink(
                            __('Delete'),
                            ['action' => 'delete', $lemonValueSet->id],
                            [
                                'method' => 'delete',
                                'confirm' => __('Are you sure you want to delete # {0}?', $lemonValueSet->id),
                            ]
                        ) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>