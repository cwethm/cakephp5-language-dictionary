<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $form
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Form'), ['action' => 'edit', $form->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Form'), ['action' => 'delete', $form->id], ['confirm' => __('Are you sure you want to delete # {0}?', $form->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Forms'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Form'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="forms view content">
            <h3><?= h($form->form_type) ?></h3>
            <table>
                <tr>
                    <th><?= __('Lexical Entry') ?></th>
                    <td><?= $form->hasValue('lexical_entry') ? $this->Html->link($form->lexical_entry->name, ['controller' => 'LexicalEntries', 'action' => 'view', $form->lexical_entry->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Language') ?></th>
                    <td><?= $form->hasValue('language') ? $this->Html->link($form->language->name, ['controller' => 'Languages', 'action' => 'view', $form->language->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Form Type') ?></th>
                    <td><?= h($form->form_type) ?></td>
                </tr>
                <tr>
                    <th><?= __('Written Representation') ?></th>
                    <td><?= h($form->written_representation) ?></td>
                </tr>
                <tr>
                    <th><?= __('Slug') ?></th>
                    <td><?= h($form->slug) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($form->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($form->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($form->modified) ?></td>
                </tr>
            </table>
            <div class="related">
                <h4><?= __('Related Linguistic Descriptions') ?></h4>
                <?php if (!empty($form->linguistic_descriptions)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Lexical Entry Id') ?></th>
                            <th><?= __('Sense Id') ?></th>
                            <th><?= __('Form Id') ?></th>
                            <th><?= __('Lemon Attribute Id') ?></th>
                            <th><?= __('Value') ?></th>
                            <th><?= __('Created') ?></th>
                            <th><?= __('Modified') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($form->linguistic_descriptions as $linguisticDescription) : ?>
                        <tr>
                            <td><?= h($linguisticDescription->id) ?></td>
                            <td><?= h($linguisticDescription->lexical_entry_id) ?></td>
                            <td><?= h($linguisticDescription->sense_id) ?></td>
                            <td><?= h($linguisticDescription->form_id) ?></td>
                            <td><?= h($linguisticDescription->lemon_attribute_id) ?></td>
                            <td><?= h($linguisticDescription->value) ?></td>
                            <td><?= h($linguisticDescription->created) ?></td>
                            <td><?= h($linguisticDescription->modified) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'LinguisticDescriptions', 'action' => 'view', $linguisticDescription->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'LinguisticDescriptions', 'action' => 'edit', $linguisticDescription->id]) ?>
                                <?= $this->Form->postLink(
                                    __('Delete'),
                                    ['controller' => 'LinguisticDescriptions', 'action' => 'delete', $linguisticDescription->id],
                                    [
                                        'method' => 'delete',
                                        'confirm' => __('Are you sure you want to delete # {0}?', $linguisticDescription->id),
                                    ]
                                ) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>