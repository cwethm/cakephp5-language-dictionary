<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\Cake\Datasource\EntityInterface> $forms
 */
?>
<div class="forms index content">
    <?= $this->Html->link(__('New Form'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Forms') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('lexical_entry_id') ?></th>
                    <th><?= $this->Paginator->sort('language_id') ?></th>
                    <th><?= $this->Paginator->sort('form_type') ?></th>
                    <th><?= $this->Paginator->sort('written_representation') ?></th>
                    <th><?= $this->Paginator->sort('slug') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($forms as $form): ?>
                <tr>
                    <td><?= $this->Number->format($form->id) ?></td>
                    <td><?= $form->hasValue('lexical_entry') ? $this->Html->link($form->lexical_entry->name, ['controller' => 'LexicalEntries', 'action' => 'view', $form->lexical_entry->id]) : '' ?></td>
                    <td><?= $form->hasValue('language') ? $this->Html->link($form->language->name, ['controller' => 'Languages', 'action' => 'view', $form->language->id]) : '' ?></td>
                    <td><?= h($form->form_type) ?></td>
                    <td><?= h($form->written_representation) ?></td>
                    <td><?= h($form->slug) ?></td>
                    <td><?= h($form->created) ?></td>
                    <td><?= h($form->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $form->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $form->id]) ?>
                        <?= $this->Form->postLink(
                            __('Delete'),
                            ['action' => 'delete', $form->id],
                            [
                                'method' => 'delete',
                                'confirm' => __('Are you sure you want to delete # {0}?', $form->id),
                            ]
                        ) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>