<?php 
    $this->loadHelper('LemonTools.DataTable');
    $this->loadHelper('LemonTools.DynamicForm'); 
?>
<?= $this->Form->create($form, [
    'id' => 'modalForm',
    'url' => ['action' => 'add'],
    'class' => 'needs-validation',
    'data-ajax-submit' => 'true'
]) ?>
<?php 
if (!empty($rdf_class)) {
    $presentationConfig['rdf_class'] ??= $rdf_class;
}
echo $this->DynamicForm->autoFields($presentationConfig, $form);
?>
<button type="submit" class="btn btn-success">Save</button>
<?= $this->Form->end() ?>
  