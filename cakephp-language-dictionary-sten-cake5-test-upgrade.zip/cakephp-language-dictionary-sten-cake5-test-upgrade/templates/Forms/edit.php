<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $form
 * @var string[]|\Cake\Collection\CollectionInterface $lexicalEntries
 * @var string[]|\Cake\Collection\CollectionInterface $languages
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', $form->id],
                ['confirm' => __('Are you sure you want to delete # {0}?', $form->id), 'class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List Forms'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="forms form content">
            <?= $this->Form->create($form) ?>
            <fieldset>
                <legend><?= __('Edit Form') ?></legend>
                <?php
                    echo $this->Form->control('lexical_entry_id', ['options' => $lexicalEntries]);
                    echo $this->Form->control('language_id', ['options' => $languages, 'empty' => true]);
                    echo $this->Form->control('form_type');
                    echo $this->Form->control('written_representation');
                    echo $this->Form->control('slug');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
