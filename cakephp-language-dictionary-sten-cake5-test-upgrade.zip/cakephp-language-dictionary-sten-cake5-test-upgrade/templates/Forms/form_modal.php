<?php
// templates/Forms/form_modal.php
echo $this->Form->create($form, [
    'url' => ['action' => 'submitAddToEntry', $lexicalEntryId],
    'id' => 'modalForm'
]);
echo $this->Form->control('written_representation');
echo $this->Form->button(__('Save'), ['class' => 'btn btn-primary']);
echo $this->Form->end();
