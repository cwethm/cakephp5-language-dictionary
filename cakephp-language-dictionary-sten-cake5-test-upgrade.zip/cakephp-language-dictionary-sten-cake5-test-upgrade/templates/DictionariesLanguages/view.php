<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $dictionariesLanguage
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Dictionaries Language'), ['action' => 'edit', $dictionariesLanguage->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Dictionaries Language'), ['action' => 'delete', $dictionariesLanguage->id], ['confirm' => __('Are you sure you want to delete # {0}?', $dictionariesLanguage->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Dictionaries Languages'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Dictionaries Language'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="dictionariesLanguages view content">
            <h3><?= h($dictionariesLanguage->id) ?></h3>
            <table>
                <tr>
                    <th><?= __('Dictionary') ?></th>
                    <td><?= $dictionariesLanguage->hasValue('dictionary') ? $this->Html->link($dictionariesLanguage->dictionary->name, ['controller' => 'Dictionaries', 'action' => 'view', $dictionariesLanguage->dictionary->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Language') ?></th>
                    <td><?= $dictionariesLanguage->hasValue('language') ? $this->Html->link($dictionariesLanguage->language->name, ['controller' => 'Languages', 'action' => 'view', $dictionariesLanguage->language->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($dictionariesLanguage->id) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>