<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $dictionariesLanguage
 * @var \Cake\Collection\CollectionInterface|string[] $dictionaries
 * @var \Cake\Collection\CollectionInterface|string[] $languages
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('List Dictionaries Languages'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="dictionariesLanguages form content">
            <?= $this->Form->create($dictionariesLanguage) ?>
            <fieldset>
                <legend><?= __('Add Dictionaries Language') ?></legend>
                <?php
                    echo $this->Form->control('dictionary_id', ['options' => $dictionaries]);
                    echo $this->Form->control('language_id', ['options' => $languages]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
