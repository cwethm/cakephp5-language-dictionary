<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\Cake\Datasource\EntityInterface> $dictionariesLanguages
 */
?>
<div class="dictionariesLanguages index content">
    <?= $this->Html->link(__('New Dictionaries Language'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Dictionaries Languages') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('dictionary_id') ?></th>
                    <th><?= $this->Paginator->sort('language_id') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($dictionariesLanguages as $dictionariesLanguage): ?>
                <tr>
                    <td><?= $this->Number->format($dictionariesLanguage->id) ?></td>
                    <td><?= $dictionariesLanguage->hasValue('dictionary') ? $this->Html->link($dictionariesLanguage->dictionary->name, ['controller' => 'Dictionaries', 'action' => 'view', $dictionariesLanguage->dictionary->id]) : '' ?></td>
                    <td><?= $dictionariesLanguage->hasValue('language') ? $this->Html->link($dictionariesLanguage->language->name, ['controller' => 'Languages', 'action' => 'view', $dictionariesLanguage->language->id]) : '' ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $dictionariesLanguage->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $dictionariesLanguage->id]) ?>
                        <?= $this->Form->postLink(
                            __('Delete'),
                            ['action' => 'delete', $dictionariesLanguage->id],
                            [
                                'method' => 'delete',
                                'confirm' => __('Are you sure you want to delete # {0}?', $dictionariesLanguage->id),
                            ]
                        ) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>