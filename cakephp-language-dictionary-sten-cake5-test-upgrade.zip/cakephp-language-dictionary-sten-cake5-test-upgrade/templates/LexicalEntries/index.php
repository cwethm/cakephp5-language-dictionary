<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface[]|\Cake\Collection\CollectionInterface $lexicalEntries
 */ 

// $presentationConfig['columns']['cover']['formatter'] = [ $this->DataTable, 'coverPreview' ];

?>

<?php
  echo $this->element('LanguageDictionary.advanced_search_compact_secw');
?>
<div class="pagination-container">
  <?=
    $this->element('data-table-pagination')
  ?>
</div>
<?= 
$this->DataTable->create($lexicalEntries, $presentationConfig, $searchOptions)
?>
<div class="pagination-container">
  <?=
    $this->element('data-table-pagination')
  ?>
</div>