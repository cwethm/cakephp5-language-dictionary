<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $lexicalEntry
 */
?> 
<div class="lexicalEntries view large-9 medium-8 columns content">
    <h3><?= h($lexicalEntry->name) ?></h3>
    <div class="table-responsive">
        <table class="table table-striped">
            <tr>
                <th scope="row"><?= __('Slug') ?></th>
                <td><?= h($lexicalEntry->slug) ?></td>
            </tr>
            <tr>
                <th scope="row"><?= __('Entry Type') ?></th>
                <td><?= h($lexicalEntry->entry_type) ?></td>
            </tr>
            <tr>
                <th scope="row"><?= __('Name') ?></th>
                <td><?= h($lexicalEntry->name) ?></td>
            </tr>
            <tr>
                <th scope="row"><?= __('Translated') ?></th>
                <td><?= h($lexicalEntry->translated) ?></td>
            </tr>
            <tr>
                <th scope="row"><?= __('Part Of Speech') ?></th>
                <td><?= h($lexicalEntry->part_of_speech) ?></td>
            </tr>
            <tr>
                <th scope="row"><?= __('Language') ?></th>
                <td><?= $lexicalEntry->hasValue('language') ? $this->Html->link($lexicalEntry->language->name, ['controller' => 'Languages', 'action' => 'view', $lexicalEntry->language->id]) : '' ?></td>
            </tr>
            <tr>
                <th scope="row"><?= __('User') ?></th>
                <td><?= $lexicalEntry->hasValue('user') ? $this->Html->link($lexicalEntry->user->id, ['controller' => 'Users', 'action' => 'view', $lexicalEntry->user->id]) : '' ?></td>
            </tr>
            <tr>
                <th scope="row"><?= __('Id') ?></th>
                <td><?= $this->Number->format($lexicalEntry->id) ?></td>
            </tr>
            <tr>
                <th scope="row"><?= __('Coverimg') ?></th>
                <td><?= $lexicalEntry->coverimg === null ? '' : $this->Number->format($lexicalEntry->coverimg) ?></td>
            </tr>
            <tr>
                <th scope="row"><?= __('Coversound') ?></th>
                <td><?= $lexicalEntry->coversound === null ? '' : $this->Number->format($lexicalEntry->coversound) ?></td>
            </tr>
            <tr>
                <th scope="row"><?= __('Tag Count') ?></th>
                <td><?= $lexicalEntry->tag_count === null ? '' : $this->Number->format($lexicalEntry->tag_count) ?></td>
            </tr>
            <tr>
                <th scope="row"><?= __('Created By') ?></th>
                <td><?= $lexicalEntry->created_by === null ? '' : $this->Number->format($lexicalEntry->created_by) ?></td>
            </tr>
            <tr>
                <th scope="row"><?= __('Modified By') ?></th>
                <td><?= $lexicalEntry->modified_by === null ? '' : $this->Number->format($lexicalEntry->modified_by) ?></td>
            </tr>
            <tr>
                <th scope="row"><?= __('Trashed') ?></th>
                <td><?= h($lexicalEntry->trashed) ?></td>
            </tr>
            <tr>
                <th scope="row"><?= __('Created') ?></th>
                <td><?= h($lexicalEntry->created) ?></td>
            </tr>
            <tr>
                <th scope="row"><?= __('Modified') ?></th>
                <td><?= h($lexicalEntry->modified) ?></td>
            </tr>
        </table>
    </div>
</div>
