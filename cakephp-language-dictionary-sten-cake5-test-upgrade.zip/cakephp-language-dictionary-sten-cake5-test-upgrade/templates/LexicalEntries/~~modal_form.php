<?php
echo $this->Form->create($entity, ['id' => 'modalForm']);
echo $this->Form->control('name');
echo $this->Form->control('translated');
echo $this->Form->button(__('Save'), ['class' => 'btn btn-success']);
echo $this->Form->end();
?>
