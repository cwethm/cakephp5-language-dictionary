<?php

$this->loadHelper('LemonTools.DynamicForm');
$this->loadHelper('LemonTools.ValueSet');
$this->loadHelper('LemonTools.ValidationFeedback');
$this->loadHelper('LemonTools.FieldFactory');

/** @var \LanguageDictionary\Model\Entity\LexicalEntry $lexicalEntry */
?>

<div class="container my-4">
    <h1 class="mb-4">Add New Lexical Entry</h1>

    <?= $this->Form->create($lexicalEntry) ?>

    <div class="row">
        <div class="col-md-6">
            <?= $this->DynamicForm->control($lexicalEntry, 'name', [
                'label' => 'Lemma (Canonical Name)'
            ]) ?>
            <?= $this->DynamicForm->control($lexicalEntry, 'translated', [
                'label' => 'Translation (altLabel)'
            ]) ?>
            <?= $this->DynamicForm->control($lexicalEntry, 'part_of_speech', [
                'options' => $this->ValueSet->getOptions('lexical_category'),
                'label' => 'Part of Speech'
            ]) ?>
            <?= $this->DynamicForm->control($lexicalEntry, 'language_id', [
                'options' => $languages,
                'label' => 'Language'
            ]) ?>
            <?= $this->DynamicForm->control($lexicalEntry, 'entry_type', [
                'options' => [
                    'word' => 'Word',
                    'phrase' => 'Phrase',
                    'proverb' => 'Proverb',
                    'idiom' => 'Idiom'
                    // Expand as you need
                ],
                'label' => 'Entry Type'
            ]) ?>
        </div>

        <div class="col-md-6">
            <?= $this->DynamicForm->control($lexicalEntry, 'coverimg', [
                'label' => 'Cover Image (Asset ID)',
                'type' => 'number'
            ]) ?>
            <?= $this->DynamicForm->control($lexicalEntry, 'coversound', [
                'label' => 'Cover Sound (Asset ID)',
                'type' => 'number'
            ]) ?>
        </div>
    </div>

    <h3 class="mt-5">Canonical Forms and Other Forms</h3>
    <?= $this->FieldFactory->addAnotherButton('forms', [
        'form_type' => [
            'label' => 'Form Type',
            'options' => $this->ValueSet->getOptions('form_type')
        ],
        'written_representation' => [
            'label' => 'Written Representation'
        ],
        'language_id' => [
            'label' => 'Language',
            'options' => $languages
        ],
    ], [
        'buttonLabel' => '➕ Add Form'
    ]) ?>

    <h3 class="mt-5">Senses</h3>
    <?= $this->FieldFactory->addAnotherButton('senses', [
        'definition' => [
            'label' => 'Definition'
        ],
        'reference' => [
            'label' => 'Reference (external or internal)'
        ],
    ], [
        'buttonLabel' => '➕ Add Sense'
    ]) ?>

    <div class="mt-4">
        <?= $this->Form->button(__('Save Entry'), ['class' => 'btn btn-primary']) ?>
    </div>

    <?= $this->Form->end() ?>

    <?= $this->ValidationFeedback->attachClientValidation() ?>
</div>
