<?php
$this->loadHelper('LemonTools.DynamicForm'); 
$this->loadHelper('LemonTools.ValueSet');
$this->loadHelper('LemonTools.ValidationFeedback');
$this->loadHelper('LemonTools.FieldFactory');
$this->loadHelper('LemonTools.CoverAssetSelector');
$this->loadHelper('LemonTools.MediaAttachment');
$this->loadHelper('LemonTools.CategoryTree');

$this->loadHelper('DigitalAssetManager.AssetGalleryView');
$this->loadHelper('LemonTools.ModalLauncher');
$this->loadHelper('LemonTools.DataAccordionList');


/** @var \LanguageDictionary\Model\Entity\LexicalEntry $lexicalEntry */
/** @var array $availableCoverImages */
/** @var array $availableCoverSounds */
?>
<?php
$model = $lexicalEntry->getSource(); // Usually 'LexicalEntries'
$id = $lexicalEntry->id;
?>
<!-- templates/LexicalEntries/edit.php -->
 
<?php
$request = $this->getRequest(); // or $this->request in older Cake versions
$backUrl = [
    'controller' => 'LexicalEntries',
    'action' => 'index',
    '?' => $searchOptions // safely get query params
];

echo $this->Html->link(
    '<i class="fas fa-arrow-left"></i> Back to Dictionary',
    $backUrl,
    ['escape' => false, 'class' => 'btn btn-secondary mb-3']
);
?>

<ul class="nav nav-tabs" id="lexicalEntryTabs" role="tablist">
  <li class="nav-item">
    <button class="nav-link active" id="tab-basic-tab" data-bs-toggle="tab" data-bs-target="#tab-basic" role="tab">Basic Info</button>
  </li>
  <li class="nav-item">
    <button class="nav-link" id="tab-media-tab" data-bs-toggle="tab" data-bs-target="#tab-media" role="tab">Media & Usage</button>
  </li>
  <li class="nav-item">
    <button class="nav-link" id="tab-history-tab" data-bs-toggle="tab" data-bs-target="#tab-history" role="tab">History</button>
  </li>
  <li class="nav-item">
    <button class="nav-link" id="tab-comments-tab" data-bs-toggle="tab" data-bs-target="#tab-comments" role="tab">Comments</button>
  </li>
</ul>

<div class="tab-content mt-3">
  <div class="tab-pane fade show active" id="tab-basic" role="tabpanel">
    <?= $this->element('LexicalEntries/edit_basic', compact('lexicalEntry')) ?>
  </div>
  <div class="tab-pane fade" id="tab-media" role="tabpanel">
    <?= $this->element('LexicalEntries/edit_usage_media', compact('lexicalEntry', 'mediaAssets', 'senses')) ?>
  </div>
  <div class="tab-pane fade" id="tab-history" role="tabpanel">
    <?= $this->element('LexicalEntries/edit_history', compact('lexicalEntry')) ?>
  </div>
  <div class="tab-pane fade" id="tab-comments" role="tabpanel">
    <?= $this->element('LexicalEntries/edit_comments', compact('lexicalEntry')) ?>
  </div>
</div>
