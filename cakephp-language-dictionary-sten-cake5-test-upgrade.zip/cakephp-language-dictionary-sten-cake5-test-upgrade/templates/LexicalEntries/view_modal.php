<?php
// File: templates/LexicalEntries/view_modal.php
/**
 * @var \LanguageDictionary\Model\Entity\LexicalEntry $entry
 * @var \LanguageDictionary\Model\Entity\Sense|null $sense
 */
?>
<div class="modal-header bg-dark text-white">
    <div>
        <h3 class="modal-title mb-1">
            <?= h($entry->canonical_form->written_representation ?? 'Untitled') ?>
            <span class="badge bg-light text-dark ms-2"><?= h($entry->part_of_speech ?? 'N/A') ?></span>
        </h3>
        <?php if (!empty($entry->translated)): ?>
            <p class="mb-0 text-white-50"><?= h($entry->translated) ?></p>
        <?php endif; ?>
    </div>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>

<div class="modal-body">
    <div class="row mb-3">
        <div class="col-md-6">
            <?php if (!empty($sense->definition)): ?>
                <h5><?= h($sense->definition) ?></h5>
            <?php else: ?>
                <div class="alert alert-warning">No definition available for this entry yet.</div>
            <?php endif; ?>

            <?php if (!empty($sense->cover_sound_asset?->media_asset?->path)): ?>
                <audio controls class="mt-3 w-100">
                    <source src="/files/<?= h($sense->cover_sound_asset->media_asset->path) ?>" type="audio/mpeg">
                    Your browser does not support the audio element.
                </audio>
            <?php endif; ?>
        </div>
        <div class="col-md-6 text-center">
            <?php if (!empty($sense->cover_image_asset?->media_asset?->path)): ?>
                <img src="/img/<?= h($sense->cover_image_asset->media_asset->path) ?>" class="img-fluid rounded shadow-sm" alt="">
            <?php endif; ?>
        </div>
    </div>
