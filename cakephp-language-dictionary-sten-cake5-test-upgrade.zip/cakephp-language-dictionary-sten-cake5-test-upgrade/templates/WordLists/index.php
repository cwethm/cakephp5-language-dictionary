<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\Cake\Datasource\EntityInterface> $wordLists
 */
?>
<div class="wordLists index content">
    <?= $this->Html->link(__('New Word List'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Word Lists') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('user_id') ?></th>
                    <th><?= $this->Paginator->sort('list_type') ?></th>
                    <th><?= $this->Paginator->sort('name') ?></th>
                    <th><?= $this->Paginator->sort('tag_count') ?></th>
                    <th><?= $this->Paginator->sort('trashed') ?></th>
                    <th><?= $this->Paginator->sort('created_by') ?></th>
                    <th><?= $this->Paginator->sort('modified_by') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($wordLists as $wordList): ?>
                <tr>
                    <td><?= $this->Number->format($wordList->id) ?></td>
                    <td><?= $wordList->hasValue('user') ? $this->Html->link($wordList->user->id, ['controller' => 'Users', 'action' => 'view', $wordList->user->id]) : '' ?></td>
                    <td><?= h($wordList->list_type) ?></td>
                    <td><?= h($wordList->name) ?></td>
                    <td><?= $wordList->tag_count === null ? '' : $this->Number->format($wordList->tag_count) ?></td>
                    <td><?= h($wordList->trashed) ?></td>
                    <td><?= $wordList->created_by === null ? '' : $this->Number->format($wordList->created_by) ?></td>
                    <td><?= $wordList->modified_by === null ? '' : $this->Number->format($wordList->modified_by) ?></td>
                    <td><?= h($wordList->created) ?></td>
                    <td><?= h($wordList->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $wordList->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $wordList->id]) ?>
                        <?= $this->Form->postLink(
                            __('Delete'),
                            ['action' => 'delete', $wordList->id],
                            [
                                'method' => 'delete',
                                'confirm' => __('Are you sure you want to delete # {0}?', $wordList->id),
                            ]
                        ) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>