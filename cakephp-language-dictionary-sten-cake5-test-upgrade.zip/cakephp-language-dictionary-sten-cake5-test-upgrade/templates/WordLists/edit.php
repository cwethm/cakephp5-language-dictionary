<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $wordList
 * @var string[]|\Cake\Collection\CollectionInterface $users
 * @var string[]|\Cake\Collection\CollectionInterface $lexicalEntries
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', $wordList->id],
                ['confirm' => __('Are you sure you want to delete # {0}?', $wordList->id), 'class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List Word Lists'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="wordLists form content">
            <?= $this->Form->create($wordList) ?>
            <fieldset>
                <legend><?= __('Edit Word List') ?></legend>
                <?php
                    echo $this->Form->control('user_id', ['options' => $users, 'empty' => true]);
                    echo $this->Form->control('list_type');
                    echo $this->Form->control('name');
                    echo $this->Form->control('description');
                    echo $this->Form->control('tag_count');
                    echo $this->Form->control('trashed', ['empty' => true]);
                    echo $this->Form->control('created_by');
                    echo $this->Form->control('modified_by');
                    echo $this->Form->control('lexical_entries._ids', ['options' => $lexicalEntries]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
