<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $wordList
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Word List'), ['action' => 'edit', $wordList->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Word List'), ['action' => 'delete', $wordList->id], ['confirm' => __('Are you sure you want to delete # {0}?', $wordList->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Word Lists'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Word List'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="wordLists view content">
            <h3><?= h($wordList->name) ?></h3>
            <table>
                <tr>
                    <th><?= __('User') ?></th>
                    <td><?= $wordList->hasValue('user') ? $this->Html->link($wordList->user->id, ['controller' => 'Users', 'action' => 'view', $wordList->user->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('List Type') ?></th>
                    <td><?= h($wordList->list_type) ?></td>
                </tr>
                <tr>
                    <th><?= __('Name') ?></th>
                    <td><?= h($wordList->name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($wordList->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Tag Count') ?></th>
                    <td><?= $wordList->tag_count === null ? '' : $this->Number->format($wordList->tag_count) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created By') ?></th>
                    <td><?= $wordList->created_by === null ? '' : $this->Number->format($wordList->created_by) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified By') ?></th>
                    <td><?= $wordList->modified_by === null ? '' : $this->Number->format($wordList->modified_by) ?></td>
                </tr>
                <tr>
                    <th><?= __('Trashed') ?></th>
                    <td><?= h($wordList->trashed) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($wordList->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($wordList->modified) ?></td>
                </tr>
            </table>
            <div class="text">
                <strong><?= __('Description') ?></strong>
                <blockquote>
                    <?= $this->Text->autoParagraph(h($wordList->description)); ?>
                </blockquote>
            </div>
            <div class="related">
                <h4><?= __('Related Lexical Entries') ?></h4>
                <?php if (!empty($wordList->lexical_entries)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Slug') ?></th>
                            <th><?= __('Entry Type') ?></th>
                            <th><?= __('Name') ?></th>
                            <th><?= __('Translated') ?></th>
                            <th><?= __('Part Of Speech') ?></th>
                            <th><?= __('Language Id') ?></th>
                            <th><?= __('Coverimg') ?></th>
                            <th><?= __('Coversound') ?></th>
                            <th><?= __('Tag Count') ?></th>
                            <th><?= __('Trashed') ?></th>
                            <th><?= __('User Id') ?></th>
                            <th><?= __('Created By') ?></th>
                            <th><?= __('Modified By') ?></th>
                            <th><?= __('Created') ?></th>
                            <th><?= __('Modified') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($wordList->lexical_entries as $lexicalEntry) : ?>
                        <tr>
                            <td><?= h($lexicalEntry->id) ?></td>
                            <td><?= h($lexicalEntry->slug) ?></td>
                            <td><?= h($lexicalEntry->entry_type) ?></td>
                            <td><?= h($lexicalEntry->name) ?></td>
                            <td><?= h($lexicalEntry->translated) ?></td>
                            <td><?= h($lexicalEntry->part_of_speech) ?></td>
                            <td><?= h($lexicalEntry->language_id) ?></td>
                            <td><?= h($lexicalEntry->coverimg) ?></td>
                            <td><?= h($lexicalEntry->coversound) ?></td>
                            <td><?= h($lexicalEntry->tag_count) ?></td>
                            <td><?= h($lexicalEntry->trashed) ?></td>
                            <td><?= h($lexicalEntry->user_id) ?></td>
                            <td><?= h($lexicalEntry->created_by) ?></td>
                            <td><?= h($lexicalEntry->modified_by) ?></td>
                            <td><?= h($lexicalEntry->created) ?></td>
                            <td><?= h($lexicalEntry->modified) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'LexicalEntries', 'action' => 'view', $lexicalEntry->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'LexicalEntries', 'action' => 'edit', $lexicalEntry->id]) ?>
                                <?= $this->Form->postLink(
                                    __('Delete'),
                                    ['controller' => 'LexicalEntries', 'action' => 'delete', $lexicalEntry->id],
                                    [
                                        'method' => 'delete',
                                        'confirm' => __('Are you sure you want to delete # {0}?', $lexicalEntry->id),
                                    ]
                                ) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>