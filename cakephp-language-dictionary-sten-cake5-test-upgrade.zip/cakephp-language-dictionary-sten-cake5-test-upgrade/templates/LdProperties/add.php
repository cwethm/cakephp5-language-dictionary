<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $ldProperty
 * @var \Cake\Collection\CollectionInterface|string[] $linguisticDescriptions
 * @var \Cake\Collection\CollectionInterface|string[] $lemonAttributes
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('List Ld Properties'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="ldProperties form content">
            <?= $this->Form->create($ldProperty) ?>
            <fieldset>
                <legend><?= __('Add Ld Property') ?></legend>
                <?php
                    echo $this->Form->control('linguistic_description_id', ['options' => $linguisticDescriptions]);
                    echo $this->Form->control('lemon_attribute_id', ['options' => $lemonAttributes]);
                    echo $this->Form->control('value');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
