<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $ldProperty
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Ld Property'), ['action' => 'edit', $ldProperty->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Ld Property'), ['action' => 'delete', $ldProperty->id], ['confirm' => __('Are you sure you want to delete # {0}?', $ldProperty->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Ld Properties'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Ld Property'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="ldProperties view content">
            <h3><?= h($ldProperty->id) ?></h3>
            <table>
                <tr>
                    <th><?= __('Linguistic Description') ?></th>
                    <td><?= $ldProperty->hasValue('linguistic_description') ? $this->Html->link($ldProperty->linguistic_description->id, ['controller' => 'LinguisticDescriptions', 'action' => 'view', $ldProperty->linguistic_description->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Lemon Attribute') ?></th>
                    <td><?= $ldProperty->hasValue('lemon_attribute') ? $this->Html->link($ldProperty->lemon_attribute->name, ['controller' => 'LemonAttributes', 'action' => 'view', $ldProperty->lemon_attribute->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Value') ?></th>
                    <td><?= h($ldProperty->value) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($ldProperty->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($ldProperty->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($ldProperty->modified) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>