<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\Cake\Datasource\EntityInterface> $ldProperties
 */
?>
<div class="ldProperties index content">
    <?= $this->Html->link(__('New Ld Property'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Ld Properties') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('linguistic_description_id') ?></th>
                    <th><?= $this->Paginator->sort('lemon_attribute_id') ?></th>
                    <th><?= $this->Paginator->sort('value') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($ldProperties as $ldProperty): ?>
                <tr>
                    <td><?= $this->Number->format($ldProperty->id) ?></td>
                    <td><?= $ldProperty->hasValue('linguistic_description') ? $this->Html->link($ldProperty->linguistic_description->id, ['controller' => 'LinguisticDescriptions', 'action' => 'view', $ldProperty->linguistic_description->id]) : '' ?></td>
                    <td><?= $ldProperty->hasValue('lemon_attribute') ? $this->Html->link($ldProperty->lemon_attribute->name, ['controller' => 'LemonAttributes', 'action' => 'view', $ldProperty->lemon_attribute->id]) : '' ?></td>
                    <td><?= h($ldProperty->value) ?></td>
                    <td><?= h($ldProperty->created) ?></td>
                    <td><?= h($ldProperty->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $ldProperty->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $ldProperty->id]) ?>
                        <?= $this->Form->postLink(
                            __('Delete'),
                            ['action' => 'delete', $ldProperty->id],
                            [
                                'method' => 'delete',
                                'confirm' => __('Are you sure you want to delete # {0}?', $ldProperty->id),
                            ]
                        ) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>