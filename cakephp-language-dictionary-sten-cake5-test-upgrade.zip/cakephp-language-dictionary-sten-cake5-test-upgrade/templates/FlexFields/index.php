<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\Cake\Datasource\EntityInterface> $flexFields
 */
?>
<div class="flexFields index content">
    <?= $this->Html->link(__('New Flex Field'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Flex Fields') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('slug') ?></th>
                    <th><?= $this->Paginator->sort('word_id') ?></th>
                    <th><?= $this->Paginator->sort('flex_key') ?></th>
                    <th><?= $this->Paginator->sort('flex_value') ?></th>
                    <th><?= $this->Paginator->sort('second_value') ?></th>
                    <th><?= $this->Paginator->sort('user_id') ?></th>
                    <th><?= $this->Paginator->sort('active') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($flexFields as $flexField): ?>
                <tr>
                    <td><?= $this->Number->format($flexField->id) ?></td>
                    <td><?= h($flexField->slug) ?></td>
                    <td><?= $this->Number->format($flexField->word_id) ?></td>
                    <td><?= h($flexField->flex_key) ?></td>
                    <td><?= h($flexField->flex_value) ?></td>
                    <td><?= h($flexField->second_value) ?></td>
                    <td><?= $flexField->hasValue('user') ? $this->Html->link($flexField->user->id, ['controller' => 'Users', 'action' => 'view', $flexField->user->id]) : '' ?></td>
                    <td><?= h($flexField->active) ?></td>
                    <td><?= h($flexField->created) ?></td>
                    <td><?= h($flexField->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $flexField->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $flexField->id]) ?>
                        <?= $this->Form->postLink(
                            __('Delete'),
                            ['action' => 'delete', $flexField->id],
                            [
                                'method' => 'delete',
                                'confirm' => __('Are you sure you want to delete # {0}?', $flexField->id),
                            ]
                        ) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>