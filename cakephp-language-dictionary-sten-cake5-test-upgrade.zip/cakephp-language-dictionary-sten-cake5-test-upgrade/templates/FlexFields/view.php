<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $flexField
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Flex Field'), ['action' => 'edit', $flexField->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Flex Field'), ['action' => 'delete', $flexField->id], ['confirm' => __('Are you sure you want to delete # {0}?', $flexField->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Flex Fields'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Flex Field'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="flexFields view content">
            <h3><?= h($flexField->flex_key) ?></h3>
            <table>
                <tr>
                    <th><?= __('Slug') ?></th>
                    <td><?= h($flexField->slug) ?></td>
                </tr>
                <tr>
                    <th><?= __('Flex Key') ?></th>
                    <td><?= h($flexField->flex_key) ?></td>
                </tr>
                <tr>
                    <th><?= __('Flex Value') ?></th>
                    <td><?= h($flexField->flex_value) ?></td>
                </tr>
                <tr>
                    <th><?= __('Second Value') ?></th>
                    <td><?= h($flexField->second_value) ?></td>
                </tr>
                <tr>
                    <th><?= __('User') ?></th>
                    <td><?= $flexField->hasValue('user') ? $this->Html->link($flexField->user->id, ['controller' => 'Users', 'action' => 'view', $flexField->user->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($flexField->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Word Id') ?></th>
                    <td><?= $this->Number->format($flexField->word_id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($flexField->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($flexField->modified) ?></td>
                </tr>
                <tr>
                    <th><?= __('Active') ?></th>
                    <td><?= $flexField->active ? __('Yes') : __('No'); ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>