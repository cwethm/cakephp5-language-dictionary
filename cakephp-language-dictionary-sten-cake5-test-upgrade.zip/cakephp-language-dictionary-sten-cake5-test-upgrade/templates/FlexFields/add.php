<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $flexField
 * @var \Cake\Collection\CollectionInterface|string[] $users
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('List Flex Fields'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="flexFields form content">
            <?= $this->Form->create($flexField) ?>
            <fieldset>
                <legend><?= __('Add Flex Field') ?></legend>
                <?php
                    echo $this->Form->control('slug');
                    echo $this->Form->control('word_id');
                    echo $this->Form->control('flex_key');
                    echo $this->Form->control('flex_value');
                    echo $this->Form->control('second_value');
                    echo $this->Form->control('user_id', ['options' => $users, 'empty' => true]);
                    echo $this->Form->control('active');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
