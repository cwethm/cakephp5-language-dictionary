<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $sense
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Sense'), ['action' => 'edit', $sense->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Sense'), ['action' => 'delete', $sense->id], ['confirm' => __('Are you sure you want to delete # {0}?', $sense->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Senses'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Sense'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="senses view content">
            <h3><?= h($sense->id) ?></h3>
            <table>
                <tr>
                    <th><?= __('Lexical Entry') ?></th>
                    <td><?= $sense->hasValue('lexical_entry') ? $this->Html->link($sense->lexical_entry->name, ['controller' => 'LexicalEntries', 'action' => 'view', $sense->lexical_entry->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Slug') ?></th>
                    <td><?= h($sense->slug) ?></td>
                </tr>
                <tr>
                    <th><?= __('Entry Name') ?></th>
                    <td><?= h($sense->entry_name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Reference') ?></th>
                    <td><?= h($sense->reference) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($sense->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Coverimg') ?></th>
                    <td><?= $sense->coverimg === null ? '' : $this->Number->format($sense->coverimg) ?></td>
                </tr>
                <tr>
                    <th><?= __('Coversnd') ?></th>
                    <td><?= $sense->coversnd === null ? '' : $this->Number->format($sense->coversnd) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($sense->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($sense->modified) ?></td>
                </tr>
            </table>
            <div class="text">
                <strong><?= __('Definition') ?></strong>
                <blockquote>
                    <?= $this->Text->autoParagraph(h($sense->definition)); ?>
                </blockquote>
            </div>
            <div class="related">
                <h4><?= __('Related Classification Categories') ?></h4>
                <?php if (!empty($sense->classification_categories)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Lft') ?></th>
                            <th><?= __('Rght') ?></th>
                            <th><?= __('Parent Id') ?></th>
                            <th><?= __('Name') ?></th>
                            <th><?= __('Created') ?></th>
                            <th><?= __('Modified') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($sense->classification_categories as $classificationCategory) : ?>
                        <tr>
                            <td><?= h($classificationCategory->id) ?></td>
                            <td><?= h($classificationCategory->lft) ?></td>
                            <td><?= h($classificationCategory->rght) ?></td>
                            <td><?= h($classificationCategory->parent_id) ?></td>
                            <td><?= h($classificationCategory->name) ?></td>
                            <td><?= h($classificationCategory->created) ?></td>
                            <td><?= h($classificationCategory->modified) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'ClassificationCategories', 'action' => 'view', $classificationCategory->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'ClassificationCategories', 'action' => 'edit', $classificationCategory->id]) ?>
                                <?= $this->Form->postLink(
                                    __('Delete'),
                                    ['controller' => 'ClassificationCategories', 'action' => 'delete', $classificationCategory->id],
                                    [
                                        'method' => 'delete',
                                        'confirm' => __('Are you sure you want to delete # {0}?', $classificationCategory->id),
                                    ]
                                ) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            <div class="related">
                <h4><?= __('Related Linguistic Descriptions') ?></h4>
                <?php if (!empty($sense->linguistic_descriptions)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Lexical Entry Id') ?></th>
                            <th><?= __('Sense Id') ?></th>
                            <th><?= __('Form Id') ?></th>
                            <th><?= __('Lemon Attribute Id') ?></th>
                            <th><?= __('Value') ?></th>
                            <th><?= __('Created') ?></th>
                            <th><?= __('Modified') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($sense->linguistic_descriptions as $linguisticDescription) : ?>
                        <tr>
                            <td><?= h($linguisticDescription->id) ?></td>
                            <td><?= h($linguisticDescription->lexical_entry_id) ?></td>
                            <td><?= h($linguisticDescription->sense_id) ?></td>
                            <td><?= h($linguisticDescription->form_id) ?></td>
                            <td><?= h($linguisticDescription->lemon_attribute_id) ?></td>
                            <td><?= h($linguisticDescription->value) ?></td>
                            <td><?= h($linguisticDescription->created) ?></td>
                            <td><?= h($linguisticDescription->modified) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'LinguisticDescriptions', 'action' => 'view', $linguisticDescription->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'LinguisticDescriptions', 'action' => 'edit', $linguisticDescription->id]) ?>
                                <?= $this->Form->postLink(
                                    __('Delete'),
                                    ['controller' => 'LinguisticDescriptions', 'action' => 'delete', $linguisticDescription->id],
                                    [
                                        'method' => 'delete',
                                        'confirm' => __('Are you sure you want to delete # {0}?', $linguisticDescription->id),
                                    ]
                                ) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>