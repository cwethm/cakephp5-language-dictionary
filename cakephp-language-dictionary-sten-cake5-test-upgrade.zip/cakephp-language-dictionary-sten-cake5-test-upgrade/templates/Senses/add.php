<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $sense
 * @var \Cake\Collection\CollectionInterface|string[] $lexicalEntries
 * @var \Cake\Collection\CollectionInterface|string[] $classificationCategories
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('List Senses'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="senses form content">
            <?= $this->Form->create($sense) ?>
            <fieldset>
                <legend><?= __('Add Sense') ?></legend>
                <?php
                    echo $this->Form->control('lexical_entry_id', ['options' => $lexicalEntries]);
                    echo $this->Form->control('slug');
                    echo $this->Form->control('entry_name');
                    echo $this->Form->control('definition');
                    echo $this->Form->control('coverimg');
                    echo $this->Form->control('coversnd');
                    echo $this->Form->control('reference');
                    echo $this->Form->control('classification_categories._ids', ['options' => $classificationCategories]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
