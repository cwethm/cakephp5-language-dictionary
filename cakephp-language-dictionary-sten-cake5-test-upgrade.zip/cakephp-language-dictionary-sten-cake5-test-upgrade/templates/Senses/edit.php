<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $sense
 * @var string[]|\Cake\Collection\CollectionInterface $lexicalEntries
 * @var string[]|\Cake\Collection\CollectionInterface $classificationCategories
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', $sense->id],
                ['confirm' => __('Are you sure you want to delete # {0}?', $sense->id), 'class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List Senses'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="senses form content">
            <?= $this->Form->create($sense) ?>
            <fieldset>
                <legend><?= __('Edit Sense') ?></legend>
                <?php
                    echo $this->Form->control('lexical_entry_id', ['options' => $lexicalEntries]);
                    echo $this->Form->control('slug');
                    echo $this->Form->control('entry_name');
                    echo $this->Form->control('definition');
                    echo $this->Form->control('coverimg');
                    echo $this->Form->control('coversnd');
                    echo $this->Form->control('reference');
                    echo $this->Form->control('classification_categories._ids', ['options' => $classificationCategories]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
