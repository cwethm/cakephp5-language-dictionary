<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\Cake\Datasource\EntityInterface> $linguisticDescriptions
 */
?>
<div class="linguisticDescriptions index content">
    <?= $this->Html->link(__('New Linguistic Description'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Linguistic Descriptions') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('lexical_entry_id') ?></th>
                    <th><?= $this->Paginator->sort('sense_id') ?></th>
                    <th><?= $this->Paginator->sort('form_id') ?></th>
                    <th><?= $this->Paginator->sort('lemon_attribute_id') ?></th>
                    <th><?= $this->Paginator->sort('value') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($linguisticDescriptions as $linguisticDescription): ?>
                <tr>
                    <td><?= $this->Number->format($linguisticDescription->id) ?></td>
                    <td><?= $linguisticDescription->hasValue('lexical_entry') ? $this->Html->link($linguisticDescription->lexical_entry->name, ['controller' => 'LexicalEntries', 'action' => 'view', $linguisticDescription->lexical_entry->id]) : '' ?></td>
                    <td><?= $linguisticDescription->hasValue('sense') ? $this->Html->link($linguisticDescription->sense->id, ['controller' => 'Senses', 'action' => 'view', $linguisticDescription->sense->id]) : '' ?></td>
                    <td><?= $linguisticDescription->hasValue('form') ? $this->Html->link($linguisticDescription->form->form_type, ['controller' => 'Forms', 'action' => 'view', $linguisticDescription->form->id]) : '' ?></td>
                    <td><?= $linguisticDescription->hasValue('lemon_attribute') ? $this->Html->link($linguisticDescription->lemon_attribute->name, ['controller' => 'LemonAttributes', 'action' => 'view', $linguisticDescription->lemon_attribute->id]) : '' ?></td>
                    <td><?= h($linguisticDescription->value) ?></td>
                    <td><?= h($linguisticDescription->created) ?></td>
                    <td><?= h($linguisticDescription->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $linguisticDescription->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $linguisticDescription->id]) ?>
                        <?= $this->Form->postLink(
                            __('Delete'),
                            ['action' => 'delete', $linguisticDescription->id],
                            [
                                'method' => 'delete',
                                'confirm' => __('Are you sure you want to delete # {0}?', $linguisticDescription->id),
                            ]
                        ) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>