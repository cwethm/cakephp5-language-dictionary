<?= $this->Form->create($entity, ['id' => 'addNewRowForm']) ?>
<?= $this->Form->control('lemon_attribute_id') ?>
<?= $this->Form->control('value') ?>
<button type="submit" class="btn btn-primary">Save</button>
<?= $this->Form->end() ?>
	