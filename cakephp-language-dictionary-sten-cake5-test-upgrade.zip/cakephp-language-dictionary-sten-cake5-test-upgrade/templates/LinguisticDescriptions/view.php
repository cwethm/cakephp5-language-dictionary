<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $linguisticDescription
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Linguistic Description'), ['action' => 'edit', $linguisticDescription->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Linguistic Description'), ['action' => 'delete', $linguisticDescription->id], ['confirm' => __('Are you sure you want to delete # {0}?', $linguisticDescription->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Linguistic Descriptions'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Linguistic Description'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="linguisticDescriptions view content">
            <h3><?= h($linguisticDescription->id) ?></h3>
            <table>
                <tr>
                    <th><?= __('Lexical Entry') ?></th>
                    <td><?= $linguisticDescription->hasValue('lexical_entry') ? $this->Html->link($linguisticDescription->lexical_entry->name, ['controller' => 'LexicalEntries', 'action' => 'view', $linguisticDescription->lexical_entry->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Sense') ?></th>
                    <td><?= $linguisticDescription->hasValue('sense') ? $this->Html->link($linguisticDescription->sense->id, ['controller' => 'Senses', 'action' => 'view', $linguisticDescription->sense->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Form') ?></th>
                    <td><?= $linguisticDescription->hasValue('form') ? $this->Html->link($linguisticDescription->form->form_type, ['controller' => 'Forms', 'action' => 'view', $linguisticDescription->form->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Lemon Attribute') ?></th>
                    <td><?= $linguisticDescription->hasValue('lemon_attribute') ? $this->Html->link($linguisticDescription->lemon_attribute->name, ['controller' => 'LemonAttributes', 'action' => 'view', $linguisticDescription->lemon_attribute->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Value') ?></th>
                    <td><?= h($linguisticDescription->value) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($linguisticDescription->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($linguisticDescription->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($linguisticDescription->modified) ?></td>
                </tr>
            </table>
            <div class="related">
                <h4><?= __('Related Ld Properties') ?></h4>
                <?php if (!empty($linguisticDescription->ld_properties)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Linguistic Description Id') ?></th>
                            <th><?= __('Lemon Attribute Id') ?></th>
                            <th><?= __('Value') ?></th>
                            <th><?= __('Created') ?></th>
                            <th><?= __('Modified') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($linguisticDescription->ld_properties as $ldProperty) : ?>
                        <tr>
                            <td><?= h($ldProperty->id) ?></td>
                            <td><?= h($ldProperty->linguistic_description_id) ?></td>
                            <td><?= h($ldProperty->lemon_attribute_id) ?></td>
                            <td><?= h($ldProperty->value) ?></td>
                            <td><?= h($ldProperty->created) ?></td>
                            <td><?= h($ldProperty->modified) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'LdProperties', 'action' => 'view', $ldProperty->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'LdProperties', 'action' => 'edit', $ldProperty->id]) ?>
                                <?= $this->Form->postLink(
                                    __('Delete'),
                                    ['controller' => 'LdProperties', 'action' => 'delete', $ldProperty->id],
                                    [
                                        'method' => 'delete',
                                        'confirm' => __('Are you sure you want to delete # {0}?', $ldProperty->id),
                                    ]
                                ) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>