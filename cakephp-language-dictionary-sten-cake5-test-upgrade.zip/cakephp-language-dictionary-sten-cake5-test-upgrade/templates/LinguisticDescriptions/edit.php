<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $linguisticDescription
 * @var string[]|\Cake\Collection\CollectionInterface $lexicalEntries
 * @var string[]|\Cake\Collection\CollectionInterface $senses
 * @var string[]|\Cake\Collection\CollectionInterface $forms
 * @var string[]|\Cake\Collection\CollectionInterface $lemonAttributes
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', $linguisticDescription->id],
                ['confirm' => __('Are you sure you want to delete # {0}?', $linguisticDescription->id), 'class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List Linguistic Descriptions'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="linguisticDescriptions form content">
            <?= $this->Form->create($linguisticDescription) ?>
            <fieldset>
                <legend><?= __('Edit Linguistic Description') ?></legend>
                <?php
                    echo $this->Form->control('lexical_entry_id', ['options' => $lexicalEntries, 'empty' => true]);
                    echo $this->Form->control('sense_id', ['options' => $senses, 'empty' => true]);
                    echo $this->Form->control('form_id', ['options' => $forms, 'empty' => true]);
                    echo $this->Form->control('lemon_attribute_id', ['options' => $lemonAttributes]);
                    echo $this->Form->control('value');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
