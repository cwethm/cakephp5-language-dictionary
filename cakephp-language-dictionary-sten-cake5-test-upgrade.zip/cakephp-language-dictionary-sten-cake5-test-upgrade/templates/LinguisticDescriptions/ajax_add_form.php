<?php 
    $this->loadHelper('LemonTools.DataTable');
    $this->loadHelper('LemonTools.DynamicForm'); 
?>
<?= $this->Form->create($desc, [
    'id' => 'modalForm',
    'url' => ['action' => 'add'],
    'class' => 'needs-validation',
    'data-ajax-submit' => 'true'
]) ?>
<?php 
if (!empty($rdf_class)) {
    $presentationConfig['rdf_class'] ??= $rdf_class;
}
echo $this->DynamicForm->autoFields($presentationConfig, $desc);
?>
<button type="submit" class="btn btn-success">Save</button>
<?= $this->Form->end() ?>
  