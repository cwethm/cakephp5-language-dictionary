<?php 
    $this->loadHelper('LemonTools.DataTable');
?>
<?= $this->Form->create($desc, [
    'id' => 'modalForm',
    'url' => ['action' => 'add'],
    'class' => 'needs-validation'
]) ?>
<?php
    if (!empty($rdf_class)) {
        $presentationConfig['rdf_class'] ??= $rdf_class;
    }
    echo $this->DynamicForm->autoFields($presentationConfig, $desc);
?>
<button type="submit" class="btn btn-success">Save</button>
<?= $this->Form->end() ?>
