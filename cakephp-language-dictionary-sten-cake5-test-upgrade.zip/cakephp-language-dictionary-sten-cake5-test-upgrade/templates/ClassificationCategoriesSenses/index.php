<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\Cake\Datasource\EntityInterface> $classificationCategoriesSenses
 */
?>
<div class="classificationCategoriesSenses index content">
    <?= $this->Html->link(__('New Classification Categories Sense'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Classification Categories Senses') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('sense_id') ?></th>
                    <th><?= $this->Paginator->sort('classification_category_id') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($classificationCategoriesSenses as $classificationCategoriesSense): ?>
                <tr>
                    <td><?= $this->Number->format($classificationCategoriesSense->id) ?></td>
                    <td><?= $classificationCategoriesSense->hasValue('sense') ? $this->Html->link($classificationCategoriesSense->sense->id, ['controller' => 'Senses', 'action' => 'view', $classificationCategoriesSense->sense->id]) : '' ?></td>
                    <td><?= $classificationCategoriesSense->hasValue('classification_category') ? $this->Html->link($classificationCategoriesSense->classification_category->name, ['controller' => 'ClassificationCategories', 'action' => 'view', $classificationCategoriesSense->classification_category->id]) : '' ?></td>
                    <td><?= h($classificationCategoriesSense->created) ?></td>
                    <td><?= h($classificationCategoriesSense->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $classificationCategoriesSense->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $classificationCategoriesSense->id]) ?>
                        <?= $this->Form->postLink(
                            __('Delete'),
                            ['action' => 'delete', $classificationCategoriesSense->id],
                            [
                                'method' => 'delete',
                                'confirm' => __('Are you sure you want to delete # {0}?', $classificationCategoriesSense->id),
                            ]
                        ) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>