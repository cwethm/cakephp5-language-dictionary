<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $classificationCategoriesSense
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Classification Categories Sense'), ['action' => 'edit', $classificationCategoriesSense->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Classification Categories Sense'), ['action' => 'delete', $classificationCategoriesSense->id], ['confirm' => __('Are you sure you want to delete # {0}?', $classificationCategoriesSense->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Classification Categories Senses'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Classification Categories Sense'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="classificationCategoriesSenses view content">
            <h3><?= h($classificationCategoriesSense->id) ?></h3>
            <table>
                <tr>
                    <th><?= __('Sense') ?></th>
                    <td><?= $classificationCategoriesSense->hasValue('sense') ? $this->Html->link($classificationCategoriesSense->sense->id, ['controller' => 'Senses', 'action' => 'view', $classificationCategoriesSense->sense->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Classification Category') ?></th>
                    <td><?= $classificationCategoriesSense->hasValue('classification_category') ? $this->Html->link($classificationCategoriesSense->classification_category->name, ['controller' => 'ClassificationCategories', 'action' => 'view', $classificationCategoriesSense->classification_category->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($classificationCategoriesSense->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($classificationCategoriesSense->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($classificationCategoriesSense->modified) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>