<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $classificationCategoriesSense
 * @var \Cake\Collection\CollectionInterface|string[] $senses
 * @var \Cake\Collection\CollectionInterface|string[] $classificationCategories
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('List Classification Categories Senses'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="classificationCategoriesSenses form content">
            <?= $this->Form->create($classificationCategoriesSense) ?>
            <fieldset>
                <legend><?= __('Add Classification Categories Sense') ?></legend>
                <?php
                    echo $this->Form->control('sense_id', ['options' => $senses]);
                    echo $this->Form->control('classification_category_id', ['options' => $classificationCategories]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
