<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $lexicalEntriesWordList
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Lexical Entries Word List'), ['action' => 'edit', $lexicalEntriesWordList->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Lexical Entries Word List'), ['action' => 'delete', $lexicalEntriesWordList->id], ['confirm' => __('Are you sure you want to delete # {0}?', $lexicalEntriesWordList->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Lexical Entries Word Lists'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Lexical Entries Word List'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="lexicalEntriesWordLists view content">
            <h3><?= h($lexicalEntriesWordList->id) ?></h3>
            <table>
                <tr>
                    <th><?= __('Lexical Entry') ?></th>
                    <td><?= $lexicalEntriesWordList->hasValue('lexical_entry') ? $this->Html->link($lexicalEntriesWordList->lexical_entry->name, ['controller' => 'LexicalEntries', 'action' => 'view', $lexicalEntriesWordList->lexical_entry->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Word List') ?></th>
                    <td><?= $lexicalEntriesWordList->hasValue('word_list') ? $this->Html->link($lexicalEntriesWordList->word_list->name, ['controller' => 'WordLists', 'action' => 'view', $lexicalEntriesWordList->word_list->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('State') ?></th>
                    <td><?= h($lexicalEntriesWordList->state) ?></td>
                </tr>
                <tr>
                    <th><?= __('Note') ?></th>
                    <td><?= h($lexicalEntriesWordList->note) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($lexicalEntriesWordList->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified By') ?></th>
                    <td><?= $lexicalEntriesWordList->modified_by === null ? '' : $this->Number->format($lexicalEntriesWordList->modified_by) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created By') ?></th>
                    <td><?= $lexicalEntriesWordList->created_by === null ? '' : $this->Number->format($lexicalEntriesWordList->created_by) ?></td>
                </tr>
                <tr>
                    <th><?= __('Trashed') ?></th>
                    <td><?= h($lexicalEntriesWordList->trashed) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($lexicalEntriesWordList->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($lexicalEntriesWordList->modified) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>