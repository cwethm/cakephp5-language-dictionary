<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\Cake\Datasource\EntityInterface> $lexicalEntriesWordLists
 */
?>
<div class="lexicalEntriesWordLists index content">
    <?= $this->Html->link(__('New Lexical Entries Word List'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Lexical Entries Word Lists') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('lexical_entry_id') ?></th>
                    <th><?= $this->Paginator->sort('word_list_id') ?></th>
                    <th><?= $this->Paginator->sort('state') ?></th>
                    <th><?= $this->Paginator->sort('note') ?></th>
                    <th><?= $this->Paginator->sort('modified_by') ?></th>
                    <th><?= $this->Paginator->sort('created_by') ?></th>
                    <th><?= $this->Paginator->sort('trashed') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($lexicalEntriesWordLists as $lexicalEntriesWordList): ?>
                <tr>
                    <td><?= $this->Number->format($lexicalEntriesWordList->id) ?></td>
                    <td><?= $lexicalEntriesWordList->hasValue('lexical_entry') ? $this->Html->link($lexicalEntriesWordList->lexical_entry->name, ['controller' => 'LexicalEntries', 'action' => 'view', $lexicalEntriesWordList->lexical_entry->id]) : '' ?></td>
                    <td><?= $lexicalEntriesWordList->hasValue('word_list') ? $this->Html->link($lexicalEntriesWordList->word_list->name, ['controller' => 'WordLists', 'action' => 'view', $lexicalEntriesWordList->word_list->id]) : '' ?></td>
                    <td><?= h($lexicalEntriesWordList->state) ?></td>
                    <td><?= h($lexicalEntriesWordList->note) ?></td>
                    <td><?= $lexicalEntriesWordList->modified_by === null ? '' : $this->Number->format($lexicalEntriesWordList->modified_by) ?></td>
                    <td><?= $lexicalEntriesWordList->created_by === null ? '' : $this->Number->format($lexicalEntriesWordList->created_by) ?></td>
                    <td><?= h($lexicalEntriesWordList->trashed) ?></td>
                    <td><?= h($lexicalEntriesWordList->created) ?></td>
                    <td><?= h($lexicalEntriesWordList->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $lexicalEntriesWordList->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $lexicalEntriesWordList->id]) ?>
                        <?= $this->Form->postLink(
                            __('Delete'),
                            ['action' => 'delete', $lexicalEntriesWordList->id],
                            [
                                'method' => 'delete',
                                'confirm' => __('Are you sure you want to delete # {0}?', $lexicalEntriesWordList->id),
                            ]
                        ) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>