<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $lexicalEntriesWordList
 * @var string[]|\Cake\Collection\CollectionInterface $lexicalEntries
 * @var string[]|\Cake\Collection\CollectionInterface $wordLists
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', $lexicalEntriesWordList->id],
                ['confirm' => __('Are you sure you want to delete # {0}?', $lexicalEntriesWordList->id), 'class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List Lexical Entries Word Lists'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="lexicalEntriesWordLists form content">
            <?= $this->Form->create($lexicalEntriesWordList) ?>
            <fieldset>
                <legend><?= __('Edit Lexical Entries Word List') ?></legend>
                <?php
                    echo $this->Form->control('lexical_entry_id', ['options' => $lexicalEntries]);
                    echo $this->Form->control('word_list_id', ['options' => $wordLists]);
                    echo $this->Form->control('state');
                    echo $this->Form->control('note');
                    echo $this->Form->control('modified_by');
                    echo $this->Form->control('created_by');
                    echo $this->Form->control('trashed', ['empty' => true]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
