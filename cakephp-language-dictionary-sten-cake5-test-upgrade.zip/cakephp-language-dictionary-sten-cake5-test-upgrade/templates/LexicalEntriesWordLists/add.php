<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $lexicalEntriesWordList
 * @var \Cake\Collection\CollectionInterface|string[] $lexicalEntries
 * @var \Cake\Collection\CollectionInterface|string[] $wordLists
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('List Lexical Entries Word Lists'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="lexicalEntriesWordLists form content">
            <?= $this->Form->create($lexicalEntriesWordList) ?>
            <fieldset>
                <legend><?= __('Add Lexical Entries Word List') ?></legend>
                <?php
                    echo $this->Form->control('lexical_entry_id', ['options' => $lexicalEntries]);
                    echo $this->Form->control('word_list_id', ['options' => $wordLists]);
                    echo $this->Form->control('state');
                    echo $this->Form->control('note');
                    echo $this->Form->control('modified_by');
                    echo $this->Form->control('created_by');
                    echo $this->Form->control('trashed', ['empty' => true]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
