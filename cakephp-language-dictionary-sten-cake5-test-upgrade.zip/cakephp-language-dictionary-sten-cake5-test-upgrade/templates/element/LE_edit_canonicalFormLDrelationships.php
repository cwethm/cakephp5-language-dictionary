<!-- CanonicalForm Card (Top) -->

<?php 
    $this->loadHelper('LemonTools.DataTable');
?>
<div class="mb-4" data-database-table-name="" vocab="http://www.lexinfo.net/ontology/3.0/lexinfo#" typeof="lemon:CanonicalForm">
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h5 property="writtenRepresentation"><?= h($records->written_representation) ?></h5>
        </div>
        <div class="card-body">
            <dl class="row">
                <dt class="col-sm-3" property="language">Language:</dt>
                <dd class="col-sm-9"><?= h($records->language->name) ?></dd>


                <dt class="col-sm-3" property="writtenRepresentation">Written Representation:</dt>
                <dd class="col-sm-9"><?= h($records->written_representation) ?></dd>
            </dl>
        </div>
    </div>
</div>

<!-- LinguisticDescriptions Table -->

<h4>Associated Descriptions</h4>

<?php
$presentationConfig['rdf_class'] = 'lemon:CanonicalForm';
if (!empty($records->linguistic_descriptions)) {
    echo $this->DataTable->create(
        $records->linguistic_descriptions,
        $presentationConfig
    );
}
?>

<!-- Add New Description Button -->

<button
  type="button"
  class="btn btn-primary"
  data-modal-trigger
  data-modal-url="/language-dictionary/linguistic-descriptions/add/<?= $records->id ?>" 
  data-modal-mode="form"                       
  data-datatable-add-row                     <!-- Custom flag for your JS handler -->
>
  Add New Row
</button>
