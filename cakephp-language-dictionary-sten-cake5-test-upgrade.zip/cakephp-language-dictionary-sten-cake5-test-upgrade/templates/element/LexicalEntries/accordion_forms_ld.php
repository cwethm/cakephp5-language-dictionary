<?php
/*******************
/* accordion_forms_ld
/****************** */
?>
<div class="accordion" id="FormsAccordion">
<?php
foreach ($lexicalEntry->forms as $i => $form):
    $formId = 'form-' . h($form->id);
    $headerId = 'heading-' . $formId;
    $collapseId = 'collapse-' . $formId;

	if($form->form_type!=='canonical'){
		?>
    <div class="accordion-item mb-3" typeof="lemon:Form">
        <h2 class="accordion-header" id="<?= $headerId ?>">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#<?= $collapseId ?>" aria-expanded="false" aria-controls="<?= $collapseId ?>">
                <?= h($form->written_representation) ?> <span class="badge text-bg-primary ms-2"><?= h($form->form_type) ?></span>
            </button>
        </h2>

        </dl>
        <div id="<?= $collapseId ?>" class="accordion-collapse collapse" aria-labelledby="<?= $headerId ?>" data-bs-parent="#FormsAccordion">
            <div class="accordion-body">

	            <dl class="row">
	               <?php 
	               if(!EMPTY($form->language->name)) { ?>
	                <dt class="col-sm-3" property="language">Language:</dt>
	                <dd class="col-sm-9"><?= h($form->language->name) ?></dd>
					<?php 
					}
					?>

	            <dt class="col-sm-3" property="writtenRepresentation">Written Representation:</dt>
	            <dd class="col-sm-9"><?= h($form->written_representation) ?></dd>

                <?= $this->DataTable->create(
                    $form->linguistic_descriptions,
                    $presentationConfig,
                    [
                        'data-datatable' => 'true',
                        'data-form-id' => $form->id,
                        'data-lexical-entry-id' => $lexicalEntry->id,
                    ]
                ) ?>
            </div>            

			<!-- CanonicalForm-style modal trigger -->
			<button
			  type="button"
			  class="btn btn-primary"
			  data-modal-trigger
			  data-modal-url="/language-dictionary/linguistic-descriptions/add/<?= $form->id ?>"
			  data-modal-mode="form"
			  data-datatable-add-row >
			  Add New Description
			</button>

        </div>
    </div>
    <?php
}
?>
<?php endforeach; ?>
</div>
