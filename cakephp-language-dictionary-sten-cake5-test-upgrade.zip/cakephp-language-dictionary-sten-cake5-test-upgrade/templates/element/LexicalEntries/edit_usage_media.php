<?php
/**
 * templates/element/LexicalEntries/edit_usage_media.php
 * @var \LanguageDictionary\Model\Entity\LexicalEntry $lexicalEntry
 * @var array $mediaAssets
 * @var array $senses
 */
?>

<div class="row">
  <!-- LEFT COLUMN: Media Management -->
  <div class="col-md-6">
    <div class="card mb-4">
      <div class="card-header">
        <h5 class="mb-0">Attached Media</h5>
      </div>
      <div class="card-body">
     <?php foreach ($mediaAssets ?? [] as $asset): ?>
  <div class="col-6 col-md-4 col-lg-3 mb-3">
    <div class="card h-100">
      <div class="card-body p-2 text-center">
        <?php
          $isImage = ($asset->asset_type_id == 6);
          $thumbPath = $isImage ? ($asset->media_asset->variantUrls['thumbnail'] ?? $asset->media_asset->path ?? null) : null;
          $thumbSrc = $thumbPath ? '/files/' . h($thumbPath) : null;
        ?>

        <?php if ($isImage && $thumbSrc): ?>
          <img src="<?= $thumbSrc ?>" class="img-fluid mb-2 rounded border" alt="Media Thumbnail">
        <?php else: ?>
          <div class="display-4 text-secondary">
            <i class="bi bi-file-earmark<?= ($asset->media_asset->extension ?? '') === 'mp3' ? '-music' : ((($asset->media_asset->extension ?? '') === 'mp4') ? '-play' : '') ?>"></i>
          </div>
          <div class="small text-muted">
            <?= h($asset->media_asset->extension ?? 'file') ?> file
          </div>
        <?php endif; ?>

        <div>
          <?= $this->Form->postLink(
            __('Detach'),
            [
              'controller' => 'MediaAssets',
              'action' => 'detach',
              $asset->id,
              '?' => ['lexical_entry_id' => $lexicalEntry->id]
            ],
            ['class' => 'btn btn-sm btn-outline-danger', 'confirm' => __('Are you sure you want to detach this media?')]
          ) ?>
        </div>
      </div>
    </div>
  </div>
<?php endforeach; ?>

        <div class="mt-3">
          <?= $this->ModalLauncher->launchButton(__('Add Media'), [
            'class' => 'btn btn-primary',
            'icon' => 'bi bi-plus',
            'url' => [
              'plugin' => 'LemonTools',
              'controller' => 'Modal',
              'action' => 'form',
              'MediaAssets',
              null,
              '?' => ['lexical_entry_id' => $lexicalEntry->id]
            ],
            'mode' => 'form'
          ]) ?>
        </div>
      </div>
    </div>
  </div>

  <!-- RIGHT COLUMN: Cover Media & Example Usage -->
  <div class="col-md-6">
    <!-- Cover Media Card -->
    <div class="card mb-4">
      <div class="card-header">
        <h5 class="mb-0">Cover Media</h5>
      </div>
      <div class="card-body">
          <?= $this->element('LexicalEntries/cover_media_widget', ['sense' => $senses[0]]) ?>
      </div>
    </div>
  </div>

    <!-- Example Usage Card -->
    <div class="card">
      <div class="card-header">
        <h5 class="mb-0">Example Usage</h5>
      </div>
      <div class="card-body">
        <?php
            $allExamples = [];
            foreach ($lexicalEntry->senses ?? [] as $sense) {
                foreach ($sense->usage_examples ?? [] as $example) {
                    $allExamples[] = $example;
                }
            }
            ?>

            <?= $this->DataAccordionList->render($allExamples, 'recordings') ?>

      </div>
    </div>
  </div>
</div>
