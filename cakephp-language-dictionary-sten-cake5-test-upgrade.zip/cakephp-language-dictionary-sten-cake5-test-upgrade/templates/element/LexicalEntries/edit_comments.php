<?php
/************************
/*	lexical entrikes comments/discussions
/********************** */