<?php if (!empty($sampleSentences)): ?>
<div class="accordion-item">
    <h2 class="accordion-header" id="headingSampleSentences">
        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSampleSentences" aria-expanded="true">
            Sample Sentences
        </button>
    </h2>
    <div id="collapseSampleSentences" class="accordion-collapse collapse show" data-bs-parent="#wordDetailsAccordion">
        <div class="accordion-body">
            <ul class="list-unstyled">
                <?php foreach ($sampleSentences as $sentence): ?>
                    <li>
                        <?= h($sentence->text) ?>
                        <?php if (!empty($sentence->audio_path)): ?>
                            <button class="btn btn-sm btn-outline-secondary ms-2" onclick="$.playSound('/files/<?= h($sentence->audio_path) ?>')">
                                ▶ Play
                            </button>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</div>
<?php endif; ?>
