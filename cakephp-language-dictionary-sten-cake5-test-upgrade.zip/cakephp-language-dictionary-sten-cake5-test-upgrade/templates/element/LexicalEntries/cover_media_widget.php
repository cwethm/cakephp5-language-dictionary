<?php
/**
 * templates/element/LexicalEntries/cover_media_widget.php
 * @var \LanguageDictionary\Model\Entity\Sense $sense
 */
?>

<div class="cover-media-widget">
  <div class="card mb-3">
    <div class="card-header">
      <strong>Cover Media for Sense #<?= h($sense->id) ?></strong>
    </div>
    <div class="card-body d-flex flex-column gap-3">

      <?php if (!empty($sense->cover_image_asset?->media_asset?->path)): ?>
        <div>
          <strong>Cover Image:</strong><br>
          <img
            src="/files/<?= h($sense->cover_image_asset->media_asset->path) ?>"
            alt="Cover Image Preview"
            class="img-fluid border rounded"
            style="max-height: 160px"
          >
        </div>
      <?php endif; ?>

      <?php if (!empty($sense->cover_sound_asset?->media_asset?->path)): ?>
        <div>
          <strong>Cover Sound:</strong><br>
          <audio controls>
            <source src="/files/<?= h($sense->cover_sound_asset->media_asset->path) ?>" type="<?= h($sense->cover_sound_asset->media_asset->mime_type) ?>">
            Your browser does not support the audio element.
          </audio>
        </div>
      <?php endif; ?>

      <div>
        <?= $this->ModalLauncher->launchButton(__('Change Cover Media'), [
          'class' => 'btn btn-outline-primary btn-sm',
          'icon' => 'bi bi-pencil-square',
          'url' => [
            'plugin' => 'LemonTools',
            'controller' => 'Modal',
            'action' => 'form',
            'CoverAssets',
            $sense->id,
            '?' => ['context_model' => 'Senses', 'context_id' => $sense->id]
          ],
          'mode' => 'form'
        ]) ?>
      </div>

    </div>
  </div>
</div>
