<?php if (!empty($semanticCategories)): ?>
<div class="accordion-item">
    <h2 class="accordion-header" id="headingSemanticCategories">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSemanticCategories" aria-expanded="false">
            Semantic Categories
        </button>
    </h2>
    <div id="collapseSemanticCategories" class="accordion-collapse collapse" data-bs-parent="#wordDetailsAccordion">
        <div class="accordion-body">
            <ul class="list-unstyled mb-0">
                <?php foreach ($semanticCategories as $category): ?>
                    <li><span class="badge bg-info text-dark"><?= h($category->label ?? $category->name) ?></span></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</div>
<?php endif; ?>
