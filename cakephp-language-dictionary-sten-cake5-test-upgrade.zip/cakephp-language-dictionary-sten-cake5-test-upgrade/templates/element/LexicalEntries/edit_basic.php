<div class="container">
    <div class="row">
        <div class="col-12 col-md-6 mb-4">
            <!-- 🛠 Core Entry Data Card -->

                <?= $this->Form->create($lexicalEntry) ?>

            <div class="card mb-4" id="core-entry-data-card">
                <div class="card-header">
                    <h5>Core Entry Data</h5>
                </div>
                <div class="card-body"> 
                    <?= $this->DynamicForm->control('name', $lexicalEntry->toArray(), [],  $presentationConfig ) ?>
                    <?= $this->DynamicForm->control('translated', $lexicalEntry->toArray(), [],  $presentationConfig ) ?>
                    <?= $this->DynamicForm->control('entry_type', $lexicalEntry->toArray(), [], $presentationConfig ) ?>
                    <?= $this->DynamicForm->control('part_of_speech', $lexicalEntry->toArray(), [],  $presentationConfig ) ?>

                    <?= $this->Form->control('dictionaries._ids', [
                        'type' => 'select',
                        'multiple' => true,
                        'label' => 'Dictionaries',
                        'options' => $this->ValueSet->getOptions('dictionaries'),
                        'class' => 'form-select mb-3',
                    ]) ?>

                   <?php
                   $linguisticDescriptionsPresentationConfig['rdf_class'] = 'Lemon:CanonicalForm';
                   echo $this->element('LanguageDictionary.LE_edit_canonicalFormLDrelationships', [
                        'records' => $lexicalEntry->canonical_form,
                        'presentationConfig' =>  $linguisticDescriptionsPresentationConfig
                    ]); 
                   ?>
                </div>
            </div>

        </div>
        <div class="col-12 col-md-6 mb-4">
            <!-- 📚 Dictionaries + Linguistic Details Card -->
            <div class="card mb-4">
              <div class="card-header">
                <h5>Sense</h5>
              </div>

              <div class="card-body">
                <!-- 📝 Definition Textarea -->
                <?= $this->Form->control('senses.0.definition', [
                    'type' => 'textarea',
                    'label' => 'Definition',
                    'placeholder' => 'Short definition of this sense...',
                    'rows' => 3,
                    'class' => 'form-control'
                ]) ?>

                <!-- 📚 Category Selector Toggle -->
                <button class="btn btn-sm btn-outline-primary mt-3" 
                        type="button" 
                        data-bs-toggle="collapse" 
                        data-bs-target="#collapseCategoriesIds" 
                        aria-expanded="false" 
                        aria-controls="collapseCategoriesIds">
                    Select Semantic Categories
                </button>

                <!-- 📚 Category Tree -->
                <div id="collapseCategoriesIds" class="collapse mt-3" data-bs-parent="#categoriesaccordion">
                  <div class="card card-body p-0">
                    <div id="core-sense-category-tree-div" class="p-3">
                      <!-- Your nested <ul> tree structure goes here -->
                        <?= $this->CategoryTree->render($categories, $selectedCategoryIds, 0) ?>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="card mb-4">
                <div class="card-header">
                <h5>Forms 
                    <button
                      type="button"
                      class="btn btn-primary float-end"
                      data-modal-trigger
                      data-modal-url="/language-dictionary/forms/add/<?= $lexicalEntry->id ?>"
                      data-modal-mode="form"
                      data-datatable-add-row >
                      Add New LexicalForm
                    </button></h5>
                </div>
                <div class="card-body">

                <?= $this->element('LexicalEntries/accordion_forms_ld', [ 'lexicalEntry' => $lexicalEntry, 'presentationConfig' => $linguisticDescriptionsPresentationConfig ] ) ?>
                </div>
            </div>  

        </div>
        <!-- more col-6 cards if needed -->
    </div>

    <div class="row">
        <div class="col-12 col-md-6 mb-4">

        </div>
    </div>
</div>