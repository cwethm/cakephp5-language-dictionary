<ul class="cd-accordion-menu">
    <?php foreach ($categories as $category): ?>
        <li data-folderid="<?= h($category->id) ?>" class="<?= $category->children ? 'has-children' : '' ?>">
            <input type="checkbox" 
                   name="senses[0][category_ids][]" 
                   value="<?= h($category->id) ?>" 
                   id="sense-0-category-<?= h($category->id) ?>"
                   <?= in_array($category->id, $selectedCategoryIds) ? 'checked' : '' ?>>
            <label for="sense-0-category-<?= h($category->id) ?>">
                <?= h($category->name) ?>
            </label>

            <?php if (!empty($category->children)): ?>
                <ul>
                    <?php foreach ($category->children as $child): ?>
                        <!-- Recursive render again for child categories -->
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </li>
    <?php endforeach; ?>
</ul>
