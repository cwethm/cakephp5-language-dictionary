<!-- CanonicalForm Card (Top) -->
<?= 
    $this->loadHelper('LemonTools.DataTable')
?>

<div class="mb-4" vocab="http://www.lexinfo.net/ontology/3.0/lexinfo#" typeof="lemon:CanonicalForm">
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h5 property="writtenRep"><?= h($lexicalEntry->canonical_form->written_rep) ?></h5>
        </div>
        <div class="card-body">
            <dl class="row">
                <dt class="col-sm-3" property="language">Language:</dt>
                <dd class="col-sm-9"><?= h($lexicalEntry->canonical_form->language) ?></dd>


            <dt class="col-sm-3" property="phoneticRep">Phonetic Form:</dt>
            <dd class="col-sm-9"><?= h($lexicalEntry->canonical_form->phonetic_rep) ?></dd>
        </dl>
    </div>
</div>


</div>

<!-- LinguisticDescriptions Table -->

<h4>Associated Descriptions</h4>

<?= 
$this->DataTable->create($records, ['model' => 'LanguageDictionary.LinguisticDescriptions'])
?>

<?= $this->DataTable->create(
    $lexicalEntry->canonical_form->linguistic_descriptions,
    $presentationConfig,
    ['data-datatable' => 'true', 'data-lexical-entry-id' => $lexicalEntry->id]
) ?>

<!-- Add New Description Button -->

<?= $this->Html->link(
    'Add New Description',
    ['controller' => 'LinguisticDescriptions', 'action' => 'add', '?' => ['canonical_form_id' => $lexicalEntry->canonical_form->id]],
    ['class' => 'btn btn-success mt-3']
) ?>
