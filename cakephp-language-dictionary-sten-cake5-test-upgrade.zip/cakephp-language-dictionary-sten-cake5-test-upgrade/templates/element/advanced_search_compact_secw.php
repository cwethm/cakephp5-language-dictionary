<div class="m-0">
    <form name="qsearchform"
          id="qsearchform"
          action="<?= $this->Url->build(['controller' => 'LexicalEntries', 'action' => 'index']) ?>"
          method="POST"
          data-data-table-name="LexicalEntries"
          data-token-container="#lexicalEntriesFilterTokens"
          data-ajax-submit="true"
          data-pagination-container=".pagination-container">

        <div class="container-fluid p-0 mb-0">
            <div class="row mb-2">
                <div class="col-12">
                    <!-- Search Q input with diacritics button -->
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <div class="btn-group" data-bs-toggle="tooltip" data-bs-placement="top" title="Insert accent">
                                <a href="#" class="btn btn-outline-dark bg-info text-dark">?</a>
                                <button type="button" class="btn btn-outline-secondary btn-diacritic" data-mark="́ ">
                                    <img alt="acute" src="/img/acute-comb-char.svg">
                                </button>
                            </div>
                        </div>
                        <?= $this->Form->control('search_q', [
                            'label' => false,
                            'placeholder' => 'Search words...',
                            'value' => $searchOptions['search_q'] ?? '',
                            'class' => 'form-control',
                            'type' => 'text'
                        ]) ?>
                    </div>
                </div>
            </div>

            <div class="row mb-2">
                <!-- Language ID -->
                <div class="col-md-3 col-6">
                    <?= $this->Form->control('language_id', [
                        'options' => [
                            1 => 'Secwepemc',
                            2 => 'English',
                            3 => 'Both'
                        ],
                        'value' => $searchOptions['language_id'] ?? 3,
                        'label' => false,
                        'class' => 'form-select form-select-sm'
                    ]) ?>
                </div>

                <!-- Media Option -->
                <div class="col-md-3 col-6">
                    <?= $this->Form->control('media_option', [
                        'options' => [
                            'all' => 'All',
                            'has_any' => 'Has Media',
                            'has_none' => 'No Media',
                            'has_img' => 'Has Image',
                            'no_img' => 'No Image',
                            'has_sound' => 'Has Sound',
                            'no_sound' => 'No Sound',
                        ],
                        'value' => $searchOptions['media_option'] ?? 'all',
                        'label' => false,
                        'class' => 'form-select form-select-sm'
                    ]) ?>
                </div>

                <!-- Part of Speech -->
                <div class="col-md-3 col-6">
                    <?= $this->Form->control('search_part_of_speech', [
                        'options' => [
                            'all' => 'All',
                            'Adjective' => 'Adjective',
                            'Adverb' => 'Adverb',
                            'Noun' => 'Noun',
                            'Verb' => 'Verb',
                            'Interjection' => 'Interjection',
                            'Conjunction' => 'Conjunction',
                            'Pronouns' => 'Pronouns',
                            'Interrogative' => 'Interrogative',
                            'Preposition' => 'Preposition',
                            'Deictic' => 'Deictic',
                            'Negative' => 'Negative',
                        ],
                        'value' => $searchOptions['search_part_of_speech'] ?? 'all',
                        'label' => false,
                        'class' => 'form-select form-select-sm'
                    ]) ?>
                </div>

                <!-- Submit button -->
                <div class="col-md-3 col-6 text-end">
                    <button type="submit" class="btn btn-primary btn-sm mt-1">
                        <i class="bi bi-search"></i> Search
                    </button>
                </div>
            </div>

            <div class="row mb-2">
                <!-- Modified Date Range -->
                <div class="col-md-3 col-6">
                    <?= $this->Form->control('search_modified_after', [
                        'type' => 'date',
                        'value' => $searchOptions['search_modified_after'] ?? '',
                        'label' => 'Modified After',
                        'class' => 'form-control form-control-sm'
                    ]) ?>
                </div>

                <div class="col-md-3 col-6">
                    <?= $this->Form->control('search_modified_before', [
                        'type' => 'date',
                        'value' => $searchOptions['search_modified_before'] ?? '',
                        'label' => 'Modified Before',
                        'class' => 'form-control form-control-sm'
                    ]) ?>
                </div>

                <!-- Created Date Range -->
                <div class="col-md-3 col-6">
                    <?= $this->Form->control('search_created_after', [
                        'type' => 'date',
                        'value' => $searchOptions['search_created_after'] ?? '',
                        'label' => 'Created After',
                        'class' => 'form-control form-control-sm'
                    ]) ?>
                </div>

                <div class="col-md-3 col-6">
                    <?= $this->Form->control('search_created_before', [
                        'type' => 'date',
                        'value' => $searchOptions['search_created_before'] ?? '',
                        'label' => 'Created Before',
                        'class' => 'form-control form-control-sm'
                    ]) ?>
                </div>
            </div>

            <!-- Hidden pagination state -->
            <?= $this->Form->hidden('page', ['value' => $searchOptions['page'] ?? 1]) ?>
            <?= $this->Form->hidden('limit', ['value' => $searchOptions['limit'] ?? 20]) ?>
            <?= $this->Form->hidden('sort', ['value' => $searchOptions['sort'] ?? 'LexicalEntries.modified']) ?>
            <?= $this->Form->hidden('direction', ['value' => $searchOptions['direction'] ?? 'desc']) ?>

        </div>
    </form>

    <!-- Filter Tokens Panel -->
    <div id="lexicalEntriesFilterTokens"
         class="filter-tokens-panel mt-2 border rounded p-2"
         data-data-table-name="LexicalEntries">
        <!-- Tokens inserted dynamically -->
    </div>
</div>
