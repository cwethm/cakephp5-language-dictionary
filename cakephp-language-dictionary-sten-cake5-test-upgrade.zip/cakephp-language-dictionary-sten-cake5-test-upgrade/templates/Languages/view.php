<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $language
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Language'), ['action' => 'edit', $language->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Language'), ['action' => 'delete', $language->id], ['confirm' => __('Are you sure you want to delete # {0}?', $language->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Languages'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Language'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="languages view content">
            <h3><?= h($language->name) ?></h3>
            <table>
                <tr>
                    <th><?= __('Name') ?></th>
                    <td><?= h($language->name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Abbreviation') ?></th>
                    <td><?= h($language->abbreviation) ?></td>
                </tr>
                <tr>
                    <th><?= __('Letters') ?></th>
                    <td><?= h($language->letters) ?></td>
                </tr>
                <tr>
                    <th><?= __('Keyboard Characters') ?></th>
                    <td><?= h($language->keyboard_characters) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($language->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($language->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($language->modified) ?></td>
                </tr>
            </table>
            <div class="related">
                <h4><?= __('Related Dictionaries') ?></h4>
                <?php if (!empty($language->dictionaries)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('User Id') ?></th>
                            <th><?= __('Slug') ?></th>
                            <th><?= __('Tag Count') ?></th>
                            <th><?= __('Name') ?></th>
                            <th><?= __('Description') ?></th>
                            <th><?= __('Created') ?></th>
                            <th><?= __('Modified') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($language->dictionaries as $dictionary) : ?>
                        <tr>
                            <td><?= h($dictionary->id) ?></td>
                            <td><?= h($dictionary->user_id) ?></td>
                            <td><?= h($dictionary->slug) ?></td>
                            <td><?= h($dictionary->tag_count) ?></td>
                            <td><?= h($dictionary->name) ?></td>
                            <td><?= h($dictionary->description) ?></td>
                            <td><?= h($dictionary->created) ?></td>
                            <td><?= h($dictionary->modified) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'Dictionaries', 'action' => 'view', $dictionary->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'Dictionaries', 'action' => 'edit', $dictionary->id]) ?>
                                <?= $this->Form->postLink(
                                    __('Delete'),
                                    ['controller' => 'Dictionaries', 'action' => 'delete', $dictionary->id],
                                    [
                                        'method' => 'delete',
                                        'confirm' => __('Are you sure you want to delete # {0}?', $dictionary->id),
                                    ]
                                ) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            <div class="related">
                <h4><?= __('Related Forms') ?></h4>
                <?php if (!empty($language->forms)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Lexical Entry Id') ?></th>
                            <th><?= __('Language Id') ?></th>
                            <th><?= __('Form Type') ?></th>
                            <th><?= __('Written Representation') ?></th>
                            <th><?= __('Slug') ?></th>
                            <th><?= __('Created') ?></th>
                            <th><?= __('Modified') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($language->forms as $form) : ?>
                        <tr>
                            <td><?= h($form->id) ?></td>
                            <td><?= h($form->lexical_entry_id) ?></td>
                            <td><?= h($form->language_id) ?></td>
                            <td><?= h($form->form_type) ?></td>
                            <td><?= h($form->written_representation) ?></td>
                            <td><?= h($form->slug) ?></td>
                            <td><?= h($form->created) ?></td>
                            <td><?= h($form->modified) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'Forms', 'action' => 'view', $form->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'Forms', 'action' => 'edit', $form->id]) ?>
                                <?= $this->Form->postLink(
                                    __('Delete'),
                                    ['controller' => 'Forms', 'action' => 'delete', $form->id],
                                    [
                                        'method' => 'delete',
                                        'confirm' => __('Are you sure you want to delete # {0}?', $form->id),
                                    ]
                                ) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            <div class="related">
                <h4><?= __('Related Lexical Entries') ?></h4>
                <?php if (!empty($language->lexical_entries)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Slug') ?></th>
                            <th><?= __('Entry Type') ?></th>
                            <th><?= __('Name') ?></th>
                            <th><?= __('Translated') ?></th>
                            <th><?= __('Part Of Speech') ?></th>
                            <th><?= __('Language Id') ?></th>
                            <th><?= __('Coverimg') ?></th>
                            <th><?= __('Coversound') ?></th>
                            <th><?= __('Tag Count') ?></th>
                            <th><?= __('Trashed') ?></th>
                            <th><?= __('User Id') ?></th>
                            <th><?= __('Created By') ?></th>
                            <th><?= __('Modified By') ?></th>
                            <th><?= __('Created') ?></th>
                            <th><?= __('Modified') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($language->lexical_entries as $lexicalEntry) : ?>
                        <tr>
                            <td><?= h($lexicalEntry->id) ?></td>
                            <td><?= h($lexicalEntry->slug) ?></td>
                            <td><?= h($lexicalEntry->entry_type) ?></td>
                            <td><?= h($lexicalEntry->name) ?></td>
                            <td><?= h($lexicalEntry->translated) ?></td>
                            <td><?= h($lexicalEntry->part_of_speech) ?></td>
                            <td><?= h($lexicalEntry->language_id) ?></td>
                            <td><?= h($lexicalEntry->coverimg) ?></td>
                            <td><?= h($lexicalEntry->coversound) ?></td>
                            <td><?= h($lexicalEntry->tag_count) ?></td>
                            <td><?= h($lexicalEntry->trashed) ?></td>
                            <td><?= h($lexicalEntry->user_id) ?></td>
                            <td><?= h($lexicalEntry->created_by) ?></td>
                            <td><?= h($lexicalEntry->modified_by) ?></td>
                            <td><?= h($lexicalEntry->created) ?></td>
                            <td><?= h($lexicalEntry->modified) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'LexicalEntries', 'action' => 'view', $lexicalEntry->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'LexicalEntries', 'action' => 'edit', $lexicalEntry->id]) ?>
                                <?= $this->Form->postLink(
                                    __('Delete'),
                                    ['controller' => 'LexicalEntries', 'action' => 'delete', $lexicalEntry->id],
                                    [
                                        'method' => 'delete',
                                        'confirm' => __('Are you sure you want to delete # {0}?', $lexicalEntry->id),
                                    ]
                                ) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            <div class="related">
                <h4><?= __('Related Synonyms') ?></h4>
                <?php if (!empty($language->synonyms)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Slug') ?></th>
                            <th><?= __('Dictionary Id') ?></th>
                            <th><?= __('Language Id') ?></th>
                            <th><?= __('Approved') ?></th>
                            <th><?= __('Initial Primary') ?></th>
                            <th><?= __('Word Id') ?></th>
                            <th><?= __('Synonym') ?></th>
                            <th><?= __('Created By') ?></th>
                            <th><?= __('Modified By') ?></th>
                            <th><?= __('Created') ?></th>
                            <th><?= __('Modified') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($language->synonyms as $synonym) : ?>
                        <tr>
                            <td><?= h($synonym->id) ?></td>
                            <td><?= h($synonym->slug) ?></td>
                            <td><?= h($synonym->dictionary_id) ?></td>
                            <td><?= h($synonym->language_id) ?></td>
                            <td><?= h($synonym->approved) ?></td>
                            <td><?= h($synonym->initial_primary) ?></td>
                            <td><?= h($synonym->word_id) ?></td>
                            <td><?= h($synonym->synonym) ?></td>
                            <td><?= h($synonym->created_by) ?></td>
                            <td><?= h($synonym->modified_by) ?></td>
                            <td><?= h($synonym->created) ?></td>
                            <td><?= h($synonym->modified) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'Synonyms', 'action' => 'view', $synonym->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'Synonyms', 'action' => 'edit', $synonym->id]) ?>
                                <?= $this->Form->postLink(
                                    __('Delete'),
                                    ['controller' => 'Synonyms', 'action' => 'delete', $synonym->id],
                                    [
                                        'method' => 'delete',
                                        'confirm' => __('Are you sure you want to delete # {0}?', $synonym->id),
                                    ]
                                ) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>