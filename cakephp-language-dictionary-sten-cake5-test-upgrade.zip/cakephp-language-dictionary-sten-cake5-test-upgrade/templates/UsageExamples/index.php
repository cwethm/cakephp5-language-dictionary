<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\Cake\Datasource\EntityInterface> $usageExamples
 */
?>
<div class="usageExamples index content">
    <?= $this->Html->link(__('New Usage Example'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Usage Examples') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('sense_id') ?></th>
                    <th><?= $this->Paginator->sort('language_id') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($usageExamples as $usageExample): ?>
                <tr>
                    <td><?= $this->Number->format($usageExample->id) ?></td>
                    <td><?= $usageExample->hasValue('sense') ? $this->Html->link($usageExample->sense->id, ['controller' => 'Senses', 'action' => 'view', $usageExample->sense->id]) : '' ?></td>
                    <td><?= $usageExample->hasValue('language') ? $this->Html->link($usageExample->language->name, ['controller' => 'Languages', 'action' => 'view', $usageExample->language->id]) : '' ?></td>
                    <td><?= h($usageExample->created) ?></td>
                    <td><?= h($usageExample->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $usageExample->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $usageExample->id]) ?>
                        <?= $this->Form->postLink(
                            __('Delete'),
                            ['action' => 'delete', $usageExample->id],
                            [
                                'method' => 'delete',
                                'confirm' => __('Are you sure you want to delete # {0}?', $usageExample->id),
                            ]
                        ) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>