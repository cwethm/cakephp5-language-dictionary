<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $usageExample
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Usage Example'), ['action' => 'edit', $usageExample->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Usage Example'), ['action' => 'delete', $usageExample->id], ['confirm' => __('Are you sure you want to delete # {0}?', $usageExample->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Usage Examples'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Usage Example'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="usageExamples view content">
            <h3><?= h($usageExample->id) ?></h3>
            <table>
                <tr>
                    <th><?= __('Sense') ?></th>
                    <td><?= $usageExample->hasValue('sense') ? $this->Html->link($usageExample->sense->id, ['controller' => 'Senses', 'action' => 'view', $usageExample->sense->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Language') ?></th>
                    <td><?= $usageExample->hasValue('language') ? $this->Html->link($usageExample->language->name, ['controller' => 'Languages', 'action' => 'view', $usageExample->language->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($usageExample->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($usageExample->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($usageExample->modified) ?></td>
                </tr>
            </table>
            <div class="text">
                <strong><?= __('Example Text') ?></strong>
                <blockquote>
                    <?= $this->Text->autoParagraph(h($usageExample->example_text)); ?>
                </blockquote>
            </div>
        </div>
    </div>
</div>