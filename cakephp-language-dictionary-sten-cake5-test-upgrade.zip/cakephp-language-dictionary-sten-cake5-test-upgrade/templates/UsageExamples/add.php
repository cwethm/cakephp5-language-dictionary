<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $usageExample
 * @var \Cake\Collection\CollectionInterface|string[] $senses
 * @var \Cake\Collection\CollectionInterface|string[] $languages
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('List Usage Examples'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="usageExamples form content">
            <?= $this->Form->create($usageExample) ?>
            <fieldset>
                <legend><?= __('Add Usage Example') ?></legend>
                <?php
                    echo $this->Form->control('sense_id', ['options' => $senses]);
                    echo $this->Form->control('example_text');
                    echo $this->Form->control('language_id', ['options' => $languages, 'empty' => true]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
