<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\Cake\Datasource\EntityInterface> $lemonAttributes
 */
?>
<div class="lemonAttributes index content">
    <?= $this->Html->link(__('New Lemon Attribute'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Lemon Attributes') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('lemon_class') ?></th>
                    <th><?= $this->Paginator->sort('module') ?></th>
                    <th><?= $this->Paginator->sort('model_class') ?></th>
                    <th><?= $this->Paginator->sort('name') ?></th>
                    <th><?= $this->Paginator->sort('type') ?></th>
                    <th><?= $this->Paginator->sort('entry_type') ?></th>
                    <th><?= $this->Paginator->sort('notes') ?></th>
                    <th><?= $this->Paginator->sort('cardinality_min') ?></th>
                    <th><?= $this->Paginator->sort('cardinality_max') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($lemonAttributes as $lemonAttribute): ?>
                <tr>
                    <td><?= $this->Number->format($lemonAttribute->id) ?></td>
                    <td><?= h($lemonAttribute->lemon_class) ?></td>
                    <td><?= h($lemonAttribute->module) ?></td>
                    <td><?= h($lemonAttribute->model_class) ?></td>
                    <td><?= h($lemonAttribute->name) ?></td>
                    <td><?= h($lemonAttribute->type) ?></td>
                    <td><?= h($lemonAttribute->entry_type) ?></td>
                    <td><?= h($lemonAttribute->notes) ?></td>
                    <td><?= h($lemonAttribute->cardinality_min) ?></td>
                    <td><?= h($lemonAttribute->cardinality_max) ?></td>
                    <td><?= h($lemonAttribute->created) ?></td>
                    <td><?= h($lemonAttribute->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $lemonAttribute->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $lemonAttribute->id]) ?>
                        <?= $this->Form->postLink(
                            __('Delete'),
                            ['action' => 'delete', $lemonAttribute->id],
                            [
                                'method' => 'delete',
                                'confirm' => __('Are you sure you want to delete # {0}?', $lemonAttribute->id),
                            ]
                        ) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>