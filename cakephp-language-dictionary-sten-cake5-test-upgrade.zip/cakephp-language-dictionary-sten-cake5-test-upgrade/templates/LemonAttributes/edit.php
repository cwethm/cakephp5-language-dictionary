<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $lemonAttribute
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', $lemonAttribute->id],
                ['confirm' => __('Are you sure you want to delete # {0}?', $lemonAttribute->id), 'class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List Lemon Attributes'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="lemonAttributes form content">
            <?= $this->Form->create($lemonAttribute) ?>
            <fieldset>
                <legend><?= __('Edit Lemon Attribute') ?></legend>
                <?php
                    echo $this->Form->control('lemon_class');
                    echo $this->Form->control('module');
                    echo $this->Form->control('model_class');
                    echo $this->Form->control('name');
                    echo $this->Form->control('type');
                    echo $this->Form->control('entry_type');
                    echo $this->Form->control('notes');
                    echo $this->Form->control('cardinality_min');
                    echo $this->Form->control('cardinality_max');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
