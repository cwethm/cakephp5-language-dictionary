<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $lemonAttribute
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Lemon Attribute'), ['action' => 'edit', $lemonAttribute->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Lemon Attribute'), ['action' => 'delete', $lemonAttribute->id], ['confirm' => __('Are you sure you want to delete # {0}?', $lemonAttribute->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Lemon Attributes'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Lemon Attribute'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="lemonAttributes view content">
            <h3><?= h($lemonAttribute->name) ?></h3>
            <table>
                <tr>
                    <th><?= __('Lemon Class') ?></th>
                    <td><?= h($lemonAttribute->lemon_class) ?></td>
                </tr>
                <tr>
                    <th><?= __('Module') ?></th>
                    <td><?= h($lemonAttribute->module) ?></td>
                </tr>
                <tr>
                    <th><?= __('Model Class') ?></th>
                    <td><?= h($lemonAttribute->model_class) ?></td>
                </tr>
                <tr>
                    <th><?= __('Name') ?></th>
                    <td><?= h($lemonAttribute->name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Type') ?></th>
                    <td><?= h($lemonAttribute->type) ?></td>
                </tr>
                <tr>
                    <th><?= __('Entry Type') ?></th>
                    <td><?= h($lemonAttribute->entry_type) ?></td>
                </tr>
                <tr>
                    <th><?= __('Notes') ?></th>
                    <td><?= h($lemonAttribute->notes) ?></td>
                </tr>
                <tr>
                    <th><?= __('Cardinality Min') ?></th>
                    <td><?= h($lemonAttribute->cardinality_min) ?></td>
                </tr>
                <tr>
                    <th><?= __('Cardinality Max') ?></th>
                    <td><?= h($lemonAttribute->cardinality_max) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($lemonAttribute->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($lemonAttribute->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($lemonAttribute->modified) ?></td>
                </tr>
            </table>
            <div class="related">
                <h4><?= __('Related Ld Properties') ?></h4>
                <?php if (!empty($lemonAttribute->ld_properties)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Linguistic Description Id') ?></th>
                            <th><?= __('Lemon Attribute Id') ?></th>
                            <th><?= __('Value') ?></th>
                            <th><?= __('Created') ?></th>
                            <th><?= __('Modified') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($lemonAttribute->ld_properties as $ldProperty) : ?>
                        <tr>
                            <td><?= h($ldProperty->id) ?></td>
                            <td><?= h($ldProperty->linguistic_description_id) ?></td>
                            <td><?= h($ldProperty->lemon_attribute_id) ?></td>
                            <td><?= h($ldProperty->value) ?></td>
                            <td><?= h($ldProperty->created) ?></td>
                            <td><?= h($ldProperty->modified) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'LdProperties', 'action' => 'view', $ldProperty->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'LdProperties', 'action' => 'edit', $ldProperty->id]) ?>
                                <?= $this->Form->postLink(
                                    __('Delete'),
                                    ['controller' => 'LdProperties', 'action' => 'delete', $ldProperty->id],
                                    [
                                        'method' => 'delete',
                                        'confirm' => __('Are you sure you want to delete # {0}?', $ldProperty->id),
                                    ]
                                ) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            <div class="related">
                <h4><?= __('Related Lemon Value Sets') ?></h4>
                <?php if (!empty($lemonAttribute->lemon_value_sets)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Lemon Attribute Id') ?></th>
                            <th><?= __('Set Name') ?></th>
                            <th><?= __('Name') ?></th>
                            <th><?= __('Label') ?></th>
                            <th><?= __('Created') ?></th>
                            <th><?= __('Modified') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($lemonAttribute->lemon_value_sets as $lemonValueSet) : ?>
                        <tr>
                            <td><?= h($lemonValueSet->id) ?></td>
                            <td><?= h($lemonValueSet->lemon_attribute_id) ?></td>
                            <td><?= h($lemonValueSet->set_name) ?></td>
                            <td><?= h($lemonValueSet->name) ?></td>
                            <td><?= h($lemonValueSet->label) ?></td>
                            <td><?= h($lemonValueSet->created) ?></td>
                            <td><?= h($lemonValueSet->modified) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'LemonValueSets', 'action' => 'view', $lemonValueSet->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'LemonValueSets', 'action' => 'edit', $lemonValueSet->id]) ?>
                                <?= $this->Form->postLink(
                                    __('Delete'),
                                    ['controller' => 'LemonValueSets', 'action' => 'delete', $lemonValueSet->id],
                                    [
                                        'method' => 'delete',
                                        'confirm' => __('Are you sure you want to delete # {0}?', $lemonValueSet->id),
                                    ]
                                ) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            <div class="related">
                <h4><?= __('Related Linguistic Descriptions') ?></h4>
                <?php if (!empty($lemonAttribute->linguistic_descriptions)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Lexical Entry Id') ?></th>
                            <th><?= __('Sense Id') ?></th>
                            <th><?= __('Form Id') ?></th>
                            <th><?= __('Lemon Attribute Id') ?></th>
                            <th><?= __('Value') ?></th>
                            <th><?= __('Created') ?></th>
                            <th><?= __('Modified') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($lemonAttribute->linguistic_descriptions as $linguisticDescription) : ?>
                        <tr>
                            <td><?= h($linguisticDescription->id) ?></td>
                            <td><?= h($linguisticDescription->lexical_entry_id) ?></td>
                            <td><?= h($linguisticDescription->sense_id) ?></td>
                            <td><?= h($linguisticDescription->form_id) ?></td>
                            <td><?= h($linguisticDescription->lemon_attribute_id) ?></td>
                            <td><?= h($linguisticDescription->value) ?></td>
                            <td><?= h($linguisticDescription->created) ?></td>
                            <td><?= h($linguisticDescription->modified) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'LinguisticDescriptions', 'action' => 'view', $linguisticDescription->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'LinguisticDescriptions', 'action' => 'edit', $linguisticDescription->id]) ?>
                                <?= $this->Form->postLink(
                                    __('Delete'),
                                    ['controller' => 'LinguisticDescriptions', 'action' => 'delete', $linguisticDescription->id],
                                    [
                                        'method' => 'delete',
                                        'confirm' => __('Are you sure you want to delete # {0}?', $linguisticDescription->id),
                                    ]
                                ) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            <div class="related">
                <h4><?= __('Related Linguistic Links') ?></h4>
                <?php if (!empty($lemonAttribute->linguistic_links)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Lexical Entry Id') ?></th>
                            <th><?= __('Fk Id') ?></th>
                            <th><?= __('LinkedModel') ?></th>
                            <th><?= __('Lemon Attribute Id') ?></th>
                            <th><?= __('Created') ?></th>
                            <th><?= __('Modified') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($lemonAttribute->linguistic_links as $linguisticLink) : ?>
                        <tr>
                            <td><?= h($linguisticLink->id) ?></td>
                            <td><?= h($linguisticLink->lexical_entry_id) ?></td>
                            <td><?= h($linguisticLink->fk_id) ?></td>
                            <td><?= h($linguisticLink->LinkedModel) ?></td>
                            <td><?= h($linguisticLink->lemon_attribute_id) ?></td>
                            <td><?= h($linguisticLink->created) ?></td>
                            <td><?= h($linguisticLink->modified) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'LinguisticLinks', 'action' => 'view', $linguisticLink->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'LinguisticLinks', 'action' => 'edit', $linguisticLink->id]) ?>
                                <?= $this->Form->postLink(
                                    __('Delete'),
                                    ['controller' => 'LinguisticLinks', 'action' => 'delete', $linguisticLink->id],
                                    [
                                        'method' => 'delete',
                                        'confirm' => __('Are you sure you want to delete # {0}?', $linguisticLink->id),
                                    ]
                                ) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>