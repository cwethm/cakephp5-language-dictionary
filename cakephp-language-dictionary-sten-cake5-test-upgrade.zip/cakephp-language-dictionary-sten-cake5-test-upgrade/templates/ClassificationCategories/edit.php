<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $classificationCategory
 * @var string[]|\Cake\Collection\CollectionInterface $parentClassificationCategories
 * @var string[]|\Cake\Collection\CollectionInterface $senses
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', $classificationCategory->id],
                ['confirm' => __('Are you sure you want to delete # {0}?', $classificationCategory->id), 'class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List Classification Categories'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="classificationCategories form content">
            <?= $this->Form->create($classificationCategory) ?>
            <fieldset>
                <legend><?= __('Edit Classification Category') ?></legend>
                <?php
                    echo $this->Form->control('parent_id', ['options' => $parentClassificationCategories, 'empty' => true]);
                    echo $this->Form->control('name');
                    echo $this->Form->control('senses._ids', ['options' => $senses]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
