<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\Cake\Datasource\EntityInterface> $classificationCategories
 */
?>
<div class="classificationCategories index content">
    <?= $this->Html->link(__('New Classification Category'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Classification Categories') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('parent_id') ?></th>
                    <th><?= $this->Paginator->sort('name') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($classificationCategories as $classificationCategory): ?>
                <tr>
                    <td><?= $this->Number->format($classificationCategory->id) ?></td>
                    <td><?= $classificationCategory->hasValue('parent_classification_category') ? $this->Html->link($classificationCategory->parent_classification_category->name, ['controller' => 'ClassificationCategories', 'action' => 'view', $classificationCategory->parent_classification_category->id]) : '' ?></td>
                    <td><?= h($classificationCategory->name) ?></td>
                    <td><?= h($classificationCategory->created) ?></td>
                    <td><?= h($classificationCategory->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $classificationCategory->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $classificationCategory->id]) ?>
                        <?= $this->Form->postLink(
                            __('Delete'),
                            ['action' => 'delete', $classificationCategory->id],
                            [
                                'method' => 'delete',
                                'confirm' => __('Are you sure you want to delete # {0}?', $classificationCategory->id),
                            ]
                        ) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>