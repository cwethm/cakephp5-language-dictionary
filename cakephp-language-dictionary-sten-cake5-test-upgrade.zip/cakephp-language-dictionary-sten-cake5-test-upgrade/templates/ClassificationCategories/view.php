<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $classificationCategory
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Classification Category'), ['action' => 'edit', $classificationCategory->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Classification Category'), ['action' => 'delete', $classificationCategory->id], ['confirm' => __('Are you sure you want to delete # {0}?', $classificationCategory->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Classification Categories'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Classification Category'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="classificationCategories view content">
            <h3><?= h($classificationCategory->name) ?></h3>
            <table>
                <tr>
                    <th><?= __('Parent Classification Category') ?></th>
                    <td><?= $classificationCategory->hasValue('parent_classification_category') ? $this->Html->link($classificationCategory->parent_classification_category->name, ['controller' => 'ClassificationCategories', 'action' => 'view', $classificationCategory->parent_classification_category->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Name') ?></th>
                    <td><?= h($classificationCategory->name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($classificationCategory->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Lft') ?></th>
                    <td><?= $classificationCategory->lft === null ? '' : $this->Number->format($classificationCategory->lft) ?></td>
                </tr>
                <tr>
                    <th><?= __('Rght') ?></th>
                    <td><?= $classificationCategory->rght === null ? '' : $this->Number->format($classificationCategory->rght) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($classificationCategory->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($classificationCategory->modified) ?></td>
                </tr>
            </table>
            <div class="related">
                <h4><?= __('Related Senses') ?></h4>
                <?php if (!empty($classificationCategory->senses)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Lexical Entry Id') ?></th>
                            <th><?= __('Slug') ?></th>
                            <th><?= __('Entry Name') ?></th>
                            <th><?= __('Definition') ?></th>
                            <th><?= __('Coverimg') ?></th>
                            <th><?= __('Coversnd') ?></th>
                            <th><?= __('Reference') ?></th>
                            <th><?= __('Created') ?></th>
                            <th><?= __('Modified') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($classificationCategory->senses as $sense) : ?>
                        <tr>
                            <td><?= h($sense->id) ?></td>
                            <td><?= h($sense->lexical_entry_id) ?></td>
                            <td><?= h($sense->slug) ?></td>
                            <td><?= h($sense->entry_name) ?></td>
                            <td><?= h($sense->definition) ?></td>
                            <td><?= h($sense->coverimg) ?></td>
                            <td><?= h($sense->coversnd) ?></td>
                            <td><?= h($sense->reference) ?></td>
                            <td><?= h($sense->created) ?></td>
                            <td><?= h($sense->modified) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'Senses', 'action' => 'view', $sense->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'Senses', 'action' => 'edit', $sense->id]) ?>
                                <?= $this->Form->postLink(
                                    __('Delete'),
                                    ['controller' => 'Senses', 'action' => 'delete', $sense->id],
                                    [
                                        'method' => 'delete',
                                        'confirm' => __('Are you sure you want to delete # {0}?', $sense->id),
                                    ]
                                ) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            <div class="related">
                <h4><?= __('Related Classification Categories') ?></h4>
                <?php if (!empty($classificationCategory->child_classification_categories)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Lft') ?></th>
                            <th><?= __('Rght') ?></th>
                            <th><?= __('Parent Id') ?></th>
                            <th><?= __('Name') ?></th>
                            <th><?= __('Created') ?></th>
                            <th><?= __('Modified') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($classificationCategory->child_classification_categories as $childClassificationCategory) : ?>
                        <tr>
                            <td><?= h($childClassificationCategory->id) ?></td>
                            <td><?= h($childClassificationCategory->lft) ?></td>
                            <td><?= h($childClassificationCategory->rght) ?></td>
                            <td><?= h($childClassificationCategory->parent_id) ?></td>
                            <td><?= h($childClassificationCategory->name) ?></td>
                            <td><?= h($childClassificationCategory->created) ?></td>
                            <td><?= h($childClassificationCategory->modified) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'ClassificationCategories', 'action' => 'view', $childClassificationCategory->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'ClassificationCategories', 'action' => 'edit', $childClassificationCategory->id]) ?>
                                <?= $this->Form->postLink(
                                    __('Delete'),
                                    ['controller' => 'ClassificationCategories', 'action' => 'delete', $childClassificationCategory->id],
                                    [
                                        'method' => 'delete',
                                        'confirm' => __('Are you sure you want to delete # {0}?', $childClassificationCategory->id),
                                    ]
                                ) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>