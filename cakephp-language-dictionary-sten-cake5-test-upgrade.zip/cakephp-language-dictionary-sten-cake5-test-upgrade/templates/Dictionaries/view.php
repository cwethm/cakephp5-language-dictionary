<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $dictionary
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Dictionary'), ['action' => 'edit', $dictionary->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Dictionary'), ['action' => 'delete', $dictionary->id], ['confirm' => __('Are you sure you want to delete # {0}?', $dictionary->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Dictionaries'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Dictionary'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="dictionaries view content">
            <h3><?= h($dictionary->name) ?></h3>
            <table>
                <tr>
                    <th><?= __('User') ?></th>
                    <td><?= $dictionary->hasValue('user') ? $this->Html->link($dictionary->user->id, ['controller' => 'Users', 'action' => 'view', $dictionary->user->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Slug') ?></th>
                    <td><?= h($dictionary->slug) ?></td>
                </tr>
                <tr>
                    <th><?= __('Name') ?></th>
                    <td><?= h($dictionary->name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($dictionary->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Tag Count') ?></th>
                    <td><?= $dictionary->tag_count === null ? '' : $this->Number->format($dictionary->tag_count) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($dictionary->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($dictionary->modified) ?></td>
                </tr>
            </table>
            <div class="text">
                <strong><?= __('Description') ?></strong>
                <blockquote>
                    <?= $this->Text->autoParagraph(h($dictionary->description)); ?>
                </blockquote>
            </div>
            <div class="related">
                <h4><?= __('Related Languages') ?></h4>
                <?php if (!empty($dictionary->languages)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Name') ?></th>
                            <th><?= __('Abbreviation') ?></th>
                            <th><?= __('Letters') ?></th>
                            <th><?= __('Keyboard Characters') ?></th>
                            <th><?= __('Created') ?></th>
                            <th><?= __('Modified') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($dictionary->languages as $language) : ?>
                        <tr>
                            <td><?= h($language->id) ?></td>
                            <td><?= h($language->name) ?></td>
                            <td><?= h($language->abbreviation) ?></td>
                            <td><?= h($language->letters) ?></td>
                            <td><?= h($language->keyboard_characters) ?></td>
                            <td><?= h($language->created) ?></td>
                            <td><?= h($language->modified) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'Languages', 'action' => 'view', $language->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'Languages', 'action' => 'edit', $language->id]) ?>
                                <?= $this->Form->postLink(
                                    __('Delete'),
                                    ['controller' => 'Languages', 'action' => 'delete', $language->id],
                                    [
                                        'method' => 'delete',
                                        'confirm' => __('Are you sure you want to delete # {0}?', $language->id),
                                    ]
                                ) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            <div class="related">
                <h4><?= __('Related Lexical Entries') ?></h4>
                <?php if (!empty($dictionary->lexical_entries)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Slug') ?></th>
                            <th><?= __('Entry Type') ?></th>
                            <th><?= __('Name') ?></th>
                            <th><?= __('Translated') ?></th>
                            <th><?= __('Part Of Speech') ?></th>
                            <th><?= __('Language Id') ?></th>
                            <th><?= __('Coverimg') ?></th>
                            <th><?= __('Coversound') ?></th>
                            <th><?= __('Tag Count') ?></th>
                            <th><?= __('Trashed') ?></th>
                            <th><?= __('User Id') ?></th>
                            <th><?= __('Created By') ?></th>
                            <th><?= __('Modified By') ?></th>
                            <th><?= __('Created') ?></th>
                            <th><?= __('Modified') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($dictionary->lexical_entries as $lexicalEntry) : ?>
                        <tr>
                            <td><?= h($lexicalEntry->id) ?></td>
                            <td><?= h($lexicalEntry->slug) ?></td>
                            <td><?= h($lexicalEntry->entry_type) ?></td>
                            <td><?= h($lexicalEntry->name) ?></td>
                            <td><?= h($lexicalEntry->translated) ?></td>
                            <td><?= h($lexicalEntry->part_of_speech) ?></td>
                            <td><?= h($lexicalEntry->language_id) ?></td>
                            <td><?= h($lexicalEntry->coverimg) ?></td>
                            <td><?= h($lexicalEntry->coversound) ?></td>
                            <td><?= h($lexicalEntry->tag_count) ?></td>
                            <td><?= h($lexicalEntry->trashed) ?></td>
                            <td><?= h($lexicalEntry->user_id) ?></td>
                            <td><?= h($lexicalEntry->created_by) ?></td>
                            <td><?= h($lexicalEntry->modified_by) ?></td>
                            <td><?= h($lexicalEntry->created) ?></td>
                            <td><?= h($lexicalEntry->modified) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'LexicalEntries', 'action' => 'view', $lexicalEntry->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'LexicalEntries', 'action' => 'edit', $lexicalEntry->id]) ?>
                                <?= $this->Form->postLink(
                                    __('Delete'),
                                    ['controller' => 'LexicalEntries', 'action' => 'delete', $lexicalEntry->id],
                                    [
                                        'method' => 'delete',
                                        'confirm' => __('Are you sure you want to delete # {0}?', $lexicalEntry->id),
                                    ]
                                ) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            <div class="related">
                <h4><?= __('Related Synonyms') ?></h4>
                <?php if (!empty($dictionary->synonyms)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Slug') ?></th>
                            <th><?= __('Dictionary Id') ?></th>
                            <th><?= __('Language Id') ?></th>
                            <th><?= __('Approved') ?></th>
                            <th><?= __('Initial Primary') ?></th>
                            <th><?= __('Word Id') ?></th>
                            <th><?= __('Synonym') ?></th>
                            <th><?= __('Created By') ?></th>
                            <th><?= __('Modified By') ?></th>
                            <th><?= __('Created') ?></th>
                            <th><?= __('Modified') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($dictionary->synonyms as $synonym) : ?>
                        <tr>
                            <td><?= h($synonym->id) ?></td>
                            <td><?= h($synonym->slug) ?></td>
                            <td><?= h($synonym->dictionary_id) ?></td>
                            <td><?= h($synonym->language_id) ?></td>
                            <td><?= h($synonym->approved) ?></td>
                            <td><?= h($synonym->initial_primary) ?></td>
                            <td><?= h($synonym->word_id) ?></td>
                            <td><?= h($synonym->synonym) ?></td>
                            <td><?= h($synonym->created_by) ?></td>
                            <td><?= h($synonym->modified_by) ?></td>
                            <td><?= h($synonym->created) ?></td>
                            <td><?= h($synonym->modified) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'Synonyms', 'action' => 'view', $synonym->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'Synonyms', 'action' => 'edit', $synonym->id]) ?>
                                <?= $this->Form->postLink(
                                    __('Delete'),
                                    ['controller' => 'Synonyms', 'action' => 'delete', $synonym->id],
                                    [
                                        'method' => 'delete',
                                        'confirm' => __('Are you sure you want to delete # {0}?', $synonym->id),
                                    ]
                                ) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>