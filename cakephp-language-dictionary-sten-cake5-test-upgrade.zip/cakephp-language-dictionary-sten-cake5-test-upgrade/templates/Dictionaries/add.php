<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $dictionary
 * @var \Cake\Collection\CollectionInterface|string[] $users
 * @var \Cake\Collection\CollectionInterface|string[] $languages
 * @var \Cake\Collection\CollectionInterface|string[] $lexicalEntries
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('List Dictionaries'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="dictionaries form content">
            <?= $this->Form->create($dictionary) ?>
            <fieldset>
                <legend><?= __('Add Dictionary') ?></legend>
                <?php
                    echo $this->Form->control('user_id', ['options' => $users]);
                    echo $this->Form->control('slug');
                    echo $this->Form->control('tag_count');
                    echo $this->Form->control('name');
                    echo $this->Form->control('description');
                    echo $this->Form->control('languages._ids', ['options' => $languages]);
                    echo $this->Form->control('lexical_entries._ids', ['options' => $lexicalEntries]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
