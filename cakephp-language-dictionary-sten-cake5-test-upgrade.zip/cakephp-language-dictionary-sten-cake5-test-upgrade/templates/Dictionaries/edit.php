<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface $dictionary
 * @var string[]|\Cake\Collection\CollectionInterface $users
 * @var string[]|\Cake\Collection\CollectionInterface $languages
 * @var string[]|\Cake\Collection\CollectionInterface $lexicalEntries
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', $dictionary->id],
                ['confirm' => __('Are you sure you want to delete # {0}?', $dictionary->id), 'class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List Dictionaries'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="dictionaries form content">
            <?= $this->Form->create($dictionary) ?>
            <fieldset>
                <legend><?= __('Edit Dictionary') ?></legend>
                <?php
                    echo $this->Form->control('user_id', ['options' => $users]);
                    echo $this->Form->control('slug');
                    echo $this->Form->control('tag_count');
                    echo $this->Form->control('name');
                    echo $this->Form->control('description');
                    echo $this->Form->control('languages._ids', ['options' => $languages]);
                    echo $this->Form->control('lexical_entries._ids', ['options' => $lexicalEntries]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
