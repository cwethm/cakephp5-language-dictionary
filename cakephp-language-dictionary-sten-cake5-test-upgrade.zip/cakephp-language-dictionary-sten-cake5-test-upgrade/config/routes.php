<?php
use Cake\Routing\RouteBuilder;
use Cake\Routing\Route\DashedRoute;

return static function (RouteBuilder $routes): void {
    $routes->setRouteClass(DashedRoute::class);

    // Scope all plugin routes under /language-dictionary
    $routes->scope('/language-dictionary', ['plugin' => 'LanguageDictionary'], function (RouteBuilder $builder) {
        $builder->connect('/', ['controller' => 'LexicalEntries', 'action' => 'index']);
        $builder->fallbacks(DashedRoute::class);
    });

    $routes->setExtensions(['csv']);
};
