<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * LanguagesFixture
 */
class LanguagesFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'name' => 'Lorem ipsum dolor sit amet',
                'abbreviation' => 'Lorem ip',
                'letters' => 'Lorem ipsum dolor sit amet',
                'keyboard_characters' => 'Lorem ipsum dolor sit amet',
                'trashed' => '2025-07-12 03:57:36',
                'created' => '2025-07-12 03:57:36',
                'modified' => '2025-07-12 03:57:36',
            ],
        ];
        parent::init();
    }
}
