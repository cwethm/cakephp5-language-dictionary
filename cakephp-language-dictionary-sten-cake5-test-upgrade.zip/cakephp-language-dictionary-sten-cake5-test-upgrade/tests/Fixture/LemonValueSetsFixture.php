<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * LemonValueSetsFixture
 */
class LemonValueSetsFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'lemon_attribute_id' => 1,
                'set_name' => 'Lorem ipsum dolor sit amet',
                'name' => 'Lorem ipsum dolor sit amet',
                'label' => 'Lorem ipsum dolor sit amet',
                'created' => '2025-04-03 15:00:34',
                'modified' => '2025-04-03 15:00:34',
            ],
        ];
        parent::init();
    }
}
