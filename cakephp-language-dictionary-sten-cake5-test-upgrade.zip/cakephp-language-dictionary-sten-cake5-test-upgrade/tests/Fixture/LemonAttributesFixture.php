<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * LemonAttributesFixture
 */
class LemonAttributesFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'uri' => 'Lorem ipsum dolor sit amet',
                'local_name' => 'Lorem ipsum dolor sit amet',
                'model_class' => 'Lorem ipsum dolor sit amet',
                'rdf_datatype' => 'Lorem ipsum dolor sit amet',
                'cardinality_min' => 1,
                'cardinality_max' => 1,
                'description' => 'Lorem ipsum dolor sit amet, aliquet feugiat. Convallis morbi fringilla gravida, phasellus feugiat dapibus velit nunc, pulvinar eget sollicitudin venenatis cum nullam, vivamus ut a sed, mollitia lectus. Nulla vestibulum massa neque ut et, id hendrerit sit, feugiat in taciti enim proin nibh, tempor dignissim, rhoncus duis vestibulum nunc mattis convallis.',
                'created' => '2025-07-13 19:54:15',
                'modified' => '2025-07-13 19:54:15',
                'category' => 'Lorem ipsum dolor sit amet',
                'range_class' => 'Lorem ipsum dolor sit amet',
                'parent_class' => 'Lorem ipsum dolor sit amet',
                'rdfs_label' => 'Lorem ipsum dolor sit amet',
                'rdfs_comment' => 'Lorem ipsum dolor sit amet, aliquet feugiat. Convallis morbi fringilla gravida, phasellus feugiat dapibus velit nunc, pulvinar eget sollicitudin venenatis cum nullam, vivamus ut a sed, mollitia lectus. Nulla vestibulum massa neque ut et, id hendrerit sit, feugiat in taciti enim proin nibh, tempor dignissim, rhoncus duis vestibulum nunc mattis convallis.',
                'rdf_type' => 'Lorem ipsum dolor sit amet',
                'domain_class' => 'Lorem ipsum dolor sit amet',
            ],
        ];
        parent::init();
    }
}
