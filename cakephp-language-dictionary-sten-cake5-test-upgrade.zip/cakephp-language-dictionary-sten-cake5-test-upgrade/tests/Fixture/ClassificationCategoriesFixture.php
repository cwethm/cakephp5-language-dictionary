<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * ClassificationCategoriesFixture
 */
class ClassificationCategoriesFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'lft' => 1,
                'rght' => 1,
                'parent_id' => 1,
                'name' => 'Lorem ipsum dolor sit amet',
                'created' => '2025-04-26 16:28:52',
                'modified' => '2025-04-26 16:28:52',
            ],
        ];
        parent::init();
    }
}
