<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * LexicalEntriesFixture
 */
class LexicalEntriesFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'slug' => 'Lorem ipsum dolor sit amet',
                'entry_type' => 'Lorem ipsum dolor sit amet',
                'name' => 'Lorem ipsum dolor sit amet',
                'translated' => 'Lorem ipsum dolor sit amet',
                'part_of_speech' => 'Lorem ipsum dolor sit amet',
                'language_id' => 1,
                'coverimg' => 1,
                'coversound' => 1,
                'tag_count' => 1,
                'trashed' => '2025-04-03 14:52:36',
                'user_id' => 1,
                'created_by' => 1,
                'modified_by' => 1,
                'created' => '2025-04-03 14:52:36',
                'modified' => '2025-04-03 14:52:36',
            ],
        ];
        parent::init();
    }
}
