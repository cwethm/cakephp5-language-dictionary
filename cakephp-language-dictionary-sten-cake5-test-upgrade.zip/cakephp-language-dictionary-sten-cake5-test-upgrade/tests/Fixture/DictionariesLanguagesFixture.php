<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * DictionariesLanguagesFixture
 */
class DictionariesLanguagesFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'dictionary_id' => 1,
                'language_id' => 1,
            ],
        ];
        parent::init();
    }
}
