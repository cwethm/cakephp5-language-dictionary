<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * FormsFixture
 */
class FormsFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'lexical_entry_id' => 1,
                'language_id' => 1,
                'form_type' => 'Lorem ipsum dolor sit amet',
                'written_representation' => 'Lorem ipsum dolor sit amet',
                'slug' => 'Lorem ipsum dolor sit amet',
                'created' => '2025-04-03 14:52:52',
                'modified' => '2025-04-03 14:52:52',
            ],
        ];
        parent::init();
    }
}
