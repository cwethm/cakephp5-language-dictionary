<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * FlexFieldsFixture
 */
class FlexFieldsFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'slug' => 'Lorem ipsum dolor sit amet',
                'word_id' => 1,
                'flex_key' => 'Lorem ipsum dolor sit amet',
                'flex_value' => 'Lorem ipsum dolor sit amet',
                'second_value' => 'Lorem ipsum dolor sit amet',
                'user_id' => 1,
                'active' => 1,
                'created' => '2025-04-03 15:00:54',
                'modified' => '2025-04-03 15:00:54',
            ],
        ];
        parent::init();
    }
}
