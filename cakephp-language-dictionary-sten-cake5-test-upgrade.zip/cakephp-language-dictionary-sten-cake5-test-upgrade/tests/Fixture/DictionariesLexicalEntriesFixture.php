<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * DictionariesLexicalEntriesFixture
 */
class DictionariesLexicalEntriesFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'dictionary_id' => 1,
                'lexical_entry_id' => 1,
                'created' => '2025-04-03 14:59:37',
                'modified' => '2025-04-03 14:59:37',
            ],
        ];
        parent::init();
    }
}
