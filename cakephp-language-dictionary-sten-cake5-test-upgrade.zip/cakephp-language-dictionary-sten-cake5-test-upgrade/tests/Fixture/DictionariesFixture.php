<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * DictionariesFixture
 */
class DictionariesFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'user_id' => '818adaa6-feca-4c07-9414-abfabcc56ca6',
                'slug' => 'Lorem ipsum dolor sit amet',
                'tag_count' => 1,
                'name' => 'Lorem ipsum dolor sit amet',
                'description' => 'Lorem ipsum dolor sit amet, aliquet feugiat. Convallis morbi fringilla gravida, phasellus feugiat dapibus velit nunc, pulvinar eget sollicitudin venenatis cum nullam, vivamus ut a sed, mollitia lectus. Nulla vestibulum massa neque ut et, id hendrerit sit, feugiat in taciti enim proin nibh, tempor dignissim, rhoncus duis vestibulum nunc mattis convallis.',
                'created' => '2025-04-03 14:53:59',
                'modified' => '2025-04-03 14:53:59',
            ],
        ];
        parent::init();
    }
}
