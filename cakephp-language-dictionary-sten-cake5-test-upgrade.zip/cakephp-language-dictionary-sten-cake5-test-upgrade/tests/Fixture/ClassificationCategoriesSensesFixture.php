<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * ClassificationCategoriesSensesFixture
 */
class ClassificationCategoriesSensesFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'sense_id' => 1,
                'classification_category_id' => 1,
                'created' => '2025-04-03 14:58:57',
                'modified' => '2025-04-03 14:58:57',
            ],
        ];
        parent::init();
    }
}
