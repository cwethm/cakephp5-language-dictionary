<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * SensesFixture
 */
class SensesFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'lexical_entry_id' => 1,
                'slug' => 'Lorem ipsum dolor sit amet',
                'entry_name' => 'Lorem ipsum dolor sit amet',
                'definition' => 'Lorem ipsum dolor sit amet, aliquet feugiat. Convallis morbi fringilla gravida, phasellus feugiat dapibus velit nunc, pulvinar eget sollicitudin venenatis cum nullam, vivamus ut a sed, mollitia lectus. Nulla vestibulum massa neque ut et, id hendrerit sit, feugiat in taciti enim proin nibh, tempor dignissim, rhoncus duis vestibulum nunc mattis convallis.',
                'coverimg' => 1,
                'coversnd' => 1,
                'reference' => 'Lorem ipsum dolor sit amet',
                'created' => '2025-04-03 14:52:47',
                'modified' => '2025-04-03 14:52:47',
            ],
        ];
        parent::init();
    }
}
