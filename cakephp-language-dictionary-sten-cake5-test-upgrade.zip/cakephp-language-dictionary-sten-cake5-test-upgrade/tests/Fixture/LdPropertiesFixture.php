<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * LdPropertiesFixture
 */
class LdPropertiesFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'linguistic_description_id' => 1,
                'lemon_attribute_id' => 1,
                'value' => 'Lorem ipsum dolor sit amet',
                'created' => '2025-04-03 15:00:21',
                'modified' => '2025-04-03 15:00:21',
            ],
        ];
        parent::init();
    }
}
