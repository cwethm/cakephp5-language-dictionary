<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * LinguisticDescriptionsFixture
 */
class LinguisticDescriptionsFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'lexical_entry_id' => 1,
                'sense_id' => 1,
                'form_id' => 1,
                'lemon_attribute_id' => 1,
                'value' => 'Lorem ipsum dolor sit amet',
                'created' => '2025-04-03 14:53:01',
                'modified' => '2025-04-03 14:53:01',
            ],
        ];
        parent::init();
    }
}
