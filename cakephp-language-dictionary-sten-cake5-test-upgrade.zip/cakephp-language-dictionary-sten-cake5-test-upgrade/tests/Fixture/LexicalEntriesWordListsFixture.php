<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * LexicalEntriesWordListsFixture
 */
class LexicalEntriesWordListsFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'lexical_entry_id' => 1,
                'word_list_id' => 1,
                'state' => 'Lorem ipsum dolor sit',
                'note' => 'Lorem ipsum dolor sit amet',
                'modified_by' => 1,
                'created_by' => 1,
                'trashed' => '2025-04-03 14:54:33',
                'created' => '2025-04-03 14:54:33',
                'modified' => '2025-04-03 14:54:33',
            ],
        ];
        parent::init();
    }
}
