<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\TestCase\Controller;

use Cake\TestSuite\IntegrationTestTrait;
use Cake\TestSuite\TestCase;
use LanguageDictionary\Controller\LinguisticDescriptionsController;

/**
 * LanguageDictionary\Controller\LinguisticDescriptionsController Test Case
 *
 * @uses \LanguageDictionary\Controller\LinguisticDescriptionsController
 */
class LinguisticDescriptionsControllerTest extends TestCase
{
    use IntegrationTestTrait;

    /**
     * Fixtures
     *
     * @var list<string>
     */
    protected array $fixtures = [
        'plugin.LanguageDictionary.LinguisticDescriptions',
    ];

    /**
     * Test index method
     *
     * @return void
     * @uses \LanguageDictionary\Controller\LinguisticDescriptionsController::index()
     */
    public function testIndex(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test view method
     *
     * @return void
     * @uses \LanguageDictionary\Controller\LinguisticDescriptionsController::view()
     */
    public function testView(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test add method
     *
     * @return void
     * @uses \LanguageDictionary\Controller\LinguisticDescriptionsController::add()
     */
    public function testAdd(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test edit method
     *
     * @return void
     * @uses \LanguageDictionary\Controller\LinguisticDescriptionsController::edit()
     */
    public function testEdit(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test delete method
     *
     * @return void
     * @uses \LanguageDictionary\Controller\LinguisticDescriptionsController::delete()
     */
    public function testDelete(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
