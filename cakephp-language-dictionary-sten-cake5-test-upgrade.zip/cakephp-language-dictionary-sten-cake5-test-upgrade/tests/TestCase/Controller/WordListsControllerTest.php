<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\TestCase\Controller;

use Cake\TestSuite\IntegrationTestTrait;
use Cake\TestSuite\TestCase;
use LanguageDictionary\Controller\WordListsController;

/**
 * LanguageDictionary\Controller\WordListsController Test Case
 *
 * @uses \LanguageDictionary\Controller\WordListsController
 */
class WordListsControllerTest extends TestCase
{
    use IntegrationTestTrait;

    /**
     * Fixtures
     *
     * @var list<string>
     */
    protected array $fixtures = [
        'plugin.LanguageDictionary.WordLists',
    ];

    /**
     * Test index method
     *
     * @return void
     * @uses \LanguageDictionary\Controller\WordListsController::index()
     */
    public function testIndex(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test view method
     *
     * @return void
     * @uses \LanguageDictionary\Controller\WordListsController::view()
     */
    public function testView(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test add method
     *
     * @return void
     * @uses \LanguageDictionary\Controller\WordListsController::add()
     */
    public function testAdd(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test edit method
     *
     * @return void
     * @uses \LanguageDictionary\Controller\WordListsController::edit()
     */
    public function testEdit(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test delete method
     *
     * @return void
     * @uses \LanguageDictionary\Controller\WordListsController::delete()
     */
    public function testDelete(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
