<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\TestCase\Controller;

use Cake\TestSuite\IntegrationTestTrait;
use Cake\TestSuite\TestCase;
use LanguageDictionary\Controller\ClassificationCategoriesSensesController;

/**
 * LanguageDictionary\Controller\ClassificationCategoriesSensesController Test Case
 *
 * @uses \LanguageDictionary\Controller\ClassificationCategoriesSensesController
 */
class ClassificationCategoriesSensesControllerTest extends TestCase
{
    use IntegrationTestTrait;

    /**
     * Fixtures
     *
     * @var list<string>
     */
    protected array $fixtures = [
        'plugin.LanguageDictionary.ClassificationCategoriesSenses',
    ];

    /**
     * Test index method
     *
     * @return void
     * @uses \LanguageDictionary\Controller\ClassificationCategoriesSensesController::index()
     */
    public function testIndex(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test view method
     *
     * @return void
     * @uses \LanguageDictionary\Controller\ClassificationCategoriesSensesController::view()
     */
    public function testView(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test add method
     *
     * @return void
     * @uses \LanguageDictionary\Controller\ClassificationCategoriesSensesController::add()
     */
    public function testAdd(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test edit method
     *
     * @return void
     * @uses \LanguageDictionary\Controller\ClassificationCategoriesSensesController::edit()
     */
    public function testEdit(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test delete method
     *
     * @return void
     * @uses \LanguageDictionary\Controller\ClassificationCategoriesSensesController::delete()
     */
    public function testDelete(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
