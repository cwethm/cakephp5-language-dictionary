<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\TestCase\Controller;

use Cake\TestSuite\IntegrationTestTrait;
use Cake\TestSuite\TestCase;
use LanguageDictionary\Controller\DictionariesLexicalEntriesController;

/**
 * LanguageDictionary\Controller\DictionariesLexicalEntriesController Test Case
 *
 * @uses \LanguageDictionary\Controller\DictionariesLexicalEntriesController
 */
class DictionariesLexicalEntriesControllerTest extends TestCase
{
    use IntegrationTestTrait;

    /**
     * Fixtures
     *
     * @var list<string>
     */
    protected array $fixtures = [
        'plugin.LanguageDictionary.DictionariesLexicalEntries',
    ];

    /**
     * Test index method
     *
     * @return void
     * @uses \LanguageDictionary\Controller\DictionariesLexicalEntriesController::index()
     */
    public function testIndex(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test view method
     *
     * @return void
     * @uses \LanguageDictionary\Controller\DictionariesLexicalEntriesController::view()
     */
    public function testView(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test add method
     *
     * @return void
     * @uses \LanguageDictionary\Controller\DictionariesLexicalEntriesController::add()
     */
    public function testAdd(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test edit method
     *
     * @return void
     * @uses \LanguageDictionary\Controller\DictionariesLexicalEntriesController::edit()
     */
    public function testEdit(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test delete method
     *
     * @return void
     * @uses \LanguageDictionary\Controller\DictionariesLexicalEntriesController::delete()
     */
    public function testDelete(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
