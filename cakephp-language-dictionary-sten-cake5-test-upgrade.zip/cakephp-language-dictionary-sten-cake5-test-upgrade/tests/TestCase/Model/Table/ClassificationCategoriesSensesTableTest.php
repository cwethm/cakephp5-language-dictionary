<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\TestCase\Model\Table;

use Cake\TestSuite\TestCase;
use LanguageDictionary\Model\Table\ClassificationCategoriesSensesTable;

/**
 * LanguageDictionary\Model\Table\ClassificationCategoriesSensesTable Test Case
 */
class ClassificationCategoriesSensesTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \LanguageDictionary\Model\Table\ClassificationCategoriesSensesTable
     */
    protected $ClassificationCategoriesSenses;

    /**
     * Fixtures
     *
     * @var list<string>
     */
    protected array $fixtures = [
        'plugin.LanguageDictionary.ClassificationCategoriesSenses',
        'plugin.LanguageDictionary.Senses',
        'plugin.LanguageDictionary.ClassificationCategories',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    protected function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('ClassificationCategoriesSenses') ? [] : ['className' => ClassificationCategoriesSensesTable::class];
        $this->ClassificationCategoriesSenses = $this->getTableLocator()->get('ClassificationCategoriesSenses', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    protected function tearDown(): void
    {
        unset($this->ClassificationCategoriesSenses);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     * @uses \LanguageDictionary\Model\Table\ClassificationCategoriesSensesTable::validationDefault()
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     * @uses \LanguageDictionary\Model\Table\ClassificationCategoriesSensesTable::buildRules()
     */
    public function testBuildRules(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
