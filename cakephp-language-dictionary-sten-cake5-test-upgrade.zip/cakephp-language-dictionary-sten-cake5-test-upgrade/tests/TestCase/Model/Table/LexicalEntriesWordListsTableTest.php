<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\TestCase\Model\Table;

use Cake\TestSuite\TestCase;
use LanguageDictionary\Model\Table\LexicalEntriesWordListsTable;

/**
 * LanguageDictionary\Model\Table\LexicalEntriesWordListsTable Test Case
 */
class LexicalEntriesWordListsTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \LanguageDictionary\Model\Table\LexicalEntriesWordListsTable
     */
    protected $LexicalEntriesWordLists;

    /**
     * Fixtures
     *
     * @var list<string>
     */
    protected array $fixtures = [
        'plugin.LanguageDictionary.LexicalEntriesWordLists',
        'plugin.LanguageDictionary.LexicalEntries',
        'plugin.LanguageDictionary.WordLists',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    protected function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('LexicalEntriesWordLists') ? [] : ['className' => LexicalEntriesWordListsTable::class];
        $this->LexicalEntriesWordLists = $this->getTableLocator()->get('LexicalEntriesWordLists', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    protected function tearDown(): void
    {
        unset($this->LexicalEntriesWordLists);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     * @uses \LanguageDictionary\Model\Table\LexicalEntriesWordListsTable::validationDefault()
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     * @uses \LanguageDictionary\Model\Table\LexicalEntriesWordListsTable::buildRules()
     */
    public function testBuildRules(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
