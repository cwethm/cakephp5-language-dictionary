<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\TestCase\Model\Table;

use Cake\TestSuite\TestCase;
use LanguageDictionary\Model\Table\FormsTable;

/**
 * LanguageDictionary\Model\Table\FormsTable Test Case
 */
class FormsTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \LanguageDictionary\Model\Table\FormsTable
     */
    protected $Forms;

    /**
     * Fixtures
     *
     * @var list<string>
     */
    protected array $fixtures = [
        'plugin.LanguageDictionary.Forms',
        'plugin.LanguageDictionary.LexicalEntries',
        'plugin.LanguageDictionary.Languages',
        'plugin.LanguageDictionary.LinguisticDescriptions',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    protected function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('Forms') ? [] : ['className' => FormsTable::class];
        $this->Forms = $this->getTableLocator()->get('Forms', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    protected function tearDown(): void
    {
        unset($this->Forms);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     * @uses \LanguageDictionary\Model\Table\FormsTable::validationDefault()
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     * @uses \LanguageDictionary\Model\Table\FormsTable::buildRules()
     */
    public function testBuildRules(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
