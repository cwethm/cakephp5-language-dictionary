<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\TestCase\Model\Table;

use Cake\TestSuite\TestCase;
use LanguageDictionary\Model\Table\DictionariesLexicalEntriesTable;

/**
 * LanguageDictionary\Model\Table\DictionariesLexicalEntriesTable Test Case
 */
class DictionariesLexicalEntriesTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \LanguageDictionary\Model\Table\DictionariesLexicalEntriesTable
     */
    protected $DictionariesLexicalEntries;

    /**
     * Fixtures
     *
     * @var list<string>
     */
    protected array $fixtures = [
        'plugin.LanguageDictionary.DictionariesLexicalEntries',
        'plugin.LanguageDictionary.Dictionaries',
        'plugin.LanguageDictionary.LexicalEntries',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    protected function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('DictionariesLexicalEntries') ? [] : ['className' => DictionariesLexicalEntriesTable::class];
        $this->DictionariesLexicalEntries = $this->getTableLocator()->get('DictionariesLexicalEntries', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    protected function tearDown(): void
    {
        unset($this->DictionariesLexicalEntries);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     * @uses \LanguageDictionary\Model\Table\DictionariesLexicalEntriesTable::validationDefault()
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     * @uses \LanguageDictionary\Model\Table\DictionariesLexicalEntriesTable::buildRules()
     */
    public function testBuildRules(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
