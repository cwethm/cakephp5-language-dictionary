<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\TestCase\Model\Table;

use Cake\TestSuite\TestCase;
use LanguageDictionary\Model\Table\LexicalEntriesTable;

/**
 * LanguageDictionary\Model\Table\LexicalEntriesTable Test Case
 */
class LexicalEntriesTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \LanguageDictionary\Model\Table\LexicalEntriesTable
     */
    protected $LexicalEntries;

    /**
     * Fixtures
     *
     * @var list<string>
     */
    protected array $fixtures = [
        'plugin.LanguageDictionary.LexicalEntries',
        'plugin.LanguageDictionary.Languages',
        'plugin.LanguageDictionary.Users',
        'plugin.LanguageDictionary.Forms',
        'plugin.LanguageDictionary.LinguisticDescriptions',
        'plugin.LanguageDictionary.LinguisticLinks',
        'plugin.LanguageDictionary.Senses',
        'plugin.LanguageDictionary.Dictionaries',
        'plugin.LanguageDictionary.WordLists',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    protected function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('LexicalEntries') ? [] : ['className' => LexicalEntriesTable::class];
        $this->LexicalEntries = $this->getTableLocator()->get('LexicalEntries', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    protected function tearDown(): void
    {
        unset($this->LexicalEntries);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     * @uses \LanguageDictionary\Model\Table\LexicalEntriesTable::validationDefault()
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     * @uses \LanguageDictionary\Model\Table\LexicalEntriesTable::buildRules()
     */
    public function testBuildRules(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
