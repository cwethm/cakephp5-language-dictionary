<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\TestCase\Model\Table;

use Cake\TestSuite\TestCase;
use LanguageDictionary\Model\Table\UsageExamplesTable;

/**
 * LanguageDictionary\Model\Table\UsageExamplesTable Test Case
 */
class UsageExamplesTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \LanguageDictionary\Model\Table\UsageExamplesTable
     */
    protected $UsageExamples;

    /**
     * Fixtures
     *
     * @var list<string>
     */
    protected array $fixtures = [
        'plugin.LanguageDictionary.UsageExamples',
        'plugin.LanguageDictionary.Senses',
        'plugin.LanguageDictionary.Languages',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    protected function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('UsageExamples') ? [] : ['className' => UsageExamplesTable::class];
        $this->UsageExamples = $this->getTableLocator()->get('UsageExamples', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    protected function tearDown(): void
    {
        unset($this->UsageExamples);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     * @uses \LanguageDictionary\Model\Table\UsageExamplesTable::validationDefault()
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     * @uses \LanguageDictionary\Model\Table\UsageExamplesTable::buildRules()
     */
    public function testBuildRules(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
