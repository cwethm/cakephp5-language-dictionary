<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\TestCase\Model\Table;

use Cake\TestSuite\TestCase;
use LanguageDictionary\Model\Table\LinguisticDescriptionsTable;

/**
 * LanguageDictionary\Model\Table\LinguisticDescriptionsTable Test Case
 */
class LinguisticDescriptionsTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \LanguageDictionary\Model\Table\LinguisticDescriptionsTable
     */
    protected $LinguisticDescriptions;

    /**
     * Fixtures
     *
     * @var list<string>
     */
    protected array $fixtures = [
        'plugin.LanguageDictionary.LinguisticDescriptions',
        'plugin.LanguageDictionary.LexicalEntries',
        'plugin.LanguageDictionary.Senses',
        'plugin.LanguageDictionary.Forms',
        'plugin.LanguageDictionary.LemonAttributes',
        'plugin.LanguageDictionary.LdProperties',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    protected function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('LinguisticDescriptions') ? [] : ['className' => LinguisticDescriptionsTable::class];
        $this->LinguisticDescriptions = $this->getTableLocator()->get('LinguisticDescriptions', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    protected function tearDown(): void
    {
        unset($this->LinguisticDescriptions);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     * @uses \LanguageDictionary\Model\Table\LinguisticDescriptionsTable::validationDefault()
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     * @uses \LanguageDictionary\Model\Table\LinguisticDescriptionsTable::buildRules()
     */
    public function testBuildRules(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
