<?php
declare(strict_types=1);

namespace LanguageDictionary\Test\TestCase\Model\Table;

use Cake\TestSuite\TestCase;
use LanguageDictionary\Model\Table\LemonAttributesTable;

/**
 * LanguageDictionary\Model\Table\LemonAttributesTable Test Case
 */
class LemonAttributesTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \LanguageDictionary\Model\Table\LemonAttributesTable
     */
    protected $LemonAttributes;

    /**
     * Fixtures
     *
     * @var list<string>
     */
    protected array $fixtures = [
        'plugin.LanguageDictionary.LemonAttributes',
        'plugin.LanguageDictionary.LdProperties',
        'plugin.LanguageDictionary.LinguisticDescriptions',
        'plugin.LanguageDictionary.LinguisticLinks',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    protected function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('LemonAttributes') ? [] : ['className' => LemonAttributesTable::class];
        $this->LemonAttributes = $this->getTableLocator()->get('LemonAttributes', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    protected function tearDown(): void
    {
        unset($this->LemonAttributes);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     * @uses \LanguageDictionary\Model\Table\LemonAttributesTable::validationDefault()
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
