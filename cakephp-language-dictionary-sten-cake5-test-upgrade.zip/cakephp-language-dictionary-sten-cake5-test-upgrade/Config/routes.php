<?php
use Cake\Routing\RouteBuilder;
use Cake\Routing\Router;

return static function (RouteBuilder $routes) {
    $routes->plugin(
        'LanguageDictionary',
        ['path' => '/language-dictionary'],
        function (RouteBuilder $builder) {
            // Lexical Entries routes
            $builder->connect('/lexical-entries/detach/:id', [
                'controller' => 'LexicalEntries',
                'action' => 'detach',
            ])->setPass(['id'])->setMethods(['POST']);
        }
    );
};
