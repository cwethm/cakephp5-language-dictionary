<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Entity;

use Cake\ORM\Entity;

/**
 * LexicalEntry Entity
 *
 * @property int $id
 * @property string|null $slug
 * @property string $entry_type
 * @property string $name
 * @property string|null $translated
 * @property string|null $part_of_speech
 * @property int|null $language_id
 * @property int|null $coverimg
 * @property int|null $coversound
 * @property int|null $tag_count
 * @property \Cake\I18n\DateTime|null $trashed
 * @property int|null $user_id
 * @property int|null $created_by
 * @property int|null $modified_by
 * @property \Cake\I18n\DateTime|null $created
 * @property \Cake\I18n\DateTime|null $modified
 *
 * @property \LanguageDictionary\Model\Entity\Language $language
 * @property \LanguageDictionary\Model\Entity\User $user
 * @property \LanguageDictionary\Model\Entity\Form[] $forms
 * @property \LanguageDictionary\Model\Entity\LinguisticDescription[] $linguistic_descriptions
 * @property \LanguageDictionary\Model\Entity\LinguisticLink[] $linguistic_links
 * @property \LanguageDictionary\Model\Entity\Sense[] $senses
 * @property \LanguageDictionary\Model\Entity\Dictionary[] $dictionaries
 * @property \LanguageDictionary\Model\Entity\WordList[] $word_lists
 */
class LexicalEntry extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array<string, bool>
     */
    protected array $_accessible = [
        'slug' => true,
        'entry_type' => true,
        'name' => true,
        'translated' => true,
        'part_of_speech' => true,
        'language_id' => true,
        'coverimg' => true,
        'coversound' => true,
        'tag_count' => true,
        'trashed' => true,
        'user_id' => true,
        'created_by' => true,
        'modified_by' => true,
        'created' => true,
        'modified' => true,
        'language' => true,
        'user' => true,
        'forms' => true,
        'linguistic_descriptions' => true,
        'linguistic_links' => true,
        'senses' => true,
        'dictionaries' => true,
        'word_lists' => true,
    ];
}
