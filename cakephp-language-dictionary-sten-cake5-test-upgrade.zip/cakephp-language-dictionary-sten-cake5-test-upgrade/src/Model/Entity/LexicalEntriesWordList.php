<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Entity;

use Cake\ORM\Entity;

/**
 * LexicalEntriesWordList Entity
 *
 * @property int $id
 * @property int $lexical_entry_id
 * @property int $word_list_id
 * @property string|null $state
 * @property string|null $note
 * @property int|null $modified_by
 * @property int|null $created_by
 * @property \Cake\I18n\DateTime|null $trashed
 * @property \Cake\I18n\DateTime|null $created
 * @property \Cake\I18n\DateTime|null $modified
 *
 * @property \LanguageDictionary\Model\Entity\LexicalEntry $lexical_entry
 * @property \LanguageDictionary\Model\Entity\WordList $word_list
 */
class LexicalEntriesWordList extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array<string, bool>
     */
    protected array $_accessible = [
        'lexical_entry_id' => true,
        'word_list_id' => true,
        'state' => true,
        'note' => true,
        'modified_by' => true,
        'created_by' => true,
        'trashed' => true,
        'created' => true,
        'modified' => true,
        'lexical_entry' => true,
        'word_list' => true,
    ];
}
