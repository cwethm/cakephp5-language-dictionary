<?php
namespace LanguageDictionary\Model\Entity;

use Cake\ORM\Entity;

class LexinfoValue extends Entity
{
    protected array $_accessible = [
        'category' => true,
        'uri' => true,
        'label' => true,
        'code' => true,
        'description' => true,
    ];
}
