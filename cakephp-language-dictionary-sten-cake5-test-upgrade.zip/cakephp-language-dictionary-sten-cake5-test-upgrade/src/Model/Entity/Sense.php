<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Entity;

use Cake\ORM\Entity;

/**
 * Sense Entity
 *
 * @property int $id
 * @property int $lexical_entry_id
 * @property string|null $slug
 * @property string|null $entry_name
 * @property string|null $definition
 * @property int|null $coverimg
 * @property int|null $coversnd
 * @property string|null $reference
 * @property \Cake\I18n\DateTime|null $created
 * @property \Cake\I18n\DateTime|null $modified
 *
 * @property \LanguageDictionary\Model\Entity\LexicalEntry $lexical_entry
 * @property \LanguageDictionary\Model\Entity\LinguisticDescription[] $linguistic_descriptions
 * @property \LanguageDictionary\Model\Entity\ClassificationCategory[] $classification_categories
 */
class Sense extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array<string, bool>
     */
    protected array $_accessible = [
        'lexical_entry_id' => true,
        'slug' => true,
        'entry_name' => true,
        'definition' => true,
        'coverimg' => true,
        'coversnd' => true,
        'reference' => true,
        'created' => true,
        'modified' => true,
        'lexical_entry' => true,
        'linguistic_descriptions' => true,
        'classification_categories' => true,
    ];
}
