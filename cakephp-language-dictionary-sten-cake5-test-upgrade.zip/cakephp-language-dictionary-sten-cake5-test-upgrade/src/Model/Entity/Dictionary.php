<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Entity;

use Cake\ORM\Entity;

/**
 * Dictionary Entity
 *
 * @property int $id
 * @property string $user_id
 * @property string|null $slug
 * @property int|null $tag_count
 * @property string $name
 * @property string $description
 * @property \Cake\I18n\DateTime $created
 * @property \Cake\I18n\DateTime $modified
 *
 * @property \LanguageDictionary\Model\Entity\User $user
 * @property \LanguageDictionary\Model\Entity\Synonym[] $synonyms
 * @property \LanguageDictionary\Model\Entity\Language[] $languages
 * @property \LanguageDictionary\Model\Entity\LexicalEntry[] $lexical_entries
 */
class Dictionary extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array<string, bool>
     */
    protected array $_accessible = [
        'user_id' => true,
        'slug' => true,
        'tag_count' => true,
        'name' => true,
        'description' => true,
        'created' => true,
        'modified' => true,
        'user' => true,
        'synonyms' => true,
        'languages' => true,
        'lexical_entries' => true,
    ];
}
