<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Entity;

use Cake\ORM\Entity;

/**
 * WordList Entity
 *
 * @property int $id
 * @property int|null $user_id
 * @property string $list_type
 * @property string $name
 * @property string|null $description
 * @property int|null $tag_count
 * @property \Cake\I18n\DateTime|null $trashed
 * @property int|null $created_by
 * @property int|null $modified_by
 * @property \Cake\I18n\DateTime|null $created
 * @property \Cake\I18n\DateTime|null $modified
 *
 * @property \LanguageDictionary\Model\Entity\User $user
 * @property \LanguageDictionary\Model\Entity\LexicalEntry[] $lexical_entries
 */
class WordList extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array<string, bool>
     */
    protected array $_accessible = [
        'user_id' => true,
        'list_type' => true,
        'name' => true,
        'description' => true,
        'tag_count' => true,
        'trashed' => true,
        'created_by' => true,
        'modified_by' => true,
        'created' => true,
        'modified' => true,
        'user' => true,
        'lexical_entries' => true,
    ];
}
