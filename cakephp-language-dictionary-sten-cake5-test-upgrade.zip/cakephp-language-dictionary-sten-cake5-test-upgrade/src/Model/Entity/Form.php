<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Entity;

use Cake\ORM\Entity;

/**
 * Form Entity
 *
 * @property int $id
 * @property int $lexical_entry_id
 * @property int|null $language_id
 * @property string $form_type
 * @property string $written_representation
 * @property string|null $slug
 * @property \Cake\I18n\DateTime|null $created
 * @property \Cake\I18n\DateTime|null $modified
 *
 * @property \LanguageDictionary\Model\Entity\LexicalEntry $lexical_entry
 * @property \LanguageDictionary\Model\Entity\Language $language
 * @property \LanguageDictionary\Model\Entity\LinguisticDescription[] $linguistic_descriptions
 */
class Form extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array<string, bool>
     */
    protected array $_accessible = [
        'lexical_entry_id' => true,
        'language_id' => true,
        'form_type' => true,
        'written_representation' => true,
        'slug' => true,
        'created' => true,
        'modified' => true,
        'lexical_entry' => true,
        'language' => true,
        'linguistic_descriptions' => true,
    ];
}
