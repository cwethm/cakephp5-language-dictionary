<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Entity;

use Cake\ORM\Entity;

/**
 * Language Entity
 *
 * @property int $id
 * @property string $name
 * @property string $abbreviation
 * @property string|null $letters
 * @property string|null $keyboard_characters
 * @property \Cake\I18n\DateTime|null $trashed
 * @property \Cake\I18n\DateTime $created
 * @property \Cake\I18n\DateTime $modified
 *
 * @property \LanguageDictionary\Model\Entity\Form[] $forms
 * @property \LanguageDictionary\Model\Entity\LexicalEntry[] $lexical_entries
 * @property \LanguageDictionary\Model\Entity\Synonym[] $synonyms
 * @property \LanguageDictionary\Model\Entity\UsageExample[] $usage_examples
 * @property \LanguageDictionary\Model\Entity\Dictionary[] $dictionaries
 * @property \LanguageDictionary\Model\Entity\LinguisticDescription[] $linguistic_descriptions
 */
class Language extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array<string, bool>
     */
    protected array $_accessible = [
        'name' => true,
        'abbreviation' => true,
        'letters' => true,
        'keyboard_characters' => true,
        'trashed' => true,
        'created' => true,
        'modified' => true,
        'forms' => true,
        'lexical_entries' => true,
        'synonyms' => true,
        'usage_examples' => true,
        'dictionaries' => true,
        'linguistic_descriptions' => true,
    ];
}
