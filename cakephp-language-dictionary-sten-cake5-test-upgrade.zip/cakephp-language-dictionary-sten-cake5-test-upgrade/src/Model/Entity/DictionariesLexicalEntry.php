<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Entity;

use Cake\ORM\Entity;

/**
 * DictionariesLexicalEntry Entity
 *
 * @property int $id
 * @property int $dictionary_id
 * @property int $lexical_entry_id
 * @property \Cake\I18n\DateTime|null $created
 * @property \Cake\I18n\DateTime|null $modified
 *
 * @property \LanguageDictionary\Model\Entity\Dictionary $dictionary
 * @property \LanguageDictionary\Model\Entity\LexicalEntry $lexical_entry
 */
class DictionariesLexicalEntry extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array<string, bool>
     */
    protected array $_accessible = [
        'dictionary_id' => true,
        'lexical_entry_id' => true,
        'created' => true,
        'modified' => true,
        'dictionary' => true,
        'lexical_entry' => true,
    ];
}
