<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Entity;

use Cake\ORM\Entity;

/**
 * LemonAttribute Entity
 *
 * @property int $id
 * @property string $uri
 * @property string $local_name
 * @property string $model_class
 * @property string|null $rdf_datatype
 * @property int|null $cardinality_min
 * @property int|null $cardinality_max
 * @property string|null $description
 * @property \Cake\I18n\DateTime|null $created
 * @property \Cake\I18n\DateTime|null $modified
 * @property string|null $category
 * @property string|null $range_class
 * @property string|null $parent_class
 * @property string|null $rdfs_label
 * @property string|null $rdfs_comment
 * @property string|null $rdf_type
 * @property string|null $domain_class
 *
 * @property \LanguageDictionary\Model\Entity\LdProperty[] $ld_properties
 * @property \LanguageDictionary\Model\Entity\LinguisticDescription[] $linguistic_descriptions
 * @property \LanguageDictionary\Model\Entity\LinguisticLink[] $linguistic_links
 */
class LemonAttribute extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array<string, bool>
     */
    protected array $_accessible = [
        'uri' => true,
        'local_name' => true,
        'model_class' => true,
        'rdf_datatype' => true,
        'cardinality_min' => true,
        'cardinality_max' => true,
        'description' => true,
        'created' => true,
        'modified' => true,
        'category' => true,
        'range_class' => true,
        'parent_class' => true,
        'rdfs_label' => true,
        'rdfs_comment' => true,
        'rdf_type' => true,
        'domain_class' => true,
        'ld_properties' => true,
        'linguistic_descriptions' => true,
        'linguistic_links' => true,
    ];
}
