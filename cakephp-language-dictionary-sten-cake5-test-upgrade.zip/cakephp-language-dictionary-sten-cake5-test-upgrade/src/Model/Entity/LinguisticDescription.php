<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Entity;

use Cake\ORM\Entity;

/**
 * LinguisticDescription Entity
 *
 * @property int $id
 * @property int|null $lexical_entry_id
 * @property int|null $sense_id
 * @property int|null $form_id
 * @property int $lemon_attribute_id
 * @property string|null $value
 * @property \Cake\I18n\DateTime|null $created
 * @property \Cake\I18n\DateTime|null $modified
 *
 * @property \LanguageDictionary\Model\Entity\LexicalEntry $lexical_entry
 * @property \LanguageDictionary\Model\Entity\Sense $sense
 * @property \LanguageDictionary\Model\Entity\Form $form
 * @property \LanguageDictionary\Model\Entity\LemonAttribute $lemon_attribute
 * @property \LanguageDictionary\Model\Entity\LdProperty[] $ld_properties
 */
class LinguisticDescription extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array<string, bool>
     */
    protected array $_accessible = [
        'lexical_entry_id' => true,
        'sense_id' => true,
        'form_id' => true,
        'lemon_attribute_id' => true,
        'value' => true,
        'created' => true,
        'modified' => true,
        'lexical_entry' => true,
        'sense' => true,
        'form' => true,
        'lemon_attribute' => true,
        'ld_properties' => true,
    ];
}
