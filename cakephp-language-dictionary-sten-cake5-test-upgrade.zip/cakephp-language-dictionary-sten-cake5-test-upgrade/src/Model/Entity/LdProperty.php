<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Entity;

use Cake\ORM\Entity;

/**
 * LdProperty Entity
 *
 * @property int $id
 * @property int $linguistic_description_id
 * @property int $lemon_attribute_id
 * @property string|null $value
 * @property \Cake\I18n\DateTime|null $created
 * @property \Cake\I18n\DateTime|null $modified
 *
 * @property \LanguageDictionary\Model\Entity\LinguisticDescription $linguistic_description
 * @property \LanguageDictionary\Model\Entity\LemonAttribute $lemon_attribute
 */
class LdProperty extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array<string, bool>
     */
    protected array $_accessible = [
        'linguistic_description_id' => true,
        'lemon_attribute_id' => true,
        'value' => true,
        'created' => true,
        'modified' => true,
        'linguistic_description' => true,
        'lemon_attribute' => true,
    ];
}
