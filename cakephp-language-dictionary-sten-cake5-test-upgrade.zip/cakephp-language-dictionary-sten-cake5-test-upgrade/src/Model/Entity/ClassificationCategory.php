<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Entity;

use Cake\ORM\Entity;

/**
 * ClassificationCategory Entity
 *
 * @property int $id
 * @property int|null $lft
 * @property int|null $rght
 * @property int|null $parent_id
 * @property string $name
 * @property \Cake\I18n\DateTime|null $created
 * @property \Cake\I18n\DateTime|null $modified
 *
 * @property \LanguageDictionary\Model\Entity\ClassificationCategory $parent_classification_category
 * @property \LanguageDictionary\Model\Entity\ClassificationCategory[] $child_classification_categories
 * @property \LanguageDictionary\Model\Entity\Sense[] $senses
 */
class ClassificationCategory extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array<string, bool>
     */
    protected array $_accessible = [
        'lft' => true,
        'rght' => true,
        'parent_id' => true,
        'name' => true,
        'created' => true,
        'modified' => true,
        'parent_classification_category' => true,
        'child_classification_categories' => true,
        'senses' => true,
    ];
}
