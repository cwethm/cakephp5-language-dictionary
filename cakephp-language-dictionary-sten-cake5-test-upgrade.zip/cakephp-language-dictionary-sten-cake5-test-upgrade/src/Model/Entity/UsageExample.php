<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Entity;

use Cake\ORM\Entity;

/**
 * UsageExample Entity
 *
 * @property int $id
 * @property int $sense_id
 * @property string $example_text
 * @property int|null $language_id
 * @property \Cake\I18n\DateTime|null $created
 * @property \Cake\I18n\DateTime|null $modified
 *
 * @property \LanguageDictionary\Model\Entity\Sense $sense
 * @property \LanguageDictionary\Model\Entity\Language $language
 */
class UsageExample extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array<string, bool>
     */
    protected array $_accessible = [
        'sense_id' => true,
        'example_text' => true,
        'language_id' => true,
        'created' => true,
        'modified' => true,
        'sense' => true,
        'language' => true,
    ];
}
