<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Entity;

use Cake\ORM\Entity;

/**
 * FlexField Entity
 *
 * @property int $id
 * @property string|null $slug
 * @property int $word_id
 * @property string $flex_key
 * @property string $flex_value
 * @property string|null $second_value
 * @property int|null $user_id
 * @property bool|null $active
 * @property \Cake\I18n\DateTime|null $created
 * @property \Cake\I18n\DateTime|null $modified
 *
 * @property \LanguageDictionary\Model\Entity\User $user
 */
class FlexField extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array<string, bool>
     */
    protected array $_accessible = [
        'slug' => true,
        'word_id' => true,
        'flex_key' => true,
        'flex_value' => true,
        'second_value' => true,
        'user_id' => true,
        'active' => true,
        'created' => true,
        'modified' => true,
        'user' => true,
    ];
}
