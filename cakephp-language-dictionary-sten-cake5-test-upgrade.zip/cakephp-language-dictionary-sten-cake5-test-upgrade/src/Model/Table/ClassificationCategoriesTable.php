<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Table;

use Cake\ORM\Query\SelectQuery;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\ORM\Query;
use Cake\Validation\Validator;

/**
 * ClassificationCategories Model
 *
 * @property \LanguageDictionary\Model\Table\ClassificationCategoriesTable&\Cake\ORM\Association\BelongsTo $ParentClassificationCategories
 * @property \LanguageDictionary\Model\Table\ClassificationCategoriesTable&\Cake\ORM\Association\HasMany $ChildClassificationCategories
 * @property \LanguageDictionary\Model\Table\SensesTable&\Cake\ORM\Association\BelongsToMany $Senses
 *
 * @method \LanguageDictionary\Model\Entity\ClassificationCategory newEmptyEntity()
 * @method \LanguageDictionary\Model\Entity\ClassificationCategory newEntity(array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\ClassificationCategory> newEntities(array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\ClassificationCategory get(mixed $primaryKey, array|string $finder = 'all', \Psr\SimpleCache\CacheInterface|string|null $cache = null, \Closure|string|null $cacheKey = null, mixed ...$args)
 * @method \LanguageDictionary\Model\Entity\ClassificationCategory findOrCreate($search, ?callable $callback = null, array $options = [])
 * @method \LanguageDictionary\Model\Entity\ClassificationCategory patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\ClassificationCategory> patchEntities(iterable $entities, array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\ClassificationCategory|false save(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method \LanguageDictionary\Model\Entity\ClassificationCategory saveOrFail(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\ClassificationCategory>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\ClassificationCategory>|false saveMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\ClassificationCategory>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\ClassificationCategory> saveManyOrFail(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\ClassificationCategory>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\ClassificationCategory>|false deleteMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\ClassificationCategory>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\ClassificationCategory> deleteManyOrFail(iterable $entities, array $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 * @mixin \Cake\ORM\Behavior\TreeBehavior
 */
class ClassificationCategoriesTable extends Table
{
    /**
     * Initialize method
     *
     * @param array<string, mixed> $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('classification_categories');
        $this->setDisplayField('name');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');
        $this->addBehavior('Tree');
 
        $this->belongsTo('ParentClassificationCategories', [
            'className' => 'LanguageDictionary.ClassificationCategories',
            'foreignKey' => 'parent_id',
        ]);
        $this->hasMany('ChildClassificationCategories', [
            'className' => 'LanguageDictionary.ClassificationCategories',
            'foreignKey' => 'parent_id',
        ]);
        $this->belongsToMany('Senses', [
            'foreignKey' => 'classification_category_id',
            'targetForeignKey' => 'sense_id',
            'joinTable' => 'classification_categories_senses',
            'className' => 'LanguageDictionary.Senses',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('parent_id')
            ->allowEmptyString('parent_id');

        $validator
            ->scalar('name')
            ->maxLength('name', 255)
            ->requirePresence('name', 'create')
            ->notEmptyString('name');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->existsIn(['parent_id'], 'ParentClassificationCategories'), ['errorField' => 'parent_id']);

        return $rules;
    }
}
