<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Table;

use Cake\ORM\Query\SelectQuery;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * DictionariesLanguages Model
 *
 * @property \LanguageDictionary\Model\Table\DictionariesTable&\Cake\ORM\Association\BelongsTo $Dictionaries
 * @property \LanguageDictionary\Model\Table\LanguagesTable&\Cake\ORM\Association\BelongsTo $Languages
 *
 * @method \LanguageDictionary\Model\Entity\DictionariesLanguage newEmptyEntity()
 * @method \LanguageDictionary\Model\Entity\DictionariesLanguage newEntity(array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\DictionariesLanguage> newEntities(array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\DictionariesLanguage get(mixed $primaryKey, array|string $finder = 'all', \Psr\SimpleCache\CacheInterface|string|null $cache = null, \Closure|string|null $cacheKey = null, mixed ...$args)
 * @method \LanguageDictionary\Model\Entity\DictionariesLanguage findOrCreate($search, ?callable $callback = null, array $options = [])
 * @method \LanguageDictionary\Model\Entity\DictionariesLanguage patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\DictionariesLanguage> patchEntities(iterable $entities, array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\DictionariesLanguage|false save(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method \LanguageDictionary\Model\Entity\DictionariesLanguage saveOrFail(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\DictionariesLanguage>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\DictionariesLanguage>|false saveMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\DictionariesLanguage>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\DictionariesLanguage> saveManyOrFail(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\DictionariesLanguage>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\DictionariesLanguage>|false deleteMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\DictionariesLanguage>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\DictionariesLanguage> deleteManyOrFail(iterable $entities, array $options = [])
 */
class DictionariesLanguagesTable extends Table
{
    /**
     * Initialize method
     *
     * @param array<string, mixed> $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('dictionaries_languages');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->belongsTo('Dictionaries', [
            'foreignKey' => 'dictionary_id',
            'joinType' => 'INNER',
            'className' => 'LanguageDictionary.Dictionaries',
        ]);
        $this->belongsTo('Languages', [
            'foreignKey' => 'language_id',
            'joinType' => 'INNER',
            'className' => 'LanguageDictionary.Languages',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('dictionary_id')
            ->notEmptyString('dictionary_id');

        $validator
            ->integer('language_id')
            ->notEmptyString('language_id');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->existsIn(['dictionary_id'], 'Dictionaries'), ['errorField' => 'dictionary_id']);
        $rules->add($rules->existsIn(['language_id'], 'Languages'), ['errorField' => 'language_id']);

        return $rules;
    }
}
