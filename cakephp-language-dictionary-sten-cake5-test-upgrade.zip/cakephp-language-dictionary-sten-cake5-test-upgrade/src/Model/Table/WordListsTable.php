<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Table;

use Cake\ORM\Query\SelectQuery;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * WordLists Model
 *
 * @property \LanguageDictionary\Model\Table\UsersTable&\Cake\ORM\Association\BelongsTo $Users
 * @property \LanguageDictionary\Model\Table\LexicalEntriesTable&\Cake\ORM\Association\BelongsToMany $LexicalEntries
 *
 * @method \LanguageDictionary\Model\Entity\WordList newEmptyEntity()
 * @method \LanguageDictionary\Model\Entity\WordList newEntity(array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\WordList> newEntities(array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\WordList get(mixed $primaryKey, array|string $finder = 'all', \Psr\SimpleCache\CacheInterface|string|null $cache = null, \Closure|string|null $cacheKey = null, mixed ...$args)
 * @method \LanguageDictionary\Model\Entity\WordList findOrCreate($search, ?callable $callback = null, array $options = [])
 * @method \LanguageDictionary\Model\Entity\WordList patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\WordList> patchEntities(iterable $entities, array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\WordList|false save(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method \LanguageDictionary\Model\Entity\WordList saveOrFail(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\WordList>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\WordList>|false saveMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\WordList>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\WordList> saveManyOrFail(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\WordList>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\WordList>|false deleteMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\WordList>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\WordList> deleteManyOrFail(iterable $entities, array $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class WordListsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array<string, mixed> $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('word_lists');
        $this->setDisplayField('name');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'className' => 'Usermgmt.Users',
        ]);
        $this->belongsToMany('LexicalEntries', [
            'foreignKey' => 'word_list_id',
            'targetForeignKey' => 'lexical_entry_id',
            'joinTable' => 'lexical_entries_word_lists',
            'className' => 'LanguageDictionary.LexicalEntries',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('user_id')
            ->allowEmptyString('user_id');

        $validator
            ->scalar('list_type')
            ->maxLength('list_type', 79)
            ->notEmptyString('list_type');

        $validator
            ->scalar('name')
            ->maxLength('name', 144)
            ->requirePresence('name', 'create')
            ->notEmptyString('name');

        $validator
            ->scalar('description')
            ->allowEmptyString('description');

        $validator
            ->integer('tag_count')
            ->allowEmptyString('tag_count');

        $validator
            ->dateTime('trashed')
            ->allowEmptyDateTime('trashed');

        $validator
            ->integer('created_by')
            ->allowEmptyString('created_by');

        $validator
            ->integer('modified_by')
            ->allowEmptyString('modified_by');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->existsIn(['user_id'], 'Users'), ['errorField' => 'user_id']);

        return $rules;
    }
}
