<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Table;

use Cake\ORM\Query\SelectQuery;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * UsageExamples Model
 *
 * @property \LanguageDictionary\Model\Table\SensesTable&\Cake\ORM\Association\BelongsTo $Senses
 * @property \LanguageDictionary\Model\Table\LanguagesTable&\Cake\ORM\Association\BelongsTo $Languages
 *
 * @method \LanguageDictionary\Model\Entity\UsageExample newEmptyEntity()
 * @method \LanguageDictionary\Model\Entity\UsageExample newEntity(array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\UsageExample> newEntities(array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\UsageExample get(mixed $primaryKey, array|string $finder = 'all', \Psr\SimpleCache\CacheInterface|string|null $cache = null, \Closure|string|null $cacheKey = null, mixed ...$args)
 * @method \LanguageDictionary\Model\Entity\UsageExample findOrCreate($search, ?callable $callback = null, array $options = [])
 * @method \LanguageDictionary\Model\Entity\UsageExample patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\UsageExample> patchEntities(iterable $entities, array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\UsageExample|false save(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method \LanguageDictionary\Model\Entity\UsageExample saveOrFail(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\UsageExample>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\UsageExample>|false saveMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\UsageExample>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\UsageExample> saveManyOrFail(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\UsageExample>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\UsageExample>|false deleteMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\UsageExample>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\UsageExample> deleteManyOrFail(iterable $entities, array $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class UsageExamplesTable extends Table
{
    /**
     * Initialize method
     *
     * @param array<string, mixed> $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('usage_examples');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Senses', [
            'foreignKey' => 'sense_id',
            'joinType' => 'INNER',
            'className' => 'LanguageDictionary.Senses',
        ]);
        $this->belongsTo('Languages', [
            'foreignKey' => 'language_id',
            'className' => 'LanguageDictionary.Languages',
        ]);
        $this->belongsToMany('Recordings', [
            'className' => 'DigitalAssetManager.Assets',
            'joinTable' => 'attachments',
            'foreignKey' => 'foreign_key',
            'targetForeignKey' => 'asset_id',
            'conditions' => [
                'Recordings.asset_type_id' => 4
            ],
        ]); 
        $this->hasMany('Attachments', [ 
            'className' => 'DigitalAssetManager.Attachments',
            'foreignKey' => 'foreign_key',
        ]); 
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('sense_id')
            ->notEmptyString('sense_id');

        $validator
            ->scalar('example_text')
            ->requirePresence('example_text', 'create')
            ->notEmptyString('example_text');

        $validator
            ->integer('language_id')
            ->allowEmptyString('language_id');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->existsIn(['sense_id'], 'Senses'), ['errorField' => 'sense_id']);
        $rules->add($rules->existsIn(['language_id'], 'Languages'), ['errorField' => 'language_id']);

        return $rules;
    }
}
