<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Table;

use Cake\ORM\Query\SelectQuery;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * LinguisticDescriptions Model
 *
 * @property \LanguageDictionary\Model\Table\LexicalEntriesTable&\Cake\ORM\Association\BelongsTo $LexicalEntries
 * @property \LanguageDictionary\Model\Table\SensesTable&\Cake\ORM\Association\BelongsTo $Senses
 * @property \LanguageDictionary\Model\Table\FormsTable&\Cake\ORM\Association\BelongsTo $Forms
 * @property \LanguageDictionary\Model\Table\LemonAttributesTable&\Cake\ORM\Association\BelongsTo $LemonAttributes
 * @property \LanguageDictionary\Model\Table\LdPropertiesTable&\Cake\ORM\Association\HasMany $LdProperties
 *
 * @method \LanguageDictionary\Model\Entity\LinguisticDescription newEmptyEntity()
 * @method \LanguageDictionary\Model\Entity\LinguisticDescription newEntity(array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\LinguisticDescription> newEntities(array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LinguisticDescription get(mixed $primaryKey, array|string $finder = 'all', \Psr\SimpleCache\CacheInterface|string|null $cache = null, \Closure|string|null $cacheKey = null, mixed ...$args)
 * @method \LanguageDictionary\Model\Entity\LinguisticDescription findOrCreate($search, ?callable $callback = null, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LinguisticDescription patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\LinguisticDescription> patchEntities(iterable $entities, array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LinguisticDescription|false save(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LinguisticDescription saveOrFail(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LinguisticDescription>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LinguisticDescription>|false saveMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LinguisticDescription>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LinguisticDescription> saveManyOrFail(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LinguisticDescription>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LinguisticDescription>|false deleteMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LinguisticDescription>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LinguisticDescription> deleteManyOrFail(iterable $entities, array $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class LinguisticDescriptionsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array<string, mixed> $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('linguistic_descriptions');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');
        $this->addBehavior('DigitalAssetManager.Attachable');
        // in the initialize() method
        $this->addBehavior('Muffin/Trash.Trash');
        $this->belongsTo('LexicalEntries', [
            'foreignKey' => 'lexical_entry_id',
            'className' => 'LanguageDictionary.LexicalEntries',
        ]);
        $this->belongsTo('Senses', [
            'foreignKey' => 'sense_id',
            'className' => 'LanguageDictionary.Senses',
        ]);
        $this->belongsTo('Forms', [
            'foreignKey' => 'form_id',
            'className' => 'LanguageDictionary.Forms',
        ]);
        // $this->belongsTo('LemonAttributes', [
        //     'foreignKey' => 'lemon_attribute_id',
        //     'joinType' => 'INNER',
        //     'className' => 'LanguageDictionary.LemonAttributes',
        // ]);
        $this->belongsTo('LemonAttributes', [
            'foreignKey' => 'lemon_attribute_id',
            // 'joinType' => 'LEFT',
            'joinType' => 'INNER',
            'className' => 'LanguageDictionary.LemonAttributes',
        ]);
        $this->belongsToMany('Languages', [
            'foreignKey' => 'linguistic_description_id',
            'targetForeignKey' => 'language_id',
            'joinTable' => 'languages_linguistic_descriptions',
            'className' => 'LanguageDictionary.Languages',
        ]);

        /**/ 
        $this->belongsToMany('Images', [
            'className' => 'DigitalAssetManager.Assets',
            'joinTable' => 'attachments',
            'foreignKey' => 'foreign_key',
            'targetForeignKey' => 'asset_id',
            'conditions' => [
                'Images.asset_type_id' => 6
            ],
        ]);
        /**/
        /**/
        $this->belongsToMany('Sounds', [
            'className' => 'DigitalAssetManager.Assets',
            'joinTable' => 'attachments',
            'foreignKey' => 'foreign_key',
            'targetForeignKey' => 'asset_id',
            'conditions' => [
                'Sounds.asset_type_id' => 4
            ],
        ]); 
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('lexical_entry_id')
            ->allowEmptyString('lexical_entry_id');

        $validator
            ->integer('sense_id')
            ->allowEmptyString('sense_id');

        $validator
            ->integer('form_id')
            ->allowEmptyString('form_id');

        $validator
            ->integer('lemon_attribute_id')
            ->notEmptyString('lemon_attribute_id');

        $validator
            ->scalar('value')
            ->maxLength('value', 255)
            ->allowEmptyString('value');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->existsIn(['lexical_entry_id'], 'LexicalEntries'), ['errorField' => 'lexical_entry_id']);
        $rules->add($rules->existsIn(['sense_id'], 'Senses'), ['errorField' => 'sense_id']);
        $rules->add($rules->existsIn(['form_id'], 'Forms'), ['errorField' => 'form_id']);
        $rules->add($rules->existsIn(['lemon_attribute_id'], 'LemonAttributes'), ['errorField' => 'lemon_attribute_id']);

        return $rules;
    }

    public function findValidForEntity(Query $query, array $options)
    {
        $entity = $options['entity'];
        $class  = $options['rdf_class'] ?? 'lemon:CanonicalForm';

        // Get properties already used by this entity
        $existingProps = Hash::extract($entity->linguistic_descriptions, '{n}.property');

        // Filter out properties that are single-use
        return $query
            ->where(['module' => 'linguistic_descriptions'])
            ->where(['rdf_class' => $class])
            ->where(function ($exp, $q) use ($existingProps) {
                return $exp->notIn('lemon_attributes.rdf_property', $existingProps);
            });
    }

}
