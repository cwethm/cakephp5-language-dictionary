<?php
// File: plugins/LanguageDictionary/src/Model/Table/LemonAttributeRangesTable.php
namespace LanguageDictionary\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;

class LemonAttributeRangesTable extends Table
{
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('lemon_attribute_ranges');
        $this->setPrimaryKey('id');

        $this->belongsTo('LemonAttributes', [
            'foreignKey' => 'lemon_attribute_id',
            'className' => 'LanguageDictionary.LemonAttributes',
        ]);
    }

    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->scalar('class_uri')->maxLength('class_uri', 512)->notEmptyString('class_uri');

        return $validator;
    }
}

