<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Table;

use Cake\ORM\Query\SelectQuery;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * DictionariesLexicalEntries Model
 *
 * @property \LanguageDictionary\Model\Table\DictionariesTable&\Cake\ORM\Association\BelongsTo $Dictionaries
 * @property \LanguageDictionary\Model\Table\LexicalEntriesTable&\Cake\ORM\Association\BelongsTo $LexicalEntries
 *
 * @method \LanguageDictionary\Model\Entity\DictionariesLexicalEntry newEmptyEntity()
 * @method \LanguageDictionary\Model\Entity\DictionariesLexicalEntry newEntity(array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\DictionariesLexicalEntry> newEntities(array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\DictionariesLexicalEntry get(mixed $primaryKey, array|string $finder = 'all', \Psr\SimpleCache\CacheInterface|string|null $cache = null, \Closure|string|null $cacheKey = null, mixed ...$args)
 * @method \LanguageDictionary\Model\Entity\DictionariesLexicalEntry findOrCreate($search, ?callable $callback = null, array $options = [])
 * @method \LanguageDictionary\Model\Entity\DictionariesLexicalEntry patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\DictionariesLexicalEntry> patchEntities(iterable $entities, array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\DictionariesLexicalEntry|false save(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method \LanguageDictionary\Model\Entity\DictionariesLexicalEntry saveOrFail(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\DictionariesLexicalEntry>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\DictionariesLexicalEntry>|false saveMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\DictionariesLexicalEntry>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\DictionariesLexicalEntry> saveManyOrFail(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\DictionariesLexicalEntry>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\DictionariesLexicalEntry>|false deleteMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\DictionariesLexicalEntry>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\DictionariesLexicalEntry> deleteManyOrFail(iterable $entities, array $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class DictionariesLexicalEntriesTable extends Table
{
    /**
     * Initialize method
     *
     * @param array<string, mixed> $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('dictionaries_lexical_entries');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Dictionaries', [
            'foreignKey' => 'dictionary_id',
            'joinType' => 'INNER',
            'className' => 'LanguageDictionary.Dictionaries',
        ]);
        $this->belongsTo('LexicalEntries', [
            'foreignKey' => 'lexical_entry_id',
            'joinType' => 'INNER',
            'className' => 'LanguageDictionary.LexicalEntries',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('dictionary_id')
            ->notEmptyString('dictionary_id');

        $validator
            ->integer('lexical_entry_id')
            ->notEmptyString('lexical_entry_id');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->isUnique(['dictionary_id', 'lexical_entry_id']), ['errorField' => 'dictionary_id']);
        $rules->add($rules->existsIn(['dictionary_id'], 'Dictionaries'), ['errorField' => 'dictionary_id']);
        $rules->add($rules->existsIn(['lexical_entry_id'], 'LexicalEntries'), ['errorField' => 'lexical_entry_id']);

        return $rules;
    }
}
