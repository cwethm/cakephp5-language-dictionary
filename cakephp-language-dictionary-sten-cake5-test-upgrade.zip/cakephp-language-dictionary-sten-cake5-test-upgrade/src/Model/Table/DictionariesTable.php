<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Table;

use Cake\ORM\Query\SelectQuery;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Dictionaries Model
 *
 * @property \LanguageDictionary\Model\Table\UsersTable&\Cake\ORM\Association\BelongsTo $Users
 * @property \LanguageDictionary\Model\Table\SynonymsTable&\Cake\ORM\Association\HasMany $Synonyms
 * @property \LanguageDictionary\Model\Table\LanguagesTable&\Cake\ORM\Association\BelongsToMany $Languages
 * @property \LanguageDictionary\Model\Table\LexicalEntriesTable&\Cake\ORM\Association\BelongsToMany $LexicalEntries
 *
 * @method \LanguageDictionary\Model\Entity\Dictionary newEmptyEntity()
 * @method \LanguageDictionary\Model\Entity\Dictionary newEntity(array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\Dictionary> newEntities(array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\Dictionary get(mixed $primaryKey, array|string $finder = 'all', \Psr\SimpleCache\CacheInterface|string|null $cache = null, \Closure|string|null $cacheKey = null, mixed ...$args)
 * @method \LanguageDictionary\Model\Entity\Dictionary findOrCreate($search, ?callable $callback = null, array $options = [])
 * @method \LanguageDictionary\Model\Entity\Dictionary patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\Dictionary> patchEntities(iterable $entities, array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\Dictionary|false save(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method \LanguageDictionary\Model\Entity\Dictionary saveOrFail(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\Dictionary>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\Dictionary>|false saveMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\Dictionary>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\Dictionary> saveManyOrFail(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\Dictionary>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\Dictionary>|false deleteMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\Dictionary>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\Dictionary> deleteManyOrFail(iterable $entities, array $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class DictionariesTable extends Table
{
    /**
     * Initialize method
     *
     * @param array<string, mixed> $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('dictionaries');
        $this->setDisplayField('name');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');
        // in the initialize() method
        $this->addBehavior('Muffin/Trash.Trash');

        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'joinType' => 'INNER',
            'className' => 'Usermgmt.Users',
        ]);
        $this->hasMany('Synonyms', [
            'foreignKey' => 'dictionary_id',
            'className' => 'LanguageDictionary.Synonyms',
        ]);
        $this->belongsToMany('Languages', [
            'foreignKey' => 'dictionary_id',
            'targetForeignKey' => 'language_id',
            'joinTable' => 'dictionaries_languages',
            'className' => 'LanguageDictionary.Languages',
        ]);
        $this->belongsToMany('LexicalEntries', [
            'foreignKey' => 'dictionary_id',
            'targetForeignKey' => 'lexical_entry_id',
            'joinTable' => 'dictionaries_lexical_entries',
            'className' => 'LanguageDictionary.LexicalEntries',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->uuid('user_id')
            ->notEmptyString('user_id');

        $validator
            ->scalar('slug')
            ->maxLength('slug', 255)
            ->allowEmptyString('slug');

        $validator
            ->integer('tag_count')
            ->allowEmptyString('tag_count');

        $validator
            ->scalar('name')
            ->maxLength('name', 255)
            ->requirePresence('name', 'create')
            ->notEmptyString('name');

        $validator
            ->scalar('description')
            ->requirePresence('description', 'create')
            ->notEmptyString('description');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->existsIn(['user_id'], 'Users'), ['errorField' => 'user_id']);

        return $rules;
    }
}
