<?php
namespace LanguageDictionary\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;

class LexinfoValuesTable extends Table
{
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('lexinfo_values');
        $this->setDisplayField('label');
        $this->setPrimaryKey('id');
    }

    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->scalar('category')
            ->maxLength('category', 128)
            ->allowEmptyString('category');

        $validator
            ->scalar('uri')
            ->maxLength('uri', 512)
            ->requirePresence('uri', 'create')
            ->notEmptyString('uri');

        $validator
            ->scalar('label')
            ->maxLength('label', 128)
            ->allowEmptyString('label');

        $validator
            ->scalar('code')
            ->maxLength('code', 64)
            ->allowEmptyString('code');

        $validator
            ->scalar('description')
            ->allowEmptyString('description');

        return $validator;
    }
}
