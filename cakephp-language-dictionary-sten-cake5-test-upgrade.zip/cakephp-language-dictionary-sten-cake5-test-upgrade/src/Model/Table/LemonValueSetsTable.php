<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Table;

use Cake\ORM\Query\SelectQuery;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * LemonValueSets Model
 *
 * @property \LanguageDictionary\Model\Table\LemonAttributesTable&\Cake\ORM\Association\BelongsTo $LemonAttributes
 *
 * @method \LanguageDictionary\Model\Entity\LemonValueSet newEmptyEntity()
 * @method \LanguageDictionary\Model\Entity\LemonValueSet newEntity(array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\LemonValueSet> newEntities(array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LemonValueSet get(mixed $primaryKey, array|string $finder = 'all', \Psr\SimpleCache\CacheInterface|string|null $cache = null, \Closure|string|null $cacheKey = null, mixed ...$args)
 * @method \LanguageDictionary\Model\Entity\LemonValueSet findOrCreate($search, ?callable $callback = null, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LemonValueSet patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\LemonValueSet> patchEntities(iterable $entities, array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LemonValueSet|false save(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LemonValueSet saveOrFail(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LemonValueSet>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LemonValueSet>|false saveMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LemonValueSet>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LemonValueSet> saveManyOrFail(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LemonValueSet>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LemonValueSet>|false deleteMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LemonValueSet>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LemonValueSet> deleteManyOrFail(iterable $entities, array $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class LemonValueSetsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array<string, mixed> $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('lemon_value_sets');
        $this->setDisplayField('name');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('LemonAttributes', [
            'foreignKey' => 'lemon_attribute_id',
            'joinType' => 'INNER',
            'className' => 'LanguageDictionary.LemonAttributes',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('lemon_attribute_id')
            ->notEmptyString('lemon_attribute_id');

        $validator
            ->scalar('set_name')
            ->maxLength('set_name', 42)
            ->allowEmptyString('set_name');

        $validator
            ->scalar('name')
            ->maxLength('name', 123)
            ->requirePresence('name', 'create')
            ->notEmptyString('name');

        $validator
            ->scalar('label')
            ->maxLength('label', 131)
            ->requirePresence('label', 'create')
            ->notEmptyString('label');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->existsIn(['lemon_attribute_id'], 'LemonAttributes'), ['errorField' => 'lemon_attribute_id']);

        return $rules;
    }
}
