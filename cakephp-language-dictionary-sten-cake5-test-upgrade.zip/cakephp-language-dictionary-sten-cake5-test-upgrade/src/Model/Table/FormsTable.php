<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Table;

use Cake\ORM\Query\SelectQuery;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Forms Model
 *
 * @property \LanguageDictionary\Model\Table\LexicalEntriesTable&\Cake\ORM\Association\BelongsTo $LexicalEntries
 * @property \LanguageDictionary\Model\Table\LanguagesTable&\Cake\ORM\Association\BelongsTo $Languages
 * @property \LanguageDictionary\Model\Table\LinguisticDescriptionsTable&\Cake\ORM\Association\HasMany $LinguisticDescriptions
 *
 * @method \LanguageDictionary\Model\Entity\Form newEmptyEntity()
 * @method \LanguageDictionary\Model\Entity\Form newEntity(array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\Form> newEntities(array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\Form get(mixed $primaryKey, array|string $finder = 'all', \Psr\SimpleCache\CacheInterface|string|null $cache = null, \Closure|string|null $cacheKey = null, mixed ...$args)
 * @method \LanguageDictionary\Model\Entity\Form findOrCreate($search, ?callable $callback = null, array $options = [])
 * @method \LanguageDictionary\Model\Entity\Form patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\Form> patchEntities(iterable $entities, array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\Form|false save(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method \LanguageDictionary\Model\Entity\Form saveOrFail(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\Form>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\Form>|false saveMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\Form>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\Form> saveManyOrFail(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\Form>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\Form>|false deleteMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\Form>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\Form> deleteManyOrFail(iterable $entities, array $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class FormsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array<string, mixed> $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('forms');
        $this->setDisplayField('form_type');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');
        // in the initialize() method
        $this->addBehavior('Muffin/Trash.Trash');

        $this->belongsTo('LexicalEntries', [
            'foreignKey' => 'lexical_entry_id',
            // 'joinType' => 'LEFT',
            'joinType' => 'INNER',
            'className' => 'LanguageDictionary.LexicalEntries',
        ]);
        $this->belongsTo('Languages', [
            'foreignKey' => 'language_id',
            'className' => 'LanguageDictionary.Languages',
        ]);
        $this->belongsTo('LemonAttributes', [
            'className' => 'LanguageDictionary.LemonAttributes',
            'foreignKey' => 'form_type',     // in Forms table
            'bindingKey' => 'uri',           // in LemonAttributes table
            'propertyName' => 'lemon_attribute',
            'joinType' => 'LEFT',
        ]);
        $this->hasMany('LinguisticDescriptions', [
            'foreignKey' => 'form_id',
            'className' => 'LanguageDictionary.LinguisticDescriptions',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('lexical_entry_id')
            ->notEmptyString('lexical_entry_id');

        $validator
            ->integer('language_id')
            ->allowEmptyString('language_id');

        $validator
            ->scalar('form_type')
            ->maxLength('form_type', 42)
            ->requirePresence('form_type', 'create')
            ->notEmptyString('form_type');

        $validator
            ->scalar('written_representation')
            ->maxLength('written_representation', 258)
            ->requirePresence('written_representation', 'create')
            ->notEmptyString('written_representation');

        $validator
            ->scalar('slug')
            ->maxLength('slug', 255)
            ->allowEmptyString('slug');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->existsIn(['lexical_entry_id'], 'LexicalEntries'), ['errorField' => 'lexical_entry_id']);
        $rules->add($rules->existsIn(['language_id'], 'Languages'), ['errorField' => 'language_id']);

        return $rules;
    }
}
