<?php
// File: plugins/LanguageDictionary/src/Model/Table/LemonAttributeCommentsTable.php
namespace LanguageDictionary\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;

class LemonAttributeCommentsTable extends Table
{
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('lemon_attribute_comments');
        $this->setPrimaryKey('id');

        $this->belongsTo('LemonAttributes', [
            'foreignKey' => 'lemon_attribute_id',
            'className' => 'LanguageDictionary.LemonAttributes',
        ]);
    }

    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->scalar('language')->maxLength('language', 10)->notEmptyString('language')
            ->scalar('comment')->maxLength('comment', 1000)->notEmptyString('comment');

        return $validator;
    }
}
