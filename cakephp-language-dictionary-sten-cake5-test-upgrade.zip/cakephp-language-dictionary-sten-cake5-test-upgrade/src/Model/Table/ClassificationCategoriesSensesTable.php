<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Table;

use Cake\ORM\Query\SelectQuery;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * ClassificationCategoriesSenses Model
 *
 * @property \LanguageDictionary\Model\Table\SensesTable&\Cake\ORM\Association\BelongsTo $Senses
 * @property \LanguageDictionary\Model\Table\ClassificationCategoriesTable&\Cake\ORM\Association\BelongsTo $ClassificationCategories
 *
 * @method \LanguageDictionary\Model\Entity\ClassificationCategoriesSense newEmptyEntity()
 * @method \LanguageDictionary\Model\Entity\ClassificationCategoriesSense newEntity(array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\ClassificationCategoriesSense> newEntities(array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\ClassificationCategoriesSense get(mixed $primaryKey, array|string $finder = 'all', \Psr\SimpleCache\CacheInterface|string|null $cache = null, \Closure|string|null $cacheKey = null, mixed ...$args)
 * @method \LanguageDictionary\Model\Entity\ClassificationCategoriesSense findOrCreate($search, ?callable $callback = null, array $options = [])
 * @method \LanguageDictionary\Model\Entity\ClassificationCategoriesSense patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\ClassificationCategoriesSense> patchEntities(iterable $entities, array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\ClassificationCategoriesSense|false save(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method \LanguageDictionary\Model\Entity\ClassificationCategoriesSense saveOrFail(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\ClassificationCategoriesSense>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\ClassificationCategoriesSense>|false saveMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\ClassificationCategoriesSense>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\ClassificationCategoriesSense> saveManyOrFail(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\ClassificationCategoriesSense>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\ClassificationCategoriesSense>|false deleteMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\ClassificationCategoriesSense>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\ClassificationCategoriesSense> deleteManyOrFail(iterable $entities, array $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class ClassificationCategoriesSensesTable extends Table
{
    /**
     * Initialize method
     *
     * @param array<string, mixed> $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('classification_categories_senses');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Senses', [
            'foreignKey' => 'sense_id',
            'joinType' => 'INNER',
            'className' => 'LanguageDictionary.Senses',
        ]);
        $this->belongsTo('ClassificationCategories', [
            'foreignKey' => 'classification_category_id',
            'joinType' => 'INNER',
            'className' => 'LanguageDictionary.ClassificationCategories',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('sense_id')
            ->notEmptyString('sense_id');

        $validator
            ->integer('classification_category_id')
            ->notEmptyString('classification_category_id');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->existsIn(['sense_id'], 'Senses'), ['errorField' => 'sense_id']);
        $rules->add($rules->existsIn(['classification_category_id'], 'ClassificationCategories'), ['errorField' => 'classification_category_id']);

        return $rules;
    }
}
