<?php
// File: plugins/LanguageDictionary/src/Model/Table/LemonAttributesTable.php

declare(strict_types=1);

namespace LanguageDictionary\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;

class LemonAttributesTable extends Table
{
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('lemon_attributes');
        $this->setPrimaryKey('id');
        $this->addBehavior('Timestamp');

        $this->hasMany('LemonAttributeLabels', [
            'foreignKey' => 'lemon_attribute_id',
            'className' => 'LanguageDictionary.LemonAttributeLabels'
        ]);

        $this->hasMany('LemonAttributeComments', [
            'className' => 'LanguageDictionary.LemonAttributeComments',
            'foreignKey' => 'lemon_attribute_id',
            'dependent' => true,
            'cascadeCallbacks' => true,
        ]);

        $this->hasMany('LemonAttributeDomains', [
            'className' => 'LanguageDictionary.LemonAttributeDomains',
            'foreignKey' => 'lemon_attribute_id',
            'dependent' => true,
            'cascadeCallbacks' => true,
        ]);

        $this->hasMany('LemonAttributeRanges', [
            'className' => 'LanguageDictionary.LemonAttributeRanges',
            'foreignKey' => 'lemon_attribute_id',
            'dependent' => true,
            'cascadeCallbacks' => true,
        ]);

        $this->hasMany('LemonAttributeRelations', [
            'className' => 'LanguageDictionary.LemonAttributeRelations',
            'foreignKey' => 'lemon_attribute_id',
            'dependent' => true,
            'cascadeCallbacks' => true,
        ]);

        $this->hasMany('LemonAttributeEnumerations', [
            'className' => 'LanguageDictionary.LemonAttributeEnumerations',
            'foreignKey' => 'lemon_attribute_id',
            'dependent' => true,
            'cascadeCallbacks' => true,
        ]);

        $this->hasMany('LemonAttributeTriggers', [
            'className' => 'LanguageDictionary.LemonAttributeTriggers',
            'foreignKey' => 'lemon_attribute_id',
            'dependent' => true,
            'cascadeCallbacks' => true,
        ]);
        $this->hasMany('Forms', [
            'className' => 'LanguageDictionary.Forms',
            'foreignKey' => 'form_type',
            'bindingKey' => 'uri',
        ]);

    }

    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->scalar('uri')->maxLength('uri', 512)->requirePresence('uri', 'create')->notEmptyString('uri')
            ->scalar('local_name')->maxLength('local_name', 128)
            ->allowEmptyString('local_name')
            ->scalar('model_class')->maxLength('model_class', 64)
            ->requirePresence('model_class', 'create')->notEmptyString('model_class');

        return $validator;
    }
    // In plugins/LanguageDictionary/src/Model/Table/LemonAttributesTable.php

    public function findFormTypeAttributes(\Cake\ORM\Query\SelectQuery $query, array $options): \Cake\ORM\Query\SelectQuery
    {
        return $query->matching('LemonAttributeRelations', function ($q) {
            return $q->where([
                'LemonAttributeRelations.relation_type' => 'rdfs:subPropertyOf',
                'LemonAttributeRelations.related_uri' => 'http://www.w3.org/ns/lemon/ontolex#LexicalForm'
            ]);
        });
    }


}
