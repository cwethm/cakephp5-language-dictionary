<?php
namespace LanguageDictionary\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;

class LemonAttributeRelationsTable extends Table
{
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('lemon_attribute_relations');
        $this->setPrimaryKey('id');
        $this->belongsTo('LemonAttributes', [
            'foreignKey' => 'lemon_attribute_id',
            'className' => 'LanguageDictionary.LemonAttributes',
            'joinType' => 'INNER'
        ]);
    }

    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('id')
            ->allowEmptyString('id', null, 'create');

        $validator
            ->integer('lemon_attribute_id')
            ->requirePresence('lemon_attribute_id', 'create')
            ->notEmptyString('lemon_attribute_id');

        $validator
            ->scalar('relation_type')
            ->maxLength('relation_type', 64)
            ->requirePresence('relation_type', 'create')
            ->notEmptyString('relation_type');

        $validator
            ->scalar('related_uri')
            ->maxLength('related_uri', 512)
            ->requirePresence('related_uri', 'create')
            ->notEmptyString('related_uri');

        return $validator;
    }
}
