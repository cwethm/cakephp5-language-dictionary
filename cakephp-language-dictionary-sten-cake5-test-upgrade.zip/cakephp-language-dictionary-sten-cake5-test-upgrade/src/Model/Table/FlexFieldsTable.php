<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Table;

use Cake\ORM\Query\SelectQuery;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * FlexFields Model
 *
 * @property \LanguageDictionary\Model\Table\UsersTable&\Cake\ORM\Association\BelongsTo $Users
 *
 * @method \LanguageDictionary\Model\Entity\FlexField newEmptyEntity()
 * @method \LanguageDictionary\Model\Entity\FlexField newEntity(array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\FlexField> newEntities(array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\FlexField get(mixed $primaryKey, array|string $finder = 'all', \Psr\SimpleCache\CacheInterface|string|null $cache = null, \Closure|string|null $cacheKey = null, mixed ...$args)
 * @method \LanguageDictionary\Model\Entity\FlexField findOrCreate($search, ?callable $callback = null, array $options = [])
 * @method \LanguageDictionary\Model\Entity\FlexField patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\FlexField> patchEntities(iterable $entities, array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\FlexField|false save(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method \LanguageDictionary\Model\Entity\FlexField saveOrFail(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\FlexField>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\FlexField>|false saveMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\FlexField>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\FlexField> saveManyOrFail(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\FlexField>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\FlexField>|false deleteMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\FlexField>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\FlexField> deleteManyOrFail(iterable $entities, array $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class FlexFieldsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array<string, mixed> $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('flex_fields');
        $this->setDisplayField('flex_key');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'className' => 'LanguageDictionary.Users',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->scalar('slug')
            ->maxLength('slug', 255)
            ->allowEmptyString('slug');

        $validator
            ->integer('word_id')
            ->requirePresence('word_id', 'create')
            ->notEmptyString('word_id');

        $validator
            ->scalar('flex_key')
            ->maxLength('flex_key', 131)
            ->requirePresence('flex_key', 'create')
            ->notEmptyString('flex_key');

        $validator
            ->scalar('flex_value')
            ->maxLength('flex_value', 255)
            ->requirePresence('flex_value', 'create')
            ->notEmptyString('flex_value');

        $validator
            ->scalar('second_value')
            ->maxLength('second_value', 123)
            ->allowEmptyString('second_value');

        $validator
            ->integer('user_id')
            ->allowEmptyString('user_id');

        $validator
            ->boolean('active')
            ->allowEmptyString('active');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->existsIn(['user_id'], 'Users'), ['errorField' => 'user_id']);

        return $rules;
    }
}
