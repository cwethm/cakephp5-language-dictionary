<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Table;

use Cake\ORM\Query\SelectQuery;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * LdProperties Model
 *
 * @property \LanguageDictionary\Model\Table\LinguisticDescriptionsTable&\Cake\ORM\Association\BelongsTo $LinguisticDescriptions
 * @property \LanguageDictionary\Model\Table\LemonAttributesTable&\Cake\ORM\Association\BelongsTo $LemonAttributes
 *
 * @method \LanguageDictionary\Model\Entity\LdProperty newEmptyEntity()
 * @method \LanguageDictionary\Model\Entity\LdProperty newEntity(array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\LdProperty> newEntities(array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LdProperty get(mixed $primaryKey, array|string $finder = 'all', \Psr\SimpleCache\CacheInterface|string|null $cache = null, \Closure|string|null $cacheKey = null, mixed ...$args)
 * @method \LanguageDictionary\Model\Entity\LdProperty findOrCreate($search, ?callable $callback = null, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LdProperty patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\LdProperty> patchEntities(iterable $entities, array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LdProperty|false save(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LdProperty saveOrFail(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LdProperty>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LdProperty>|false saveMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LdProperty>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LdProperty> saveManyOrFail(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LdProperty>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LdProperty>|false deleteMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LdProperty>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LdProperty> deleteManyOrFail(iterable $entities, array $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class LdPropertiesTable extends Table
{
    /**
     * Initialize method
     *
     * @param array<string, mixed> $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('ld_properties');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('LinguisticDescriptions', [
            'foreignKey' => 'linguistic_description_id',
            'joinType' => 'INNER',
            'className' => 'LanguageDictionary.LinguisticDescriptions',
        ]);
        $this->belongsTo('LemonAttributes', [
            'foreignKey' => 'lemon_attribute_id',
            'joinType' => 'INNER',
            'className' => 'LanguageDictionary.LemonAttributes',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->nonNegativeInteger('linguistic_description_id')
            ->notEmptyString('linguistic_description_id');

        $validator
            ->integer('lemon_attribute_id')
            ->notEmptyString('lemon_attribute_id');

        $validator
            ->scalar('value')
            ->maxLength('value', 255)
            ->allowEmptyString('value');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->existsIn(['linguistic_description_id'], 'LinguisticDescriptions'), ['errorField' => 'linguistic_description_id']);
        $rules->add($rules->existsIn(['lemon_attribute_id'], 'LemonAttributes'), ['errorField' => 'lemon_attribute_id']);

        return $rules;
    }
}
