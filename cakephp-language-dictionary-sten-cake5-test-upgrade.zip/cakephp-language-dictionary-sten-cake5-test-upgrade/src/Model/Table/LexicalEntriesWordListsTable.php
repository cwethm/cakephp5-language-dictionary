<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Table;

use Cake\ORM\Query\SelectQuery;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * LexicalEntriesWordLists Model
 *
 * @property \LanguageDictionary\Model\Table\LexicalEntriesTable&\Cake\ORM\Association\BelongsTo $LexicalEntries
 * @property \LanguageDictionary\Model\Table\WordListsTable&\Cake\ORM\Association\BelongsTo $WordLists
 *
 * @method \LanguageDictionary\Model\Entity\LexicalEntriesWordList newEmptyEntity()
 * @method \LanguageDictionary\Model\Entity\LexicalEntriesWordList newEntity(array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\LexicalEntriesWordList> newEntities(array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LexicalEntriesWordList get(mixed $primaryKey, array|string $finder = 'all', \Psr\SimpleCache\CacheInterface|string|null $cache = null, \Closure|string|null $cacheKey = null, mixed ...$args)
 * @method \LanguageDictionary\Model\Entity\LexicalEntriesWordList findOrCreate($search, ?callable $callback = null, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LexicalEntriesWordList patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\LexicalEntriesWordList> patchEntities(iterable $entities, array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LexicalEntriesWordList|false save(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LexicalEntriesWordList saveOrFail(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LexicalEntriesWordList>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LexicalEntriesWordList>|false saveMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LexicalEntriesWordList>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LexicalEntriesWordList> saveManyOrFail(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LexicalEntriesWordList>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LexicalEntriesWordList>|false deleteMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LexicalEntriesWordList>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LexicalEntriesWordList> deleteManyOrFail(iterable $entities, array $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class LexicalEntriesWordListsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array<string, mixed> $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('lexical_entries_word_lists');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('LexicalEntries', [
            'foreignKey' => 'lexical_entry_id',
            'joinType' => 'INNER',
            'className' => 'LanguageDictionary.LexicalEntries',
        ]);
        $this->belongsTo('WordLists', [
            'foreignKey' => 'word_list_id',
            'joinType' => 'INNER',
            'className' => 'LanguageDictionary.WordLists',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('lexical_entry_id')
            ->notEmptyString('lexical_entry_id');

        $validator
            ->integer('word_list_id')
            ->notEmptyString('word_list_id');

        $validator
            ->scalar('state')
            ->maxLength('state', 23)
            ->allowEmptyString('state');

        $validator
            ->scalar('note')
            ->maxLength('note', 255)
            ->allowEmptyString('note');

        $validator
            ->integer('modified_by')
            ->allowEmptyString('modified_by');

        $validator
            ->integer('created_by')
            ->allowEmptyString('created_by');

        $validator
            ->dateTime('trashed')
            ->allowEmptyDateTime('trashed');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->existsIn(['lexical_entry_id'], 'LexicalEntries'), ['errorField' => 'lexical_entry_id']);
        $rules->add($rules->existsIn(['word_list_id'], 'WordLists'), ['errorField' => 'word_list_id']);

        return $rules;
    }
}
