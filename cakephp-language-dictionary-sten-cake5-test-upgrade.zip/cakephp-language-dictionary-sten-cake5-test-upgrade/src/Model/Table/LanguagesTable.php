<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Table;

use Cake\ORM\Query\SelectQuery;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Languages Model
 *
 * @property \LanguageDictionary\Model\Table\FormsTable&\Cake\ORM\Association\HasMany $Forms
 * @property \LanguageDictionary\Model\Table\LexicalEntriesTable&\Cake\ORM\Association\HasMany $LexicalEntries
 * @property \LanguageDictionary\Model\Table\SynonymsTable&\Cake\ORM\Association\HasMany $Synonyms
 * @property \LanguageDictionary\Model\Table\UsageExamplesTable&\Cake\ORM\Association\HasMany $UsageExamples
 * @property \LanguageDictionary\Model\Table\DictionariesTable&\Cake\ORM\Association\BelongsToMany $Dictionaries
 * @property \LanguageDictionary\Model\Table\LinguisticDescriptionsTable&\Cake\ORM\Association\BelongsToMany $LinguisticDescriptions
 *
 * @method \LanguageDictionary\Model\Entity\Language newEmptyEntity()
 * @method \LanguageDictionary\Model\Entity\Language newEntity(array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\Language> newEntities(array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\Language get(mixed $primaryKey, array|string $finder = 'all', \Psr\SimpleCache\CacheInterface|string|null $cache = null, \Closure|string|null $cacheKey = null, mixed ...$args)
 * @method \LanguageDictionary\Model\Entity\Language findOrCreate($search, ?callable $callback = null, array $options = [])
 * @method \LanguageDictionary\Model\Entity\Language patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\Language> patchEntities(iterable $entities, array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\Language|false save(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method \LanguageDictionary\Model\Entity\Language saveOrFail(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\Language>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\Language>|false saveMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\Language>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\Language> saveManyOrFail(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\Language>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\Language>|false deleteMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\Language>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\Language> deleteManyOrFail(iterable $entities, array $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class LanguagesTable extends Table
{
    /**
     * Initialize method
     *
     * @param array<string, mixed> $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('languages');
        $this->setDisplayField('name');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->hasMany('Forms', [
            'foreignKey' => 'language_id',
            'className' => 'LanguageDictionary.Forms',
        ]);
        $this->hasMany('LexicalEntries', [
            'foreignKey' => 'language_id',
            'className' => 'LanguageDictionary.LexicalEntries',
        ]);
        $this->hasMany('Synonyms', [
            'foreignKey' => 'language_id',
            'className' => 'LanguageDictionary.Synonyms',
        ]);
        $this->hasMany('UsageExamples', [
            'foreignKey' => 'language_id',
            'className' => 'LanguageDictionary.UsageExamples',
        ]);
        $this->belongsToMany('Dictionaries', [
            'foreignKey' => 'language_id',
            'targetForeignKey' => 'dictionary_id',
            'joinTable' => 'dictionaries_languages',
            'className' => 'LanguageDictionary.Dictionaries',
        ]);
        $this->belongsToMany('LinguisticDescriptions', [
            'foreignKey' => 'language_id',
            'targetForeignKey' => 'linguistic_description_id',
            'joinTable' => 'languages_linguistic_descriptions',
            'className' => 'LanguageDictionary.LinguisticDescriptions',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->scalar('name')
            ->maxLength('name', 255)
            ->requirePresence('name', 'create')
            ->notEmptyString('name');

        $validator
            ->scalar('abbreviation')
            ->maxLength('abbreviation', 10)
            ->requirePresence('abbreviation', 'create')
            ->notEmptyString('abbreviation');

        $validator
            ->scalar('letters')
            ->maxLength('letters', 255)
            ->allowEmptyString('letters');

        $validator
            ->scalar('keyboard_characters')
            ->maxLength('keyboard_characters', 255)
            ->allowEmptyString('keyboard_characters');

        $validator
            ->dateTime('trashed')
            ->allowEmptyDateTime('trashed');

        return $validator;
    }
}
