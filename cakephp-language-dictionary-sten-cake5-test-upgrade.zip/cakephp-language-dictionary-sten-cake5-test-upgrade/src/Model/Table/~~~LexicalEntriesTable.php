<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Table;

use Cake\ORM\Query\SelectQuery;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * LexicalEntries Model
 *
 * @property \LanguageDictionary\Model\Table\LanguagesTable&\Cake\ORM\Association\BelongsTo $Languages
 * @property \LanguageDictionary\Model\Table\UsersTable&\Cake\ORM\Association\BelongsTo $Users
 * @property \LanguageDictionary\Model\Table\FormsTable&\Cake\ORM\Association\HasMany $Forms
 * @property \LanguageDictionary\Model\Table\LinguisticDescriptionsTable&\Cake\ORM\Association\HasMany $LinguisticDescriptions
 * @property \LanguageDictionary\Model\Table\LinguisticLinksTable&\Cake\ORM\Association\HasMany $LinguisticLinks
 * @property \LanguageDictionary\Model\Table\SensesTable&\Cake\ORM\Association\HasMany $Senses
 * @property \LanguageDictionary\Model\Table\DictionariesTable&\Cake\ORM\Association\BelongsToMany $Dictionaries
 * @property \LanguageDictionary\Model\Table\WordListsTable&\Cake\ORM\Association\BelongsToMany $WordLists
 *
 * @method \LanguageDictionary\Model\Entity\LexicalEntry newEmptyEntity()
 * @method \LanguageDictionary\Model\Entity\LexicalEntry newEntity(array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\LexicalEntry> newEntities(array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LexicalEntry get(mixed $primaryKey, array|string $finder = 'all', \Psr\SimpleCache\CacheInterface|string|null $cache = null, \Closure|string|null $cacheKey = null, mixed ...$args)
 * @method \LanguageDictionary\Model\Entity\LexicalEntry findOrCreate($search, ?callable $callback = null, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LexicalEntry patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\LexicalEntry> patchEntities(iterable $entities, array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LexicalEntry|false save(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LexicalEntry saveOrFail(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LexicalEntry>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LexicalEntry>|false saveMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LexicalEntry>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LexicalEntry> saveManyOrFail(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LexicalEntry>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LexicalEntry>|false deleteMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LexicalEntry>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LexicalEntry> deleteManyOrFail(iterable $entities, array $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class LexicalEntriesTable extends Table
{
    /**
     * Initialize method
     *
     * @param array<string, mixed> $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('lexical_entries');
        $this->setDisplayField('name');
        $this->setPrimaryKey('id');

        $this->addBehavior('DigitalAssetManager.Attachable');
        $this->addBehavior('Timestamp');
        // in the initialize() method
        $this->addBehavior('Muffin/Trash.Trash');

        $this->belongsTo('Languages', [
            'foreignKey' => 'language_id',
            'className' => 'LanguageDictionary.Languages',
        ]);
        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'className' => 'Usermgmt.Users',
        ]);
        $this->hasMany('Forms', [
            'foreignKey' => 'lexical_entry_id',
            'className' => 'LanguageDictionary.Forms',
            'conditions' => ['Forms.form_type !=' => 'query_string_form']
        ]);
        $this->hasMany('HiddenForms', [
            'foreignKey' => 'lexical_entry_id',
            'className' => 'LanguageDictionary.Forms',
            'conditions' => ['HiddenForms.form_type IN' => ['query_string_form']]
        ]);
        /**/ 
        $this->hasOne('CanonicalForm', [ 
            'foreignKey' => 'lexical_entry_id',
            'className' => 'LanguageDictionary.Forms',
            'conditions' => ['CanonicalForm.form_type' => 'canonical']
        ]);
        $this->hasOne('TranslateableAsForm', [ 
            'foreignKey' => 'lexical_entry_id',
            'className' => 'LanguageDictionary.Forms',
            'conditions' => ['TranslateableAsForm.form_type' => 'translateable_as']
        ]);
        $this->hasMany('LinguisticDescriptions', [
            'foreignKey' => 'lexical_entry_id',
            'className' => 'LanguageDictionary.LinguisticDescriptions',
        ]);
        $this->hasMany('SampleSentences', [
            'foreignKey' => 'lexical_entry_id',
            'className' => 'LanguageDictionary.LinguisticDescriptions',
            'conditions' => [
                'SampleSentences.lemon_attribute_id' => 22
            ],
        ]);
        /**/ 
        $this->belongsToMany('ImageAssets', [
            'className' => 'DigitalAssetManager.Assets',
            'joinTable' => 'attachments',
            'foreignKey' => 'foreign_key',
            'targetForeignKey' => 'asset_id',
            'conditions' => [
                'Images.asset_type_id' => 6
            ],
        ]);
        /**/
        /**/
        $this->belongsToMany('SoundAssets', [
            'className' => 'DigitalAssetManager.Assets',
            'joinTable' => 'attachments',
            'foreignKey' => 'foreign_key',
            'targetForeignKey' => 'asset_id',
            'conditions' => [
                'Sounds.asset_type_id' => 4
            ],
        ]); 
        $this->hasMany('Senses', [
            'foreignKey' => 'lexical_entry_id',
            'className' => 'LanguageDictionary.Senses',
        ]);
        $this->belongsToMany('Dictionaries', [
            'foreignKey' => 'lexical_entry_id',
            'targetForeignKey' => 'dictionary_id',
            'joinTable' => 'dictionaries_lexical_entries',
            'className' => 'LanguageDictionary.Dictionaries',
        ]);
        $this->belongsToMany('WordLists', [
            'foreignKey' => 'lexical_entry_id',
            'targetForeignKey' => 'word_list_id',
            'joinTable' => 'lexical_entries_word_lists',
            'className' => 'LanguageDictionary.WordLists',
        ]); 
        
    $this->hasMany('Attachments', [
        'className' => 'DigitalAssetManager.Attachments',
        'foreignKey' => 'foreign_key',
        'conditions' => [
            'Attachments.model' => 'LanguageDictionary.LexicalEntries',
        ],
        'dependent' => true,
        'cascadeCallbacks' => true,
    ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->scalar('slug')
            ->maxLength('slug', 143)
            ->allowEmptyString('slug');

        $validator
            ->scalar('entry_type')
            ->maxLength('entry_type', 37)
            ->requirePresence('entry_type', 'create')
            ->notEmptyString('entry_type');

        $validator
            ->scalar('name')
            ->maxLength('name', 255)
            ->requirePresence('name', 'create')
            ->notEmptyString('name');

        $validator
            ->scalar('translated')
            ->maxLength('translated', 258)
            ->allowEmptyString('translated');

        $validator
            ->scalar('part_of_speech')
            ->maxLength('part_of_speech', 42)
            ->allowEmptyString('part_of_speech');

        $validator
            ->integer('language_id')
            ->allowEmptyString('language_id');

        $validator
            ->integer('coverimg')
            ->allowEmptyString('coverimg');

        $validator
            ->integer('coversound')
            ->allowEmptyString('coversound');

        $validator
            ->integer('tag_count')
            ->allowEmptyString('tag_count');

        $validator
            ->dateTime('trashed')
            ->allowEmptyDateTime('trashed');

        $validator
            ->integer('user_id')
            ->allowEmptyString('user_id');

        $validator
            ->integer('created_by')
            ->allowEmptyString('created_by');

        $validator
            ->integer('modified_by')
            ->allowEmptyString('modified_by');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->existsIn(['language_id'], 'Languages'), ['errorField' => 'language_id']);
        $rules->add($rules->existsIn(['user_id'], 'Users'), ['errorField' => 'user_id']);

        return $rules;
    }
}
