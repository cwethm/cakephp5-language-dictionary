<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Table;

use Cake\ORM\Query\SelectQuery;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * LemonAttributes Model
 *
 * @property \LanguageDictionary\Model\Table\LdPropertiesTable&\Cake\ORM\Association\HasMany $LdProperties
 * @property \LanguageDictionary\Model\Table\LemonValueSetsTable&\Cake\ORM\Association\HasMany $LemonValueSets
 * @property \LanguageDictionary\Model\Table\LinguisticDescriptionsTable&\Cake\ORM\Association\HasMany $LinguisticDescriptions
 * @property \LanguageDictionary\Model\Table\LinguisticLinksTable&\Cake\ORM\Association\HasMany $LinguisticLinks
 *
 * @method \LanguageDictionary\Model\Entity\LemonAttribute newEmptyEntity()
 * @method \LanguageDictionary\Model\Entity\LemonAttribute newEntity(array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\LemonAttribute> newEntities(array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LemonAttribute get(mixed $primaryKey, array|string $finder = 'all', \Psr\SimpleCache\CacheInterface|string|null $cache = null, \Closure|string|null $cacheKey = null, mixed ...$args)
 * @method \LanguageDictionary\Model\Entity\LemonAttribute findOrCreate($search, ?callable $callback = null, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LemonAttribute patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\LemonAttribute> patchEntities(iterable $entities, array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LemonAttribute|false save(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LemonAttribute saveOrFail(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LemonAttribute>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LemonAttribute>|false saveMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LemonAttribute>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LemonAttribute> saveManyOrFail(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LemonAttribute>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LemonAttribute>|false deleteMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LemonAttribute>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LemonAttribute> deleteManyOrFail(iterable $entities, array $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class LemonAttributesTable extends Table
{
    /**
     * Initialize method
     *
     * @param array<string, mixed> $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('lemon_attributes');
        $this->setDisplayField('name');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');
        // in the initialize() method
        // $this->addBehavior('Muffin/Trash.Trash');

        $this->hasMany('LdProperties', [
            'foreignKey' => 'lemon_attribute_id',
            'className' => 'LanguageDictionary.LdProperties',
        ]);
        $this->hasMany('LemonValueSets', [
            'foreignKey' => 'lemon_attribute_id',
            'className' => 'LanguageDictionary.LemonValueSets',
        ]);
        // $this->hasMany('LinguisticDescriptions', [
        //     'foreignKey' => 'lemon_attribute_id',
        //     'className' => 'LanguageDictionary.LinguisticDescriptions',
        // ]);
        // $this->hasMany('LinguisticDescriptions', [
        //     'foreignKey' => 'lemon_attribute_id',
        //     'className' => 'LanguageDictionary.LinguisticDescriptions',
        // ]);
        $this->hasMany('LinguisticDescriptions', [
            'foreignKey' => 'lemon_attribute_id',
            'className' => 'LanguageDictionary.LinguisticDescriptions',
        ]);
        $this->hasMany('LinguisticLinks', [
            'foreignKey' => 'lemon_attribute_id',
            'className' => 'LanguageDictionary.LinguisticLinks',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->scalar('lemon_class')
            ->maxLength('lemon_class', 55)
            ->requirePresence('lemon_class', 'create')
            ->notEmptyString('lemon_class');

        $validator
            ->scalar('module')
            ->maxLength('module', 55)
            ->requirePresence('module', 'create')
            ->notEmptyString('module');

        $validator
            ->scalar('model_class')
            ->maxLength('model_class', 163)
            ->requirePresence('model_class', 'create')
            ->notEmptyString('model_class');

        $validator
            ->scalar('name')
            ->maxLength('name', 221)
            ->requirePresence('name', 'create')
            ->notEmptyString('name');

        $validator
            ->scalar('type')
            ->maxLength('type', 31)
            ->requirePresence('type', 'create')
            ->notEmptyString('type');

        $validator
            ->scalar('entry_type')
            ->maxLength('entry_type', 82)
            ->allowEmptyString('entry_type');

        $validator
            ->scalar('notes')
            ->maxLength('notes', 255)
            ->requirePresence('notes', 'create')
            ->notEmptyString('notes');

        $validator
            ->scalar('cardinality_min')
            ->maxLength('cardinality_min', 11)
            ->allowEmptyString('cardinality_min');

        $validator
            ->scalar('cardinality_max')
            ->maxLength('cardinality_max', 11)
            ->allowEmptyString('cardinality_max');

        return $validator;
    }
}
