<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Table;

use Cake\ORM\Query\SelectQuery;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Senses Model
 *
 * @property \LanguageDictionary\Model\Table\LexicalEntriesTable&\Cake\ORM\Association\BelongsTo $LexicalEntries
 * @property \LanguageDictionary\Model\Table\LinguisticDescriptionsTable&\Cake\ORM\Association\HasMany $LinguisticDescriptions
 * @property \LanguageDictionary\Model\Table\ClassificationCategoriesTable&\Cake\ORM\Association\BelongsToMany $ClassificationCategories
 *
 * @method \LanguageDictionary\Model\Entity\Sense newEmptyEntity()
 * @method \LanguageDictionary\Model\Entity\Sense newEntity(array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\Sense> newEntities(array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\Sense get(mixed $primaryKey, array|string $finder = 'all', \Psr\SimpleCache\CacheInterface|string|null $cache = null, \Closure|string|null $cacheKey = null, mixed ...$args)
 * @method \LanguageDictionary\Model\Entity\Sense findOrCreate($search, ?callable $callback = null, array $options = [])
 * @method \LanguageDictionary\Model\Entity\Sense patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\Sense> patchEntities(iterable $entities, array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\Sense|false save(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method \LanguageDictionary\Model\Entity\Sense saveOrFail(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\Sense>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\Sense>|false saveMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\Sense>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\Sense> saveManyOrFail(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\Sense>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\Sense>|false deleteMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\Sense>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\Sense> deleteManyOrFail(iterable $entities, array $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class SensesTable extends Table
{
    /**
     * Initialize method
     *
     * @param array<string, mixed> $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('senses');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');
        // in the initialize() method
        $this->addBehavior('Muffin/Trash.Trash');

        $this->belongsTo('LexicalEntries', [
            'foreignKey' => 'lexical_entry_id',
            'joinType' => 'INNER',
            'className' => 'LanguageDictionary.LexicalEntries',
        ]);
        $this->hasMany('LinguisticDescriptions', [
            'foreignKey' => 'sense_id',
            'className' => 'LanguageDictionary.LinguisticDescriptions',
        ]);
        $this->hasMany('UsageExamples', [
            'foreignKey' => 'sense_id',
            'className' => 'LanguageDictionary.UsageExamples'
        ]);
        // $this->belongsTo('CoverImg', [
        //     'className' => 'DigitalAssetManager.Assets', 
        //     'foreignKey' => 'coverimg',
        //     'conditions' => [
        //         'CoverImg.asset_type_id' => 6
        //     ],
        // ]); 
        // $this->belongsTo('CoverImageAsset', [
        //     'className' => 'DigitalAssetManager.Assets',
        //     'foreignKey' => 'coverimg',
        //     'conditions' => ['CoverImageAsset.asset_type_id' => 6],
        // ]);
        // $this->belongsTo('CoverSoundAsset', [
        //     'className' => 'DigitalAssetManager.Assets', 
        //     'foreignKey' => 'coversnd',
        //     'conditions' => [
        //         'CoverSound.asset_type_id' => 4
        //     ],
                // ]); 
        $this->belongsTo('CoverImageAsset', [
            'className' => 'DigitalAssetManager.Assets',
            'foreignKey' => 'coverimg',
            'propertyName' => 'cover_image_asset',
        ]);
        $this->belongsTo('CoverSoundAsset', [
            'className' => 'DigitalAssetManager.Assets',
            'foreignKey' => 'coversnd',
            'propertyName' => 'cover_sound_asset',
        ]);

        $this->belongsToMany('ClassificationCategories', [
            'foreignKey' => 'sense_id',
            'targetForeignKey' => 'classification_category_id',
            'joinTable' => 'classification_categories_senses',
            'className' => 'LanguageDictionary.ClassificationCategories',
        ]);
        $this->belongsToMany('Assets', [
            'className' => 'DigitalAssetManager.Assets',
            'joinTable' => 'attachments',
            'foreignKey' => 'Attachments.asset_id',
        ]);
        $this->hasMany('Attachments', [ 
            'className' => 'DigitalAssetManager.Attachments',
            'foreignKey' => 'foreign_key',
        ]); 
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('lexical_entry_id')
            ->notEmptyString('lexical_entry_id');

        $validator
            ->scalar('slug')
            ->maxLength('slug', 255)
            ->allowEmptyString('slug');

        $validator
            ->scalar('entry_name')
            ->maxLength('entry_name', 42)
            ->allowEmptyString('entry_name');

        $validator
            ->scalar('definition')
            ->allowEmptyString('definition');

        $validator
            ->integer('coverimg')
            ->allowEmptyString('coverimg');

        $validator
            ->integer('coversnd')
            ->allowEmptyString('coversnd');

        $validator
            ->scalar('reference')
            ->maxLength('reference', 255)
            ->allowEmptyString('reference');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->existsIn(['lexical_entry_id'], 'LexicalEntries'), ['errorField' => 'lexical_entry_id']);

        return $rules;
    }
}
