<?php
declare(strict_types=1);

namespace LanguageDictionary\Model\Table;

use Cake\ORM\Query\SelectQuery;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * LexicalEntries Model
 *
 * @property \LanguageDictionary\Model\Table\LanguagesTable&\Cake\ORM\Association\BelongsTo $Languages
 * @property \LanguageDictionary\Model\Table\UsersTable&\Cake\ORM\Association\BelongsTo $Users
 * @property \LanguageDictionary\Model\Table\FormsTable&\Cake\ORM\Association\HasMany $Forms
 * @property \LanguageDictionary\Model\Table\LinguisticDescriptionsTable&\Cake\ORM\Association\HasMany $LinguisticDescriptions
 * @property \LanguageDictionary\Model\Table\LinguisticLinksTable&\Cake\ORM\Association\HasMany $LinguisticLinks
 * @property \LanguageDictionary\Model\Table\SensesTable&\Cake\ORM\Association\HasMany $Senses
 * @property \LanguageDictionary\Model\Table\DictionariesTable&\Cake\ORM\Association\BelongsToMany $Dictionaries
 * @property \LanguageDictionary\Model\Table\WordListsTable&\Cake\ORM\Association\BelongsToMany $WordLists
 *
 * @method \LanguageDictionary\Model\Entity\LexicalEntry newEmptyEntity()
 * @method \LanguageDictionary\Model\Entity\LexicalEntry newEntity(array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\LexicalEntry> newEntities(array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LexicalEntry get(mixed $primaryKey, array|string $finder = 'all', \Psr\SimpleCache\CacheInterface|string|null $cache = null, \Closure|string|null $cacheKey = null, mixed ...$args)
 * @method \LanguageDictionary\Model\Entity\LexicalEntry findOrCreate($search, ?callable $callback = null, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LexicalEntry patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method array<\LanguageDictionary\Model\Entity\LexicalEntry> patchEntities(iterable $entities, array $data, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LexicalEntry|false save(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method \LanguageDictionary\Model\Entity\LexicalEntry saveOrFail(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LexicalEntry>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LexicalEntry>|false saveMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LexicalEntry>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LexicalEntry> saveManyOrFail(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LexicalEntry>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LexicalEntry>|false deleteMany(iterable $entities, array $options = [])
 * @method iterable<\LanguageDictionary\Model\Entity\LexicalEntry>|\Cake\Datasource\ResultSetInterface<\LanguageDictionary\Model\Entity\LexicalEntry> deleteManyOrFail(iterable $entities, array $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class LexicalEntriesTable extends Table
{
    /**
     * Initialize method
     *
     * @param array<string, mixed> $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('lexical_entries');
        $this->setDisplayField('name');
        $this->setPrimaryKey('id');

        $this->addBehavior('DigitalAssetManager.Attachable');
        $this->addBehavior('Timestamp');
        // in the initialize() method
        $this->addBehavior('Muffin/Trash.Trash');

        $this->belongsTo('Languages', [
            'foreignKey' => 'language_id',
            'className' => 'LanguageDictionary.Languages',
        ]);
        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'className' => 'Usermgmt.Users',
        ]);
        $this->hasMany('Forms', [
            'foreignKey' => 'lexical_entry_id',
            'className' => 'LanguageDictionary.Forms',
            'conditions' => ['Forms.form_type !=' => 'query_string_form']
        ]);
        $this->hasMany('HiddenForms', [
            'foreignKey' => 'lexical_entry_id',
            'className' => 'LanguageDictionary.Forms',
            'conditions' => ['HiddenForms.form_type IN' => ['query_string_form']]
        ]);
        /**/ 
        $this->hasOne('CanonicalForm', [ 
            'foreignKey' => 'lexical_entry_id',
            'className' => 'LanguageDictionary.Forms',
            'conditions' => ['CanonicalForm.form_type' => 'canonical']
        ]);
        $this->hasOne('TranslateableAsForm', [ 
            'foreignKey' => 'lexical_entry_id',
            'className' => 'LanguageDictionary.Forms',
            'conditions' => ['TranslateableAsForm.form_type' => 'translateable_as']
        ]);
        $this->hasMany('LinguisticDescriptions', [
            'foreignKey' => 'lexical_entry_id',
            'className' => 'LanguageDictionary.LinguisticDescriptions',
        ]);
        $this->hasMany('SampleSentences', [
            'foreignKey' => 'lexical_entry_id',
            'className' => 'LanguageDictionary.LinguisticDescriptions',
            'conditions' => [
                'SampleSentences.lemon_attribute_id' => 22
            ],
        ]);
        /**/ 
        $this->belongsToMany('ImageAssets', [
            'className' => 'DigitalAssetManager.Assets',
            'joinTable' => 'attachments',
            'foreignKey' => 'foreign_key',
            'targetForeignKey' => 'asset_id',
            'conditions' => [
                'Images.asset_type_id' => 6
            ],
        ]);
        /**/
        /**/
        $this->belongsToMany('SoundAssets', [
            'className' => 'DigitalAssetManager.Assets',
            'joinTable' => 'attachments',
            'foreignKey' => 'foreign_key',
            'targetForeignKey' => 'asset_id',
            'conditions' => [
                'Sounds.asset_type_id' => 4
            ],
        ]); 
        // $this->hasOne('Senses', [
        //     'foreignKey' => 'lexical_entry_id',
        //     'className' => 'LanguageDictionary.Senses',
        // ]);
        $this->hasMany('Senses', [
            'foreignKey' => 'lexical_entry_id',
            'className' => 'LanguageDictionary.Senses',
            'dependent' => true,
            'cascadeCallbacks' => true,
        ]);
        $this->belongsToMany('Dictionaries', [
            'foreignKey' => 'lexical_entry_id',
            'targetForeignKey' => 'dictionary_id',
            'joinTable' => 'dictionaries_lexical_entries',
            'className' => 'LanguageDictionary.Dictionaries',
        ]);
        $this->belongsToMany('WordLists', [
            'foreignKey' => 'lexical_entry_id',
            'targetForeignKey' => 'word_list_id',
            'joinTable' => 'lexical_entries_word_lists',
            'className' => 'LanguageDictionary.WordLists',
        ]); 
        
    $this->hasMany('Attachments', [
        'className' => 'DigitalAssetManager.Attachments',
        'foreignKey' => 'foreign_key',
        'conditions' => [
            'Attachments.model' => 'LanguageDictionary.LexicalEntries',
        ],
        'dependent' => true,
        'cascadeCallbacks' => true,
    ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->scalar('slug')
            ->maxLength('slug', 143)
            ->allowEmptyString('slug');

        $validator
            ->scalar('entry_type')
            ->maxLength('entry_type', 37)
            ->requirePresence('entry_type', 'create')
            ->notEmptyString('entry_type');

        $validator
            ->scalar('name')
            ->maxLength('name', 255)
            ->requirePresence('name', 'create')
            ->notEmptyString('name');

        $validator
            ->scalar('translated')
            ->maxLength('translated', 258)
            ->allowEmptyString('translated');

        $validator
            ->scalar('part_of_speech')
            ->maxLength('part_of_speech', 42)
            ->allowEmptyString('part_of_speech');

        $validator
            ->integer('language_id')
            ->allowEmptyString('language_id');

        $validator
            ->integer('coverimg')
            ->allowEmptyString('coverimg');

        $validator
            ->integer('coversound')
            ->allowEmptyString('coversound');

        $validator
            ->integer('tag_count')
            ->allowEmptyString('tag_count');

        $validator
            ->dateTime('trashed')
            ->allowEmptyDateTime('trashed');

        $validator
            ->integer('user_id')
            ->allowEmptyString('user_id');

        $validator
            ->integer('created_by')
            ->allowEmptyString('created_by');

        $validator
            ->integer('modified_by')
            ->allowEmptyString('modified_by');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->existsIn(['language_id'], 'Languages'), ['errorField' => 'language_id']);
        $rules->add($rules->existsIn(['user_id'], 'Users'), ['errorField' => 'user_id']);

        return $rules;
    }

    // SearchWords Finder - CakePHP 5 ready
    public function findSearchWords(SelectQuery $query, array $options): SelectQuery
    {
        // Base columns
        $columns = [
            'LexicalEntries.id',
            'LexicalEntries.slug',
            'LexicalEntries.entry_type',
            'LexicalEntries.part_of_speech',
            'LexicalEntries.name',
            'LexicalEntries.translated',
            'LexicalEntries.coverimg',
            'LexicalEntries.coversound',
            'LexicalEntries.tag_count',
            'LexicalEntries.trashed',
            'LexicalEntries.user_id',
            'LexicalEntries.created_by',
            'LexicalEntries.modified_by',
            'LexicalEntries.created',
            'LexicalEntries.modified',
        ];

        // Base query
        $query = $query
            ->select($columns)
            ->distinct($columns)
            ->contain([
                'Users',
                'Forms',
                'LinguisticDescriptions',
                'Senses', // plural - your association is Senses
                'Senses.CoverImageAsset.MediaAsset',
                'Senses.CoverSoundAsset.MediaAsset'
            ])
            ->where(['LexicalEntries.entry_type' => 'word']);

        // Apply filters step by step
        $query = $this->_applyDeletedFilter($query, $options['deleted_view'] ?? null);

        $this->_setupFormsFields($options); // modifies $options by reference

        if (!empty($options['search_ai'])) {
            $query = $this->_applySearchAI($query, $options['search_ai'], $options['search_type'] ?? 'full', $options);
        }

        $query = $this->_applyPartOfSpeechFilter($query, $options['search_part_of_speech'] ?? 'all');

        $query = $this->_applyMediaOptionFilter($query, $options['media_option'] ?? 'all');

        $query = $this->_applyModifiedDateRange($query, $options);
        $query = $this->_applyCreatedDateRange($query, $options);

        $query = $this->_applyModifiedByFilter($query, $options['search_modified_by'] ?? []);

        return $query;
    }

    protected function _applyDeletedFilter(SelectQuery $query, ?string $deletedView): SelectQuery
    {
        if (empty($deletedView)) {
            return $query->andWhere(['LexicalEntries.trashed IS' => null]);
        } elseif ($deletedView === 'onlyTrashed') {
            return $query->andWhere(['LexicalEntries.trashed IS NOT' => null]);
        }
        return $query;
    }

    protected function _setupFormsFields(array &$options): void
    {
        if (!empty($options['language_id']) && $options['language_id'] == 1) {
            $options['formsfields'] = 'unaccented_name';
            $options['formstype'] = ['canonical', 'query_string_form'];
            $options['language_ids'] = [1];
        } elseif (!empty($options['language_id']) && $options['language_id'] == 2) {
            $options['formsfields'] = 'unaccented_translated';
            $options['formstype'] = ['translateable_as', 'query_string_form'];
            $options['language_ids'] = [2];
        } else {
            $options['formsfields'] = 'both';
            $options['formstype'] = ['translateable_as', 'canonical', 'query_string_form'];
            $options['language_ids'] = [1, 2, 3];
        }
    }


protected function _applySearchAI(SelectQuery $query, string $searchAI, string $searchType, array $options): SelectQuery
{
    if ($searchType !== 'exact') {
        $connection = $this->getConnection();

        $sql = "
            SELECT f.lexical_entry_id, 
                   CASE 
                       WHEN f.written_representation = :search_ai THEN 999 
                       WHEN f.written_representation LIKE :starts_with THEN 99 
                       ELSE 9 
                   END AS result_order
            FROM forms f
            WHERE f.language_id IN (" . implode(',', $options['language_ids']) . ")
              AND (
                  f.written_representation = :search_ai 
                  OR f.written_representation LIKE :starts_with 
                  OR f.written_representation LIKE :contains
              )
            ORDER BY result_order DESC
        ";

        $params = [
            'search_ai' => $searchAI,
            'starts_with' => $searchAI . '%',
            'contains' => '%' . $searchAI . '%',
        ];

        $statement = $connection->execute($sql, $params);
        $rows = $statement->fetchAll('assoc');

        $ids = [];
        $relevanceMap = [];

        foreach ($rows as $row) {
            $ids[] = $row['lexical_entry_id'];
            $relevanceMap[$row['lexical_entry_id']] = $row['result_order'];
        }

        if (count($ids) > 0) {
            $query = $query->innerJoinWith('Forms')
                ->andWhere(['Forms.lexical_entry_id IN' => $ids])
                ->formatResults(function (\Cake\Collection\CollectionInterface $results) use ($relevanceMap) {
                    return $results->map(function ($row) use ($relevanceMap) {
                        $row['relevance'] = $relevanceMap[$row['id']] ?? 0;
                        return $row;
                    });
                })
                ->order(['FIELD(LexicalEntries.id, ' . implode(',', $ids) . ')']);
        } else {
            $query = $query->innerJoinWith('Forms')
                ->andWhere(['Forms.written_representation' => $searchAI]);
        }
    } else {
        $query = $query->innerJoinWith('Forms')
            ->andWhere(['Forms.written_representation' => $searchAI]);
    }

    return $query;
}


    protected function _applyPartOfSpeechFilter(SelectQuery $query, string $pos): SelectQuery
    {
        if ($pos !== 'all') {
            return $query->andWhere(['LexicalEntries.part_of_speech' => $pos]);
        }
        return $query;
    }

protected function _applyMediaOptionFilter(SelectQuery $query, string $mediaOption): SelectQuery
{
    switch ($mediaOption) {
        case 'has_any':
            return $query->andWhere(function ($exp, $q) {
                return $exp->or([
                    $exp->isNotNull('LexicalEntries.coverimg'),
                    $exp->isNotNull('LexicalEntries.coversound')
                ]);
            });
        case 'has_none':
            return $query->andWhere([
                'LexicalEntries.coverimg IS' => null,
                'LexicalEntries.coversound IS' => null
            ]);
        case 'has_img':
            return $query->andWhere(['LexicalEntries.coverimg IS NOT' => null]);
        case 'no_img':
            return $query->andWhere(['LexicalEntries.coverimg IS' => null]);
        case 'has_sound':
            return $query->andWhere(['LexicalEntries.coversound IS NOT' => null]);
        case 'no_sound':
            return $query->andWhere(['LexicalEntries.coversound IS' => null]);
        default:
            return $query;
    }
}


    protected function _applyModifiedDateRange(SelectQuery $query, array $options): SelectQuery
    {
        if (!empty($options['search_modified_after'])) {
            $query = $query->andWhere(['LexicalEntries.modified >=' => $options['search_modified_after']]);
        }
        if (!empty($options['search_modified_before'])) {
            $query = $query->andWhere(['LexicalEntries.modified <=' => $options['search_modified_before']]);
        }
        return $query;
    }

    protected function _applyCreatedDateRange(SelectQuery $query, array $options): SelectQuery
    {
        if (!empty($options['search_created_after'])) {
            $query = $query->andWhere(['LexicalEntries.created >=' => $options['search_created_after']]);
        }
        if (!empty($options['search_created_before'])) {
            $query = $query->andWhere(['LexicalEntries.created <=' => $options['search_created_before']]);
        }
        return $query;
    }

    protected function _applyModifiedByFilter(SelectQuery $query, array $userIds): SelectQuery
    {
        if (!empty($userIds)) {
            return $query->andWhere(['LexicalEntries.modified_by IN' => $userIds]);
        }
        return $query;
    }

}
