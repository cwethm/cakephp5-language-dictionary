<?php
// File: plugins/LanguageDictionary/src/Model/Table/LemonAttributeLabelsTable.php
namespace LanguageDictionary\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;

class LemonAttributeLabelsTable extends Table
{
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('lemon_attribute_labels');
        $this->setPrimaryKey('id');

        $this->belongsTo('LemonAttributes', [
            'foreignKey' => 'lemon_attribute_id',
            'className' => 'LanguageDictionary.LemonAttributes',
        ]);
    }

    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->scalar('language')->maxLength('language', 10)->notEmptyString('language')
            ->scalar('label')->maxLength('label', 255)->notEmptyString('label');

        return $validator;
    }
}
