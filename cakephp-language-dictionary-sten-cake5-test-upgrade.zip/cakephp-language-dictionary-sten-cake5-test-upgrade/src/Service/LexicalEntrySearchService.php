<?php
declare(strict_types=1);

namespace LanguageDictionary\Service;

use LanguageDictionary\Model\Table\LexicalEntriesTable;
use Cake\ORM\TableRegistry;
use Cake\ORM\Query\SelectQuery;

class LexicalEntrySearchService
{
    protected LexicalEntriesTable $LexicalEntries;

    public function __construct(?LexicalEntriesTable $LexicalEntries = null)
    {
        // Allow injection for testing, fallback to TableLocator
        $this->LexicalEntries = $LexicalEntries ?? TableRegistry::getTableLocator()->get('LanguageDictionary.LexicalEntries');
    }

    /**
     * Perform searchWords query
     *
     * @param array $options The full array of form options
     * @return \Cake\ORM\Query\SelectQuery<\LanguageDictionary\Model\Entity\LexicalEntry>
     */
    public function search(array $options): SelectQuery
    {
        // Normalize common options
        $options['search_q'] = trim($options['search_q'] ?? '');
        $options['search_ai'] = trim($options['search_ai'] ?? '');
        $options['limit'] = isset($options['limit']) ? (int)$options['limit'] : 20;
        $options['page'] = isset($options['page']) ? (int)$options['page'] : 1;
        $options['sort'] = $options['sort'] ?? 'LexicalEntries.modified';
        $options['direction'] = $options['direction'] ?? 'desc';
        $contains = ['Forms', 'LinguisticDescriptions', 'Senses', 'Senses.CoverImageAsset.MediaAsset', 'Senses.CoverSoundAsset.MediaAsset'];
        // return $this->LexicalEntries->find('searchWords', $options)->contain([
        //     'Senses' => [
        //         'CoverImageAsset' => ['MediaAsset'],
        //         'CoverSoundAsset' => ['MediaAsset']
        //     ]
        // ]);
        return $this->LexicalEntries->find('searchWords', $options)->contain([
            'Senses' => [
                'CoverImageAsset' => [
                    'MediaAsset'
                ],
                'CoverSoundAsset' => [
                    'MediaAsset'
                ]
            ]
        ]);

    }
}
