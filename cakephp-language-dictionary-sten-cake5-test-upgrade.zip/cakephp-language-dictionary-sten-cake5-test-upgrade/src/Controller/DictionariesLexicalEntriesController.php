<?php
declare(strict_types=1);

namespace LanguageDictionary\Controller;

use LanguageDictionary\Controller\AppController;

/**
 * DictionariesLexicalEntries Controller
 *
 * @property \LanguageDictionary\Model\Table\DictionariesLexicalEntriesTable $DictionariesLexicalEntries
 */
class DictionariesLexicalEntriesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $query = $this->DictionariesLexicalEntries->find()
            ->contain(['Dictionaries', 'LexicalEntries']);
        $dictionariesLexicalEntries = $this->paginate($query);

        $this->set(compact('dictionariesLexicalEntries'));
    }

    /**
     * View method
     *
     * @param string|null $id Dictionaries Lexical Entry id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $dictionariesLexicalEntry = $this->DictionariesLexicalEntries->get($id, contain: ['Dictionaries', 'LexicalEntries']);
        $this->set(compact('dictionariesLexicalEntry'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $dictionariesLexicalEntry = $this->DictionariesLexicalEntries->newEmptyEntity();
        if ($this->request->is('post')) {
            $dictionariesLexicalEntry = $this->DictionariesLexicalEntries->patchEntity($dictionariesLexicalEntry, $this->request->getData());
            if ($this->DictionariesLexicalEntries->save($dictionariesLexicalEntry)) {
                $this->Flash->success(__('The dictionaries lexical entry has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The dictionaries lexical entry could not be saved. Please, try again.'));
        }
        $dictionaries = $this->DictionariesLexicalEntries->Dictionaries->find('list', limit: 200)->all();
        $lexicalEntries = $this->DictionariesLexicalEntries->LexicalEntries->find('list', limit: 200)->all();
        $this->set(compact('dictionariesLexicalEntry', 'dictionaries', 'lexicalEntries'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Dictionaries Lexical Entry id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $dictionariesLexicalEntry = $this->DictionariesLexicalEntries->get($id, contain: []);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $dictionariesLexicalEntry = $this->DictionariesLexicalEntries->patchEntity($dictionariesLexicalEntry, $this->request->getData());
            if ($this->DictionariesLexicalEntries->save($dictionariesLexicalEntry)) {
                $this->Flash->success(__('The dictionaries lexical entry has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The dictionaries lexical entry could not be saved. Please, try again.'));
        }
        $dictionaries = $this->DictionariesLexicalEntries->Dictionaries->find('list', limit: 200)->all();
        $lexicalEntries = $this->DictionariesLexicalEntries->LexicalEntries->find('list', limit: 200)->all();
        $this->set(compact('dictionariesLexicalEntry', 'dictionaries', 'lexicalEntries'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Dictionaries Lexical Entry id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $dictionariesLexicalEntry = $this->DictionariesLexicalEntries->get($id);
        if ($this->DictionariesLexicalEntries->delete($dictionariesLexicalEntry)) {
            $this->Flash->success(__('The dictionaries lexical entry has been deleted.'));
        } else {
            $this->Flash->error(__('The dictionaries lexical entry could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
