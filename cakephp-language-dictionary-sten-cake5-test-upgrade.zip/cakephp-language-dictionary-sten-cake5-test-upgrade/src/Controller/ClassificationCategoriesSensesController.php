<?php
declare(strict_types=1);

namespace LanguageDictionary\Controller;

use LanguageDictionary\Controller\AppController;

/**
 * ClassificationCategoriesSenses Controller
 *
 * @property \LanguageDictionary\Model\Table\ClassificationCategoriesSensesTable $ClassificationCategoriesSenses
 */
class ClassificationCategoriesSensesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $query = $this->ClassificationCategoriesSenses->find()
            ->contain(['Senses', 'ClassificationCategories']);
        $classificationCategoriesSenses = $this->paginate($query);

        $this->set(compact('classificationCategoriesSenses'));
    }

    /**
     * View method
     *
     * @param string|null $id Classification Categories Sense id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $classificationCategoriesSense = $this->ClassificationCategoriesSenses->get($id, contain: ['Senses', 'ClassificationCategories']);
        $this->set(compact('classificationCategoriesSense'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $classificationCategoriesSense = $this->ClassificationCategoriesSenses->newEmptyEntity();
        if ($this->request->is('post')) {
            $classificationCategoriesSense = $this->ClassificationCategoriesSenses->patchEntity($classificationCategoriesSense, $this->request->getData());
            if ($this->ClassificationCategoriesSenses->save($classificationCategoriesSense)) {
                $this->Flash->success(__('The classification categories sense has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The classification categories sense could not be saved. Please, try again.'));
        }
        $senses = $this->ClassificationCategoriesSenses->Senses->find('list', limit: 200)->all();
        $classificationCategories = $this->ClassificationCategoriesSenses->ClassificationCategories->find('list', limit: 200)->all();
        $this->set(compact('classificationCategoriesSense', 'senses', 'classificationCategories'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Classification Categories Sense id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $classificationCategoriesSense = $this->ClassificationCategoriesSenses->get($id, contain: []);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $classificationCategoriesSense = $this->ClassificationCategoriesSenses->patchEntity($classificationCategoriesSense, $this->request->getData());
            if ($this->ClassificationCategoriesSenses->save($classificationCategoriesSense)) {
                $this->Flash->success(__('The classification categories sense has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The classification categories sense could not be saved. Please, try again.'));
        }
        $senses = $this->ClassificationCategoriesSenses->Senses->find('list', limit: 200)->all();
        $classificationCategories = $this->ClassificationCategoriesSenses->ClassificationCategories->find('list', limit: 200)->all();
        $this->set(compact('classificationCategoriesSense', 'senses', 'classificationCategories'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Classification Categories Sense id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $classificationCategoriesSense = $this->ClassificationCategoriesSenses->get($id);
        if ($this->ClassificationCategoriesSenses->delete($classificationCategoriesSense)) {
            $this->Flash->success(__('The classification categories sense has been deleted.'));
        } else {
            $this->Flash->error(__('The classification categories sense could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
