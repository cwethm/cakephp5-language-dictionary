<?php
declare(strict_types=1);

namespace LanguageDictionary\Controller;

use LanguageDictionary\Controller\AppController;

/**
 * LdProperties Controller
 *
 * @property \LanguageDictionary\Model\Table\LdPropertiesTable $LdProperties
 */
class LdPropertiesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $query = $this->LdProperties->find()
            ->contain(['LinguisticDescriptions', 'LemonAttributes']);
        $ldProperties = $this->paginate($query);

        $this->set(compact('ldProperties'));
    }

    /**
     * View method
     *
     * @param string|null $id Ld Property id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $ldProperty = $this->LdProperties->get($id, contain: ['LinguisticDescriptions', 'LemonAttributes']);
        $this->set(compact('ldProperty'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $ldProperty = $this->LdProperties->newEmptyEntity();
        if ($this->request->is('post')) {
            $ldProperty = $this->LdProperties->patchEntity($ldProperty, $this->request->getData());
            if ($this->LdProperties->save($ldProperty)) {
                $this->Flash->success(__('The ld property has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The ld property could not be saved. Please, try again.'));
        }
        $linguisticDescriptions = $this->LdProperties->LinguisticDescriptions->find('list', limit: 200)->all();
        $lemonAttributes = $this->LdProperties->LemonAttributes->find('list', limit: 200)->all();
        $this->set(compact('ldProperty', 'linguisticDescriptions', 'lemonAttributes'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Ld Property id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $ldProperty = $this->LdProperties->get($id, contain: []);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $ldProperty = $this->LdProperties->patchEntity($ldProperty, $this->request->getData());
            if ($this->LdProperties->save($ldProperty)) {
                $this->Flash->success(__('The ld property has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The ld property could not be saved. Please, try again.'));
        }
        $linguisticDescriptions = $this->LdProperties->LinguisticDescriptions->find('list', limit: 200)->all();
        $lemonAttributes = $this->LdProperties->LemonAttributes->find('list', limit: 200)->all();
        $this->set(compact('ldProperty', 'linguisticDescriptions', 'lemonAttributes'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Ld Property id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $ldProperty = $this->LdProperties->get($id);
        if ($this->LdProperties->delete($ldProperty)) {
            $this->Flash->success(__('The ld property has been deleted.'));
        } else {
            $this->Flash->error(__('The ld property could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
