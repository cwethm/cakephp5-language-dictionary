<?php
declare(strict_types=1);

namespace LanguageDictionary\Controller;

use LanguageDictionary\Controller\AppController;
use Cake\Core\Configure;

/**
 * Forms Controller
 *
 * @property \LanguageDictionary\Model\Table\FormsTable $Forms
 */
class FormsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $query = $this->Forms->find()
            ->contain(['LexicalEntries', 'Languages']);
        $forms = $this->paginate($query);

        $this->set(compact('forms'));
    }

    /**
     * View method
     *
     * @param string|null $id Form id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $form = $this->Forms->get($id, contain: ['LexicalEntries', 'Languages', 'LinguisticDescriptions']);
        $this->set(compact('form'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    // public function add()
    // {
    //     $form = $this->Forms->newEmptyEntity();
    //     if ($this->request->is('post')) {
    //         $form = $this->Forms->patchEntity($form, $this->request->getData());
    //         if ($this->Forms->save($form)) {
    //             $this->Flash->success(__('The form has been saved.'));

    //             return $this->redirect(['action' => 'index']);
    //         }
    //         $this->Flash->error(__('The form could not be saved. Please, try again.'));
    //     }
    //     $lexicalEntries = $this->Forms->LexicalEntries->find('list', limit: 200)->all();
    //     $languages = $this->Forms->Languages->find('list', limit: 200)->all();
    //     $this->set(compact('form', 'lexicalEntries', 'languages'));
    // }
    public function add($pid = null)
    {
        $formData = [];
        if (!empty($pid)) {
            $formData['lexical_entry_id'] = $pid;
            $formData['language_id'] = '';
            $formData['form_type'] = '';
            $formData['written_representation'] = '';
        }

        // Load config and context
        $presentationConfig = include CONFIG . 'TableDefinitions/FormsTable.php';

            // $formTypeAttributes = $this->Forms->LemonAttributes
            //     ->find('list', ['keyField' => 'uri', 'valueField' => 'local_name'])
            //     ->find('formTypeAttributes')
            //     ->all();

        $schema = new \LemonTools\Service\LemonSchemaService();
        $formTypeAttributes = $schema->getAttributesForField('Forms', 'form_type');

        $form = $this->Forms->newEmptyEntity();
        $form = $this->Forms->patchEntity($form, $formData);

        $contextModel = $this->request->getQuery('context_model') ?? $presentationConfig['context_model'];
 
        if ($this->request->is('get')) {
            $this->set(compact('form', 'contextModel', 'presentationConfig', 'formTypeAttributes'));
            $this->viewBuilder()->disableAutoLayout();
            return $this->render('ajax_add_form');
        }

        if ($this->request->is('post')) {
            $form = $this->Forms->patchEntity($form, $this->request->getData());

            if ($this->Forms->save($form)) {
                $form = $this->Forms->get($form->id, contain: $presentationConfig['contains'] );

                $rowHtml = $this->RowRenderer->renderRow($form, $presentationConfig);

                $this->set([
                    'success' => true,
                    'rowHtml' => $rowHtml,
                    'row' => [
                        'id' => $form->id,
                        'lexical_entry_id' => $form->lexical_entry_id,
                        'language_id' => $form->language_id,
                        'form_type' => $form->form_type,
                        'written_representation' => $form->written_representation,
                        'created' => $form->created?->i18nFormat('yyyy-MM-dd'),
                        // 'lemon_attribute_name' => $form->lemon_attribute->name ?? null
                    ]
                ]);
                $this->viewBuilder()->disableAutoLayout();
                $this->viewBuilder()->setOption('serialize', ['success', 'rowHtml', 'row']);
                return $this->render('ajax_add_form');
            }

            $this->set([
                'success' => false,
                'message' => __('Validation failed'),
            ]);
            $this->viewBuilder()->disableAutoLayout();
            $this->viewBuilder()->setOption('serialize', ['success', 'message']);
            return $this->render('ajax_add_form');
        }

        throw new \Cake\Http\Exception\MethodNotAllowedException();
    }

    /**
     * Edit method
     *
     * @param string|null $id Form id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $form = $this->Forms->get($id, contain: []);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $form = $this->Forms->patchEntity($form, $this->request->getData());
            if ($this->Forms->save($form)) {
                $this->Flash->success(__('The form has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The form could not be saved. Please, try again.'));
        }
        $lexicalEntries = $this->Forms->LexicalEntries->find('list', limit: 200)->all();
        $languages = $this->Forms->Languages->find('list', limit: 200)->all();
        $this->set(compact('form', 'lexicalEntries', 'languages'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Form id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $form = $this->Forms->get($id);
        if ($this->Forms->delete($form)) {
            $this->Flash->success(__('The form has been deleted.'));
        } else {
            $this->Flash->error(__('The form could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
    // In LanguageDictionary\Controller\FormsController.php
    public function addToEntry(int $lexicalEntryId)
    {
        $this->viewBuilder()->disableAutoLayout();

        $form = $this->Forms->newEmptyEntity();

        $this->set(compact('form', 'lexicalEntryId'));
        $this->render('form_modal'); // templates/Forms/form_modal.php
    }

}
