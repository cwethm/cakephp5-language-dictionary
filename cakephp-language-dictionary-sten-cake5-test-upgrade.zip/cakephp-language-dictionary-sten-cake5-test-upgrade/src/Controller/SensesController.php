<?php
declare(strict_types=1);

namespace LanguageDictionary\Controller;

use LanguageDictionary\Controller\AppController;

/**
 * Senses Controller
 *
 * @property \LanguageDictionary\Model\Table\SensesTable $Senses
 */
class SensesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $query = $this->Senses->find()
            ->contain(['LexicalEntries']);
        $senses = $this->paginate($query);

        $this->set(compact('senses'));
    }

    /**
     * View method
     *
     * @param string|null $id Sense id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $sense = $this->Senses->get($id, contain: ['LexicalEntries', 'ClassificationCategories', 'LinguisticDescriptions']);
        $this->set(compact('sense'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $sense = $this->Senses->newEmptyEntity();
        if ($this->request->is('post')) {
            $sense = $this->Senses->patchEntity($sense, $this->request->getData());
            if ($this->Senses->save($sense)) {
                $this->Flash->success(__('The sense has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The sense could not be saved. Please, try again.'));
        }
        $lexicalEntries = $this->Senses->LexicalEntries->find('list', limit: 200)->all();
        $classificationCategories = $this->Senses->ClassificationCategories->find('list', limit: 200)->all();
        $this->set(compact('sense', 'lexicalEntries', 'classificationCategories'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Sense id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $sense = $this->Senses->get($id, contain: ['ClassificationCategories', 'CoverSoundAsset', 'CoverImageAsset']);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $sense = $this->Senses->patchEntity($sense, $this->request->getData());
            if ($this->Senses->save($sense)) {
                $this->Flash->success(__('The sense has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The sense could not be saved. Please, try again.'));
        }
        $lexicalEntries = $this->Senses->LexicalEntries->find('list', limit: 200)->all();
        $classificationCategories = $this->Senses->ClassificationCategories->find('list', limit: 200)->all();
        $this->set(compact('sense', 'lexicalEntries', 'classificationCategories'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Sense id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $sense = $this->Senses->get($id);
        if ($this->Senses->delete($sense)) {
            $this->Flash->success(__('The sense has been deleted.'));
        } else {
            $this->Flash->error(__('The sense could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
