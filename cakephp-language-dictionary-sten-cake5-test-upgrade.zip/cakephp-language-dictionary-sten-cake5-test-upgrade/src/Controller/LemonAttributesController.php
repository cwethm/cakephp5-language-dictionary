<?php
declare(strict_types=1);

namespace LanguageDictionary\Controller;

use LanguageDictionary\Controller\AppController;

/**
 * LemonAttributes Controller
 *
 * @property \LanguageDictionary\Model\Table\LemonAttributesTable $LemonAttributes
 */
class LemonAttributesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $query = $this->LemonAttributes->find();
        $lemonAttributes = $this->paginate($query);

        $this->set(compact('lemonAttributes'));
    }

    /**
     * View method
     *
     * @param string|null $id Lemon Attribute id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $lemonAttribute = $this->LemonAttributes->get($id, contain: ['LdProperties', 'LemonValueSets', 'LinguisticDescriptions', 'LinguisticLinks']);
        $this->set(compact('lemonAttribute'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $lemonAttribute = $this->LemonAttributes->newEmptyEntity();
        if ($this->request->is('post')) {
            $lemonAttribute = $this->LemonAttributes->patchEntity($lemonAttribute, $this->request->getData());
            if ($this->LemonAttributes->save($lemonAttribute)) {
                $this->Flash->success(__('The lemon attribute has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The lemon attribute could not be saved. Please, try again.'));
        }
        $this->set(compact('lemonAttribute'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Lemon Attribute id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $lemonAttribute = $this->LemonAttributes->get($id, contain: []);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $lemonAttribute = $this->LemonAttributes->patchEntity($lemonAttribute, $this->request->getData());
            if ($this->LemonAttributes->save($lemonAttribute)) {
                $this->Flash->success(__('The lemon attribute has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The lemon attribute could not be saved. Please, try again.'));
        }
        $this->set(compact('lemonAttribute'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Lemon Attribute id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $lemonAttribute = $this->LemonAttributes->get($id);
        if ($this->LemonAttributes->delete($lemonAttribute)) {
            $this->Flash->success(__('The lemon attribute has been deleted.'));
        } else {
            $this->Flash->error(__('The lemon attribute could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
