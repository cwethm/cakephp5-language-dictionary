<?php
declare(strict_types=1);

namespace LanguageDictionary\Controller;

use LanguageDictionary\Controller\AppController;

/**
 * LexicalEntriesWordLists Controller
 *
 * @property \LanguageDictionary\Model\Table\LexicalEntriesWordListsTable $LexicalEntriesWordLists
 */
class LexicalEntriesWordListsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $query = $this->LexicalEntriesWordLists->find()
            ->contain(['LexicalEntries', 'WordLists']);
        $lexicalEntriesWordLists = $this->paginate($query);

        $this->set(compact('lexicalEntriesWordLists'));
    }

    /**
     * View method
     *
     * @param string|null $id Lexical Entries Word List id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $lexicalEntriesWordList = $this->LexicalEntriesWordLists->get($id, contain: ['LexicalEntries', 'WordLists']);
        $this->set(compact('lexicalEntriesWordList'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $lexicalEntriesWordList = $this->LexicalEntriesWordLists->newEmptyEntity();
        if ($this->request->is('post')) {
            $lexicalEntriesWordList = $this->LexicalEntriesWordLists->patchEntity($lexicalEntriesWordList, $this->request->getData());
            if ($this->LexicalEntriesWordLists->save($lexicalEntriesWordList)) {
                $this->Flash->success(__('The lexical entries word list has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The lexical entries word list could not be saved. Please, try again.'));
        }
        $lexicalEntries = $this->LexicalEntriesWordLists->LexicalEntries->find('list', limit: 200)->all();
        $wordLists = $this->LexicalEntriesWordLists->WordLists->find('list', limit: 200)->all();
        $this->set(compact('lexicalEntriesWordList', 'lexicalEntries', 'wordLists'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Lexical Entries Word List id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $lexicalEntriesWordList = $this->LexicalEntriesWordLists->get($id, contain: []);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $lexicalEntriesWordList = $this->LexicalEntriesWordLists->patchEntity($lexicalEntriesWordList, $this->request->getData());
            if ($this->LexicalEntriesWordLists->save($lexicalEntriesWordList)) {
                $this->Flash->success(__('The lexical entries word list has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The lexical entries word list could not be saved. Please, try again.'));
        }
        $lexicalEntries = $this->LexicalEntriesWordLists->LexicalEntries->find('list', limit: 200)->all();
        $wordLists = $this->LexicalEntriesWordLists->WordLists->find('list', limit: 200)->all();
        $this->set(compact('lexicalEntriesWordList', 'lexicalEntries', 'wordLists'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Lexical Entries Word List id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $lexicalEntriesWordList = $this->LexicalEntriesWordLists->get($id);
        if ($this->LexicalEntriesWordLists->delete($lexicalEntriesWordList)) {
            $this->Flash->success(__('The lexical entries word list has been deleted.'));
        } else {
            $this->Flash->error(__('The lexical entries word list could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
