<?php
declare(strict_types=1);

namespace LanguageDictionary\Controller;

use LanguageDictionary\Controller\AppController;

/**
 * LemonValueSets Controller
 *
 * @property \LanguageDictionary\Model\Table\LemonValueSetsTable $LemonValueSets
 */
class LemonValueSetsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $query = $this->LemonValueSets->find()
            ->contain(['LemonAttributes']);
        $lemonValueSets = $this->paginate($query);

        $this->set(compact('lemonValueSets'));
    }

    /**
     * View method
     *
     * @param string|null $id Lemon Value Set id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $lemonValueSet = $this->LemonValueSets->get($id, contain: ['LemonAttributes']);
        $this->set(compact('lemonValueSet'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $lemonValueSet = $this->LemonValueSets->newEmptyEntity();
        if ($this->request->is('post')) {
            $lemonValueSet = $this->LemonValueSets->patchEntity($lemonValueSet, $this->request->getData());
            if ($this->LemonValueSets->save($lemonValueSet)) {
                $this->Flash->success(__('The lemon value set has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The lemon value set could not be saved. Please, try again.'));
        }
        $lemonAttributes = $this->LemonValueSets->LemonAttributes->find('list', limit: 200)->all();
        $this->set(compact('lemonValueSet', 'lemonAttributes'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Lemon Value Set id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $lemonValueSet = $this->LemonValueSets->get($id, contain: []);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $lemonValueSet = $this->LemonValueSets->patchEntity($lemonValueSet, $this->request->getData());
            if ($this->LemonValueSets->save($lemonValueSet)) {
                $this->Flash->success(__('The lemon value set has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The lemon value set could not be saved. Please, try again.'));
        }
        $lemonAttributes = $this->LemonValueSets->LemonAttributes->find('list', limit: 200)->all();
        $this->set(compact('lemonValueSet', 'lemonAttributes'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Lemon Value Set id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $lemonValueSet = $this->LemonValueSets->get($id);
        if ($this->LemonValueSets->delete($lemonValueSet)) {
            $this->Flash->success(__('The lemon value set has been deleted.'));
        } else {
            $this->Flash->error(__('The lemon value set could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
