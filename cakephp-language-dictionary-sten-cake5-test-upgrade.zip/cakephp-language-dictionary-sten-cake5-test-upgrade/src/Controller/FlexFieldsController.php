<?php
declare(strict_types=1);

namespace LanguageDictionary\Controller;

use LanguageDictionary\Controller\AppController;

/**
 * FlexFields Controller
 *
 * @property \LanguageDictionary\Model\Table\FlexFieldsTable $FlexFields
 */
class FlexFieldsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $query = $this->FlexFields->find()
            ->contain(['Users']);
        $flexFields = $this->paginate($query);

        $this->set(compact('flexFields'));
    }

    /**
     * View method
     *
     * @param string|null $id Flex Field id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $flexField = $this->FlexFields->get($id, contain: ['Users']);
        $this->set(compact('flexField'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $flexField = $this->FlexFields->newEmptyEntity();
        if ($this->request->is('post')) {
            $flexField = $this->FlexFields->patchEntity($flexField, $this->request->getData());
            if ($this->FlexFields->save($flexField)) {
                $this->Flash->success(__('The flex field has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The flex field could not be saved. Please, try again.'));
        }
        $users = $this->FlexFields->Users->find('list', limit: 200)->all();
        $this->set(compact('flexField', 'users'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Flex Field id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $flexField = $this->FlexFields->get($id, contain: []);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $flexField = $this->FlexFields->patchEntity($flexField, $this->request->getData());
            if ($this->FlexFields->save($flexField)) {
                $this->Flash->success(__('The flex field has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The flex field could not be saved. Please, try again.'));
        }
        $users = $this->FlexFields->Users->find('list', limit: 200)->all();
        $this->set(compact('flexField', 'users'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Flex Field id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $flexField = $this->FlexFields->get($id);
        if ($this->FlexFields->delete($flexField)) {
            $this->Flash->success(__('The flex field has been deleted.'));
        } else {
            $this->Flash->error(__('The flex field could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
