<?php
declare(strict_types=1);

namespace LanguageDictionary\Controller;

use LanguageDictionary\Controller\AppController;

/**
 * Dictionaries Controller
 *
 * @property \LanguageDictionary\Model\Table\DictionariesTable $Dictionaries
 */
class DictionariesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $query = $this->Dictionaries->find()
            ->contain(['Users']);
        $dictionaries = $this->paginate($query);

        $this->set(compact('dictionaries'));
    }

    /**
     * View method
     *
     * @param string|null $id Dictionary id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $dictionary = $this->Dictionaries->get($id, contain: ['Users', 'Languages', 'LexicalEntries', 'Synonyms']);
        $this->set(compact('dictionary'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $dictionary = $this->Dictionaries->newEmptyEntity();
        if ($this->request->is('post')) {
            $dictionary = $this->Dictionaries->patchEntity($dictionary, $this->request->getData());
            if ($this->Dictionaries->save($dictionary)) {
                $this->Flash->success(__('The dictionary has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The dictionary could not be saved. Please, try again.'));
        }
        $users = $this->Dictionaries->Users->find('list', limit: 200)->all();
        $languages = $this->Dictionaries->Languages->find('list', limit: 200)->all();
        $lexicalEntries = $this->Dictionaries->LexicalEntries->find('list', limit: 200)->all();
        $this->set(compact('dictionary', 'users', 'languages', 'lexicalEntries'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Dictionary id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $dictionary = $this->Dictionaries->get($id, contain: ['Languages', 'LexicalEntries']);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $dictionary = $this->Dictionaries->patchEntity($dictionary, $this->request->getData());
            if ($this->Dictionaries->save($dictionary)) {
                $this->Flash->success(__('The dictionary has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The dictionary could not be saved. Please, try again.'));
        }
        $users = $this->Dictionaries->Users->find('list', limit: 200)->all();
        $languages = $this->Dictionaries->Languages->find('list', limit: 200)->all();
        $lexicalEntries = $this->Dictionaries->LexicalEntries->find('list', limit: 200)->all();
        $this->set(compact('dictionary', 'users', 'languages', 'lexicalEntries'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Dictionary id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $dictionary = $this->Dictionaries->get($id);
        if ($this->Dictionaries->delete($dictionary)) {
            $this->Flash->success(__('The dictionary has been deleted.'));
        } else {
            $this->Flash->error(__('The dictionary could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
