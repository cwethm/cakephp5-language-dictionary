<?php
declare(strict_types=1);

namespace LanguageDictionary\Controller;

use LanguageDictionary\Controller\AppController;

/**
 * LinguisticDescriptions Controller
 *
 * @property \LanguageDictionary\Model\Table\LinguisticDescriptionsTable $LinguisticDescriptions
 */
class LinguisticDescriptionsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $query = $this->LinguisticDescriptions->find()
            ->contain(['LexicalEntries', 'Senses', 'Forms', 'LemonAttributes']);
        $linguisticDescriptions = $this->paginate($query);

        $this->set(compact('linguisticDescriptions'));
    }

    /**
     * View method
     *
     * @param string|null $id Linguistic Description id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $linguisticDescription = $this->LinguisticDescriptions->get($id, contain: ['LexicalEntries', 'Senses', 'Forms', 'LemonAttributes', 'LdProperties']);
        $this->set(compact('linguisticDescription'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
/*    public function add()
    {
        $linguisticDescription = $this->LinguisticDescriptions->newEmptyEntity();
        if ($this->request->is('post')) {
            $linguisticDescription = $this->LinguisticDescriptions->patchEntity($linguisticDescription, $this->request->getData());
            if ($this->LinguisticDescriptions->save($linguisticDescription)) {
                $this->Flash->success(__('The linguistic description has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The linguistic description could not be saved. Please, try again.'));
        }
        $lexicalEntries = $this->LinguisticDescriptions->LexicalEntries->find('list', limit: 200)->all();
        $senses = $this->LinguisticDescriptions->Senses->find('list', limit: 200)->all();
        $forms = $this->LinguisticDescriptions->Forms->find('list', limit: 200)->all();
        $lemonAttributes = $this->LinguisticDescriptions->LemonAttributes->find('list', limit: 200)->all();
        $this->set(compact('linguisticDescription', 'lexicalEntries', 'senses', 'forms', 'lemonAttributes'));
//     }*/
// public function add()
// {
//     $desc = $this->LinguisticDescriptions->newEmptyEntity();
//     // In a controller action, or in beforeRender.
//     if ($this->request->is('ajax')) {
//         $this->viewBuilder()->setClassName('Ajax');
//     }

//     if ($this->request->is('post')) {
//         $desc = $this->LinguisticDescriptions->patchEntity($desc, $this->request->getData());
//         if ($this->LinguisticDescriptions->save($desc)) {
//             // Optional: fetch again if you need contains()
//             $desc = $this->LinguisticDescriptions->get($desc->id);

//             $this->set([
//                 'success' => true,
//                 'row' => [
//                     'id' => $desc->id,
//                     'lemon_attribute_id' => $desc->lemon_attribute_id,
//                     'value' => $desc->value,
//                     'created' => $desc->created->i18nFormat('yyyy-MM-dd')
//                 ]
//             ]);
//             $this->render('ajax_add_form'); // this is a view or element
//         } else {
//             $this->set(['success' => false, 'message' => 'Validation failed']);
//         }

//         $this->viewBuilder()->setOption('serialize', ['success', 'row', 'message']);
//         return;
//     }
//         $lemonAttributes = $this->LinguisticDescriptions->LemonAttributes->find('list', limit: 200)->where(['model_class'=>'Forms'])->all();

//     $this->set(compact('desc', 'lemonAttributes'));
//     $this->render('ajax_add_form'); // this is a view or element
// }
public function add($pid = null)
{
    $descData = [];
    if (!empty($pid)) {
        $descData['form_id'] = $pid;
    }

    // Optionally load config for rendering
    $presentationConfig = include CONFIG . 'TableDefinitions/LinguisticDescriptionsTable.php';

    $desc = $this->LinguisticDescriptions->newEmptyEntity();
    $desc = $this->LinguisticDescriptions->patchEntity($desc, $descData);

    // Determine context model (e.g. Forms, Senses, etc.)
    $contextModel = $this->request->getQuery('context_model') ?? $presentationConfig['context_model'];

    // Load matching LemonAttributes
    $lemonAttributes = $this->LinguisticDescriptions->LemonAttributes
        ->find('list', ['keyField' => 'id', 'valueField' => 'local_name'])
        ->where(['model_class' => $contextModel])
        ->orderAsc('local_name')
        ->all();

    // For GET: render the modal form
    if ($this->request->is('get')) {
        $this->set(compact('desc', 'lemonAttributes', 'contextModel', 'presentationConfig'));
        $this->viewBuilder()->disableAutoLayout();
        return $this->render('ajax_add_form');
    }

    // For POST: attempt to save new description
    if ($this->request->is('post')) {
        $desc = $this->LinguisticDescriptions->patchEntity($desc, $this->request->getData());

        if ($this->LinguisticDescriptions->save($desc)) {
            $desc = $this->LinguisticDescriptions
                ->get($desc->id, contain: ['LemonAttributes']);

            $this->set(compact('desc', 'lemonAttributes', 'contextModel', 'presentationConfig'));

            $rowHtml = $this->RowRenderer->renderRow($desc, $presentationConfig);

            $this->set([
                'success' => true,
                'rowHtml' => $rowHtml,
                'desc' => $desc,
                'row' => [
                    'id' => $desc->id,
                    'lemon_attribute_id' => $desc->lemon_attribute_id,
                    'value' => $desc->value,
                    'created' => $desc->created?->i18nFormat('yyyy-MM-dd'),
                    // 'lemon_attribute_name' => $desc->lemon_attribute->name ?? null
                    'lemon_attribute_name' => $desc->lemon_attribute->name ?? null
                ]
            ]);
            $this->viewBuilder()->disableAutoLayout();
            $this->viewBuilder()->setOption('serialize', ['success', 'rowHtml', 'row']);
            return $this->render('ajax_add_form');
        }

        // Validation failed
        $this->set([
            'success' => false,
            'message' => __('Validation failed'),
        ]);
        $this->viewBuilder()->disableAutoLayout();
        $this->viewBuilder()->setOption('serialize', ['success', 'message']);
        return $this->render('ajax_add_form');
    }

    throw new \Cake\Http\Exception\MethodNotAllowedException();
}



    /**
     * Edit method
     *
     * @param string|null $id Linguistic Description id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $linguisticDescription = $this->LinguisticDescriptions->get($id, contain: []);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $linguisticDescription = $this->LinguisticDescriptions->patchEntity($linguisticDescription, $this->request->getData());
            if ($this->LinguisticDescriptions->save($linguisticDescription)) {
                $this->Flash->success(__('The linguistic description has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The linguistic description could not be saved. Please, try again.'));
        }
        $lexicalEntries = $this->LinguisticDescriptions->LexicalEntries->find('list', limit: 200)->all();
        $senses = $this->LinguisticDescriptions->Senses->find('list', limit: 200)->all();
        $forms = $this->LinguisticDescriptions->Forms->find('list', limit: 200)->all();
        $lemonAttributes = $this->LinguisticDescriptions->LemonAttributes->find('list', limit: 200)->all();
        $this->set(compact('linguisticDescription', 'lexicalEntries', 'senses', 'forms', 'lemonAttributes'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Linguistic Description id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $linguisticDescription = $this->LinguisticDescriptions->get($id);
        if ($this->LinguisticDescriptions->delete($linguisticDescription)) {
            $this->Flash->success(__('The linguistic description has been deleted.'));
        } else {
            $this->Flash->error(__('The linguistic description could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
   
}
