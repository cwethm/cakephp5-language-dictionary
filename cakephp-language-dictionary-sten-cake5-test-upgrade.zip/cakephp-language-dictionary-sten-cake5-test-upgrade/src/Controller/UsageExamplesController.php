<?php
declare(strict_types=1);

namespace LanguageDictionary\Controller;

use LanguageDictionary\Controller\AppController;

/**
 * UsageExamples Controller
 *
 * @property \LanguageDictionary\Model\Table\UsageExamplesTable $UsageExamples
 */
class UsageExamplesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $query = $this->UsageExamples->find()
            ->contain(['Senses', 'Languages']);
        $usageExamples = $this->paginate($query);

        $this->set(compact('usageExamples'));
    }

    /**
     * View method
     *
     * @param string|null $id Usage Example id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $usageExample = $this->UsageExamples->get($id, contain: ['Senses', 'Languages']);
        $this->set(compact('usageExample'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $usageExample = $this->UsageExamples->newEmptyEntity();
        if ($this->request->is('post')) {
            $usageExample = $this->UsageExamples->patchEntity($usageExample, $this->request->getData());
            if ($this->UsageExamples->save($usageExample)) {
                $this->Flash->success(__('The usage example has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The usage example could not be saved. Please, try again.'));
        }
        $senses = $this->UsageExamples->Senses->find('list', limit: 200)->all();
        $languages = $this->UsageExamples->Languages->find('list', limit: 200)->all();
        $this->set(compact('usageExample', 'senses', 'languages'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Usage Example id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $usageExample = $this->UsageExamples->get($id, contain: []);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $usageExample = $this->UsageExamples->patchEntity($usageExample, $this->request->getData());
            if ($this->UsageExamples->save($usageExample)) {
                $this->Flash->success(__('The usage example has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The usage example could not be saved. Please, try again.'));
        }
        $senses = $this->UsageExamples->Senses->find('list', limit: 200)->all();
        $languages = $this->UsageExamples->Languages->find('list', limit: 200)->all();
        $this->set(compact('usageExample', 'senses', 'languages'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Usage Example id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $usageExample = $this->UsageExamples->get($id);
        if ($this->UsageExamples->delete($usageExample)) {
            $this->Flash->success(__('The usage example has been deleted.'));
        } else {
            $this->Flash->error(__('The usage example could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
