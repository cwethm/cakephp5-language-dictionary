<?php
declare(strict_types=1);

namespace LanguageDictionary\Controller;

use App\Controller\AppController as BaseAppController;

class AppController extends BaseAppController
{
    // 🍋 Plugin-wide controller logic can go here later.
}
