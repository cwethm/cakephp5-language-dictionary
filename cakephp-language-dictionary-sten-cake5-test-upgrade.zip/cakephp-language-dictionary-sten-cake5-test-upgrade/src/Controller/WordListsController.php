<?php
declare(strict_types=1);

namespace LanguageDictionary\Controller;

use LanguageDictionary\Controller\AppController;

/**
 * WordLists Controller
 *
 * @property \LanguageDictionary\Model\Table\WordListsTable $WordLists
 */
class WordListsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $query = $this->WordLists->find()
            ->contain(['Users']);
        $wordLists = $this->paginate($query);

        $this->set(compact('wordLists'));
    }

    /**
     * View method
     *
     * @param string|null $id Word List id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $wordList = $this->WordLists->get($id, contain: ['Users', 'LexicalEntries']);
        $this->set(compact('wordList'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $wordList = $this->WordLists->newEmptyEntity();
        if ($this->request->is('post')) {
            $wordList = $this->WordLists->patchEntity($wordList, $this->request->getData());
            if ($this->WordLists->save($wordList)) {
                $this->Flash->success(__('The word list has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The word list could not be saved. Please, try again.'));
        }
        $users = $this->WordLists->Users->find('list', limit: 200)->all();
        $lexicalEntries = $this->WordLists->LexicalEntries->find('list', limit: 200)->all();
        $this->set(compact('wordList', 'users', 'lexicalEntries'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Word List id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $wordList = $this->WordLists->get($id, contain: ['LexicalEntries']);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $wordList = $this->WordLists->patchEntity($wordList, $this->request->getData());
            if ($this->WordLists->save($wordList)) {
                $this->Flash->success(__('The word list has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The word list could not be saved. Please, try again.'));
        }
        $users = $this->WordLists->Users->find('list', limit: 200)->all();
        $lexicalEntries = $this->WordLists->LexicalEntries->find('list', limit: 200)->all();
        $this->set(compact('wordList', 'users', 'lexicalEntries'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Word List id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $wordList = $this->WordLists->get($id);
        if ($this->WordLists->delete($wordList)) {
            $this->Flash->success(__('The word list has been deleted.'));
        } else {
            $this->Flash->error(__('The word list could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
