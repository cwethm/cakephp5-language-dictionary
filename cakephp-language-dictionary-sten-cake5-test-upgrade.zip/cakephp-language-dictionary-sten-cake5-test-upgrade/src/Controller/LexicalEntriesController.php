<?php
declare(strict_types=1);

namespace LanguageDictionary\Controller;

use LanguageDictionary\Controller\AppController;
use LemonTools\Service\AssetFetcherService;
use DigitalAssetManager\Controller\Component\Traits\AttachmentDetachTrait;
use LemonTools\Controller\Component\PluginComponentLoaderTrait;
use LanguageDictionary\Service\LexicalEntrySearchService;
use Cake\Core\Configure;

/**
 * LexicalEntries Controller
 *
 * @property \LanguageDictionary\Model\Table\LexicalEntriesTable $LexicalEntries
 */
class LexicalEntriesController extends AppController
{
    use AttachmentDetachTrait;
    use PluginComponentLoaderTrait;

    protected function getDefaultSearchOptions(): array
    {
        return [
            'search_q' => '',
            'search_ai' => '',
            'search_type' => 'full',
            'language_id' => 3,
            'deleted_view' => '',
            'media_option' => 'all',
            'search_part_of_speech' => 'all',
            'search_modified_by' => [],
            'search_modified_after' => '',
            'search_modified_before' => '',
            'search_created_after' => '',
            'search_created_before' => '',
        ];
    }

    public function initialize(): void
    {
            parent::initialize();
        
    }
//     public function index()
//     {
//         $this->viewBuilder()->addHelper('LemonTools.DataTable');
//         $query = $this->LexicalEntries->find()
//             ->contain(['Languages', 'Users']);
//         $lexicalEntries = $this->paginate($query);
//         $presentationConfig = Configure::read('TableDefinitions.LexicalEntriesTable') ??
//             include CONFIG . 'TableDefinitions/LexicalEntriesTable.php';
// $this->LexicalEntries->find('searchWords', [...options array...])

//         $this->set(compact('lexicalEntries', 'presentationConfig'));
//     } 

// public function index()
// {
//     $this->viewBuilder()->addHelper('LemonTools.DataTable');    
//     // Merge default options + request data
//     $defaultOptions = $this->getDefaultSearchOptions();
//     $requestData = $this->getRequest()->getData();

//     // Normalize array values that may come as '' instead of []
//     if (!empty($requestData['search_modified_by']) && is_string($requestData['search_modified_by'])) {
//         $requestData['search_modified_by'] = (array)$requestData['search_modified_by'];
//     }

//     $searchOptions = array_merge($defaultOptions, $requestData);

//     // If search_q is present but search_ai is not, normalize
//     if (empty($searchOptions['search_ai']) && !empty($searchOptions['search_q'])) {
//         // Example — call a normalization method (or Entity method)
//         $searchOptions['search_ai'] = $this->normalizeSearchAI($searchOptions['search_q']);
//     }

//     // Perform search via service
//     $searchService = new LexicalEntrySearchService();
//     $query = $searchService->search($searchOptions);

//     // Paginate results
//     $this->paginate = [
//         'limit' => 20,
//         'order' => ['LexicalEntries.modified' => 'DESC'],
//     ];
//     $lexicalEntries = $this->paginate($query);

//     $presentationConfig = Configure::read('TableDefinitions.LexicalEntriesTable') ??
//         include CONFIG . 'TableDefinitions/LexicalEntriesTable.php';

//     // Supply user options for Modified By multi-select
//     $userOptions = $this->LexicalEntries->Users->find('list')->toArray();

//     // Pass to view
//     $this->set(compact('lexicalEntries', 'searchOptions', 'userOptions', 'presentationConfig'));
// }

// public function index()
// {
//     $this->viewBuilder()->addHelper('LemonTools.DataTable');

//     $defaultOptions = $this->getDefaultSearchOptions();
//     $requestData = $this->getRequest()->getData();

//     if (!empty($requestData['search_modified_by']) && is_string($requestData['search_modified_by'])) {
//         $requestData['search_modified_by'] = (array)$requestData['search_modified_by'];
//     }

//     $searchOptions = array_merge($defaultOptions, $requestData);

//     // Normalize search fields
//     $searchOptions['search_q'] = trim($searchOptions['search_q'] ?? '');
//     $searchOptions['search_ai'] = trim($searchOptions['search_ai'] ?? '');

//     if (empty($searchOptions['search_ai']) && !empty($searchOptions['search_q'])) {
//         $searchOptions['search_ai'] = $this->normalizeSearchAI($searchOptions['search_q']);
//     }

//     // Use service (in future → consider injecting via initialize)
//     $searchService = new LexicalEntrySearchService();
//     $query = $searchService->search($searchOptions);

//     // Sync pagination with search options
//     $this->paginate = [
//         'limit' => $searchOptions['limit'] ?? 20,
//         'order' => [$searchOptions['sort'] ?? 'LexicalEntries.modified' => $searchOptions['direction'] ?? 'DESC'],
//     ];
//     $lexicalEntries = $this->paginate($query);

//     $presentationConfig = Configure::read('TableDefinitions.LexicalEntriesTable')
//         ?? include CONFIG . 'TableDefinitions/LexicalEntriesTable.php';

//     $userOptions = $this->LexicalEntries->Users->find('list')->toArray();

//     $this->set(compact('lexicalEntries', 'searchOptions', 'userOptions', 'presentationConfig'));
// }

public function index()
{
    $this->set('context_domain', 'form'); // ✅ valid

    $this->viewBuilder()->addHelper('LemonTools.DataTable');

    // Merge options
    $defaultOptions = $this->getDefaultSearchOptions();
    $requestData = $this->getRequest()->getData();
    $requestGetData = $this->request->getQueryParams();

    if (!empty($requestData['search_modified_by']) && is_string($requestData['search_modified_by'])) {
        $requestData['search_modified_by'] = (array)$requestData['search_modified_by'];
    }

    $searchOptions = array_merge($defaultOptions, $requestData, $requestGetData);

    if (empty($searchOptions['search_ai']) && !empty($searchOptions['search_q'])) {
        $searchOptions['search_ai'] = $this->normalizeSearchAI($searchOptions['search_q']);
    }

    $searchService = new LexicalEntrySearchService();
    $query = $searchService->search($searchOptions);

    // Paginate
    $this->paginate = [
        'limit' => $searchOptions['limit'] ?? 20,
        'order' => [
            $searchOptions['sort'] ?? 'LexicalEntries.modified' => strtoupper($searchOptions['direction'] ?? 'DESC')
        ],
    ];
    $lexicalEntries = $this->paginate($query);

    $presentationConfig = Configure::read('TableDefinitions.LexicalEntriesTable') ??
        include CONFIG . 'TableDefinitions/LexicalEntriesTable.php';

    $userOptions = $this->LexicalEntries->Users->find('list')->toArray();

    // If AJAX / JSON requested → return JSON
    if ($this->request->is('ajax') || $this->request->is('json')) {
        $this->viewBuilder()->setClassName('Json');
        $this->set([
            'data' => $lexicalEntries,
            'pagination' => $this->request->getAttribute('paging')['LexicalEntries'],
            'searchOptions' => $searchOptions,
            '_serialize' => ['data', 'pagination', 'searchOptions'],
        ]);
        return;
    }

    // Else → normal HTML view
    $this->set(compact('lexicalEntries', 'searchOptions', 'userOptions', 'presentationConfig'));
}

    /**
     * View method
     *[
            'contain' => ['Dictionaries', 'Senses','Senses.ClassificationCategories', 'LinguisticDescriptions', 'LinguisticDescriptions.LemonAttributes', 'Senses.LinguisticDescriptions', 'Senses.LinguisticDescriptions.LemonAttributes', 'CanonicalForm', 'CanonicalForm.LinguisticDescriptions', 'CanonicalForm.LinguisticDescriptions.LemonAttributes','TranslateableAsForm.LinguisticDescriptions', 'TranslateableAsForm.LinguisticDescriptions.LemonAttributes', 
        'Forms', 
        'Forms.Languages', 'Forms.LinguisticDescriptions', 'Forms.LinguisticDescriptions.LemonAttributes','Senses.CoverImg','Senses.CoverImg.ImageAssets','Senses.CoverSound','Senses.CoverSound.MediaAssets','Assets','Assets.MediaAssets','Assets.ImageAssets','Images','Images.ImageAssets','Sounds','Sounds.MediaAssets', 'SampleSentences', 'SampleSentences.Sounds'],
        ]

     * @param string|null $id Lexical Entry id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $lexicalEntry = $this->LexicalEntries->get($id, contain: ['Dictionaries', 'WordLists', 'Senses', 'Senses.ClassificationCategories', 'Attachments.Assets']);


        $assets = $this->LexicalEntries->getAttachedAssets($lexicalEntry);
        $this->set(compact('lexicalEntry','assets'));
    }
    public function viewModal(int $id)
    {
        $this->request->allowMethod(['get']);
        $this->viewBuilder()->disableAutoLayout();
        $entry = $this->LexicalEntries->get($id, [
            'contain' => ['CanonicalForm','Senses.CoverImageAsset.MediaAsset', 'Senses.CoverSoundAsset.MediaAsset']
        ]);
        $sense = $this->LexicalEntries->Senses->findByLexicalEntryId($id)->contain([
            'UsageExamples', 
            'LinguisticDescriptions',
            'CoverImageAsset' => [
                    'MediaAsset'
                ],
                'CoverSoundAsset' => [
                    'MediaAsset'
                ]])->first();
        $this->viewBuilder()->setLayout('ajax');
        $this->set(compact('entry', 'sense'));        
        $this->render('view_modal');
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $lexicalEntry = $this->LexicalEntries->newEmptyEntity();
        if ($this->request->is('post')) {
            $lexicalEntry = $this->LexicalEntries->patchEntity($lexicalEntry, $this->request->getData());
            if ($this->LexicalEntries->save($lexicalEntry)) {
                $this->Flash->success(__('The lexical entry has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The lexical entry could not be saved. Please, try again.'));
        }
        $languages = $this->LexicalEntries->Languages->find('list', limit: 200)->all();
        $users = $this->LexicalEntries->Users->find('list', limit: 200)->all();
        $dictionaries = $this->LexicalEntries->Dictionaries->find('list', limit: 200)->all();
        $wordLists = $this->LexicalEntries->WordLists->find('list', limit: 200)->all();
        $this->set(compact('lexicalEntry', 'languages', 'users', 'dictionaries', 'wordLists'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Lexical Entry id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    // public function edit($id = null)
    // {
    //     $this->set('context_domain', 'form');
    // $linguisticDescriptionsPresentationConfig = Configure::read('TableDefinitions.LinguisticDescriptionsTable') ??
    //     // Dynamically limit LemonAttributes to the relevant context model (e.g., 'Form')
    //     $contextModel = $this->request->getQuery('context_model') ?? 'Form';

    //     $lemonAttributes = $this->fetchTable('LanguageDictionary.LemonAttributes')
    //         ->find('list', ['keyField' => 'id', 'valueField' => 'local_name'])
    //         ->where(['model_class' => $contextModel])
    //         ->toArray();

    //     include CONFIG . 'TableDefinitions/LinguisticDescriptionsTable.php';
    //     $contain = [
    //         'Dictionaries',
    //         'WordLists',
    //         'Senses' => [
    //             'CoverImageAsset' => ['MediaAsset'],
    //             'CoverSoundAsset' => ['MediaAsset'],
    //             'ClassificationCategories',
    //             'UsageExamples.Recordings'
    //         ],
    //         'Forms' => [
    //             'LinguisticDescriptions' => ['LemonAttributes']
    //         ],
    //         'CanonicalForm' => [
    //             'LinguisticDescriptions' => ['LemonAttributes'],
    //             'Languages'
    //         ],
    //         'Attachments.Assets.MediaAsset',
    //         'ImageAssets',
    //         'SoundAssets'
    //     ];
    //     $lexicalEntry = $this->LexicalEntries->get($id, contain: $contain );
    //     if ($this->request->is(['patch', 'post', 'put'])) {
    //         $lexicalEntry = $this->LexicalEntries->patchEntity($lexicalEntry, $this->request->getData());
    //         if ($this->LexicalEntries->save($lexicalEntry)) {
    //             $this->Flash->success(__('The lexical entry has been saved.'));

    //             return $this->redirect(['action' => 'index']);
    //         }
    //         $this->Flash->error(__('The lexical entry could not be saved. Please, try again.'));
    //     } 
    //     $selectedCategoryIds = [];

    //     if (!empty($lexicalEntry->senses) && !empty($lexicalEntry->senses[0]->classification_categories)) {
    //         foreach ($lexicalEntry->senses[0]->classification_categories as $category) {
    //             $selectedCategoryIds[] = $category->id;
    //         }
    //     }
        
    //     // 🍋 Fetch attached assets using AssetFetcherService
    //     $assetFetcher = new AssetFetcherService();
    //     $mediaAssets = $assetFetcher->fetch($lexicalEntry); // flat list
    //     $coverMediaOptions = $assetFetcher->fetch($lexicalEntry, 'asset_type_id'); // ✅ Corrected here

    //     $availableCoverImages = $coverMediaOptions[6] ?? [];
    //     $availableCoverSounds = $coverMediaOptions[4] ?? [];


    //     // Fetch categories tree
    //     $classificationCategoriesTable = $this->fetchTable('LanguageDictionary.ClassificationCategories');
    //     $categories = $classificationCategoriesTable
    //         ->find('threaded', [
    //             'keyField' => 'id',
    //             'parentField' => 'parent_id',
    //         ])
    //         ->where([
    //             'ClassificationCategories.name IS NOT' => null,
    //             'ClassificationCategories.name !=' => '',
    //         ])
    //         ->contain([
    //             'ParentClassificationCategories',
    //             'ChildClassificationCategories',
    //             'Senses',
    //         ])
    //         ->toArray();
    //         $senses = $lexicalEntry->senses;
    //         $languages = $this->LexicalEntries->Languages->find('list', limit: 200)->all();
    //         $users = $this->LexicalEntries->Users->find('list', limit: 200)->all();
    //         $dictionaries = $this->LexicalEntries->Dictionaries->find('list', limit: 200)->all();
    //         $wordLists = $this->LexicalEntries->WordLists->find('list', limit: 200)->all();

    //     $linguisticDescriptionsPresentationConfig = Configure::read('TableDefinitions.LinguisticDescriptionsTable') ??
    //         include CONFIG . 'TableDefinitions/LinguisticDescriptionsTable.php';

    //     // Configure the LinguisticDescriptions table
    //     $presentationConfig = [
    //         'tableId' => 'linguisticDescriptionsTable',
    //         'dataTableName' => 'LinguisticDescriptions',
    //         'model' => 'LinguisticDescriptions',
    //         'context_model' => 'LinguisticDescriptions',
    //         'context_domain' => 'Form',
    //         'plugin' => 'LanguageDictionary',
    //         'columns' => [
    //             'id' => ['label' => 'ID', 'visible' => false],
    //             'lemon_attribute.name' => [
    //                 'label' => 'LemonAttributes Type',
    //                 'formatter' => 'semanticBadge',
    //                 'rdf:type' => 'lemon:descriptionType', // RDFa integration
    //                 'formatter' => function ($entity) {
    //                     return $entity->lemon_attribute->name ?? $entity->lemon_attribute_id;
    //                 },
    //             ],
    //             'value' => [
    //                 'label' => 'Value',
    //                 'searchable' => true,
    //                 'formatter' => 'rdfLiteral', // Handles RDF literals with language tags
    //             ],
    //             'language.name' => [
    //                 'label' => 'Language',
    //                 'formatter' => 'languageTag', // Displays as ISO 639-3 badge
    //             ],
    //         ],
    //         'rowActions' => [
    //             'edit' => [
    //                 'useModalEdit' => true,
    //                 'url' => ['controller' => 'LinguisticDescriptions', 'action' => 'edit', ':id'],
    //                 'icon' => 'pencil',
    //                 'class' => 'btn btn-sm  btn-outline-primary',
    //             ],
    //             'delete' => [
    //                 'url' => ['controller' => 'LinguisticDescriptions', 'action' => 'delete', ':id'],
    //                 'icon' => 'trash',
    //                 'class' => 'btn btn-sm  btn-outline-danger',
    //                 'confirm' => 'Delete this description?', 
    //             ],
    //         ],
    //         'bulkActions' => [
    //             'delete' => [
    //                 'url' => ['controller' => 'LinguisticDescriptions', 'action' => 'deleteMultiple'],
    //                 'label' => 'Delete Selected',
    //                 'icon' => 'trash',
    //                 'class' => 'btn-danger',
    //             ],
    //         ],
    //     ];

    //     $this->set(compact('lexicalEntry', 'lemonAttributes', 'contextModel'));
    //     $this->set(compact('lexicalEntry', 'languages', 'senses', 'users', 'dictionaries', 'wordLists', 'mediaAssets', 'availableCoverImages', 'availableCoverSounds', 'categories', 'selectedCategoryIds', 'presentationConfig', 'linguisticDescriptionsPresentationConfig'));
    // }

    public function edit($id = null)
    {
        $context_domain = 'form';
        // Merge options
        $defaultOptions = $this->getDefaultSearchOptions();
        // $requestData = $this->getRequest()->getData();
        $requestData = $this->request->getQueryParams();

        if (!empty($requestData['search_modified_by']) && is_string($requestData['search_modified_by'])) {
            $requestData['search_modified_by'] = (array)$requestData['search_modified_by'];
        }

        $searchOptions = array_merge($defaultOptions, $requestData);
 
        $this->set( compact('context_domain','searchOptions'));

        $contextModel = $this->request->getQuery('context_model') ?? 'Form';

        // Load presentation config for LinguisticDescriptions (from Configure or fallback include)
        $linguisticDescriptionsPresentationConfig = Configure::read('TableDefinitions.LinguisticDescriptionsTable');
        if (!$linguisticDescriptionsPresentationConfig) {
            $linguisticDescriptionsPresentationConfig = include CONFIG . 'TableDefinitions/LinguisticDescriptionsTable.php';
        }

        // Fetch relevant LemonAttributes
        $lemonAttributes = $this->fetchTable('LanguageDictionary.LemonAttributes')
            ->find('list', ['keyField' => 'id', 'valueField' => 'local_name'])
            ->where(['model_class' => $contextModel])
            ->toArray();

        // Setup containment
        $contain = [
            'Dictionaries',
            'WordLists',
            'Senses' => [
                'CoverImageAsset' => ['MediaAsset'],
                'CoverSoundAsset' => ['MediaAsset'],
                'ClassificationCategories',
                'UsageExamples.Recordings'
            ],
            'Forms' => [
                'LinguisticDescriptions' => ['LemonAttributes' => ['LemonAttributeLabels','LemonAttributeDomains','LemonAttributeRanges','LemonAttributeRelations','LemonAttributeEnumerations'], 'Languages'] ,
                'Languages'
            ],
            'CanonicalForm' => [
                'LinguisticDescriptions' => ['LemonAttributes', 'Languages'],
                'Languages'
            ],
            'Attachments.Assets.MediaAsset',
            'ImageAssets',
            'SoundAssets'
        ];

        $lexicalEntry = $this->LexicalEntries->get($id, contain: $contain);
        $formsData = $lexicalEntry->forms;

        if ($this->request->is(['patch', 'post', 'put'])) {
            $lexicalEntry = $this->LexicalEntries->patchEntity($lexicalEntry, $this->request->getData());
            if ($this->LexicalEntries->save($lexicalEntry)) {
                $this->Flash->success(__('The lexical entry has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The lexical entry could not be saved. Please, try again.'));
        }

        // Build list of pre-selected category IDs
        $selectedCategoryIds = [];
        if (!empty($lexicalEntry->senses[0]?->classification_categories)) {
            foreach ($lexicalEntry->senses[0]->classification_categories as $category) {
                $selectedCategoryIds[] = $category->id;
            }
        }

        // 🍋 Fetch attached assets using AssetFetcherService
        $assetFetcher = new AssetFetcherService();
        $mediaAssets = $assetFetcher->fetch($lexicalEntry); // flat list
        $coverMediaOptions = $assetFetcher->fetch($lexicalEntry, 'asset_type_id');
        $availableCoverImages = $coverMediaOptions[6] ?? [];
        $availableCoverSounds = $coverMediaOptions[4] ?? [];

        // Fetch category tree
        $classificationCategoriesTable = $this->fetchTable('LanguageDictionary.ClassificationCategories');
        $categories = $classificationCategoriesTable
            ->find('threaded', [
                'keyField' => 'id',
                'parentField' => 'parent_id',
            ])
            ->where([
                'ClassificationCategories.name IS NOT' => null,
                'ClassificationCategories.name !=' => '',
            ])
            ->contain([
                'ParentClassificationCategories',
                'ChildClassificationCategories',
                'Senses',
            ])
            ->toArray();

        // Load dropdowns
        $senses = $lexicalEntry->senses;
        $languages = $this->LexicalEntries->Languages->find('list', limit: 200)->all();
        $users = $this->LexicalEntries->Users->find('list', limit: 200)->all();
        $dictionaries = $this->LexicalEntries->Dictionaries->find('list', limit: 200)->all();
        $wordLists = $this->LexicalEntries->WordLists->find('list', limit: 200)->all();

        // $presentationConfig = [
        //     'tableId' => 'linguisticDescriptionsTable',
        //     'dataTableName' => 'LinguisticDescriptions',
        //     'model' => 'LinguisticDescriptions',
        //     'context_model' => 'LinguisticDescriptions',
        //     'context_domain' => 'Form',
        //     'plugin' => 'LanguageDictionary',
        //     'columns' => [
        //         'id' => ['label' => 'ID', 'visible' => false],
        //         'sense_id' => ['label' => 'sense id', 'visible' => false],
        //         'form_id' => ['label' => 'form id', 'visible' => false],
        //         'lemon_attribute.name' => [
        //             'label' => 'Lemon Class',
        //             'formatter' => 'semanticBadge',
        //             'rdf:type' => 'lemon:descriptionType',
        //             'formatter' => function ($entity) {
        //                 return $entity->lemon_attribute->name ?? $entity->lemon_attribute_id;
        //             },
        //         ],
        //         'value' => [
        //             'label' => 'Value',
        //             'searchable' => true,
        //             'formatter' => 'rdfLiteral',
        //         ],
        //         'language.name' => [
        //             'label' => 'Language',
        //             'formatter' => 'languageTag',
        //             'formatter' => function ($entity) {
        //                 return $entity->languages[0]->name ?? $entity->language_id;
        //             },
        //         ],
        //     ],
        //     'rowActions' => [
        //         'edit' => [
        //             'useModalEdit' => true,
        //             'url' => ['controller' => 'LinguisticDescriptions', 'action' => 'edit', ':id'],
        //             'icon' => 'pencil',
        //             'class' => 'btn btn-sm btn-outline-primary',
        //         ],
        //         'delete' => [
        //             'url' => ['controller' => 'LinguisticDescriptions', 'action' => 'delete', ':id'],
        //             'icon' => 'trash',
        //             'class' => 'btn btn-sm btn-outline-danger',
        //             'confirm' => 'Delete this description?',
        //         ],
        //     ],
        //     'bulkActions' => [
        //         'delete' => [
        //             'url' => ['controller' => 'LinguisticDescriptions', 'action' => 'deleteMultiple'],
        //             'label' => 'Delete Selected',
        //             'icon' => 'trash',
        //             'class' => 'btn-danger',
        //         ],
        //     ],
        // ];

        $presentationConfig = Configure::read('TableDefinitions.LexicalEntriesTable') ??
            include CONFIG . 'TableDefinitions/LexicalEntriesTable.php';

        $this->set(compact(
            'lexicalEntry',
            'formsData',
            'lemonAttributes',
            'contextModel',
            'languages',
            'senses',
            'users',
            'dictionaries',
            'wordLists',
            'mediaAssets',
            'availableCoverImages',
            'availableCoverSounds',
            'categories',
            'selectedCategoryIds',
            'presentationConfig',
            'linguisticDescriptionsPresentationConfig'
        ));
    }

    /**
     * Delete method
     *
     * @param string|null $id Lexical Entry id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
    //  */
    // public function delete($id = null)
    // {
    //     $this->request->allowMethod(['post', 'delete']);
    //     $this->autoRender = false; // We are returning JSON only

    //     $success = 'deleted';
    //     $failed = 'did not delete properly';

    //     $entity = $this->LexicalEntries->get($id);
    //     if ($this->LexicalEntries->delete($entity)) {
    //         $success[] = $id;
    //     } else {
    //         $failed[] = $id;
    //     }
    //     if (empty($id)) {
    //         $this->response = $this->response->withStatus(400);
    //         echo json_encode(['error' => 'Invalid or missing ID']);
    //         return;
    //     }
    //     $this->response = $this->response->withType('application/json');
    //     echo json_encode(compact('success', 'failed'));
    // }
    // public function delete($id = null)
    // {
    //     $this->request->allowMethod(['post', 'delete']);
    //     $this->autoRender = false; // We are returning JSON only
    //     $this->viewBuilder()->disableAutoLayout();

    //     // Set JSON response type
    //     $this->response = $this->response->withType('application/json');

    //     $success = '';
    //     $failed = '';
    //     $error = '';
    //     if (empty($id)) {
    //         $this->response = $this->response->withStatus(400);
    //         $this->set(['error' => 'Invalid or missing ID']);
    //         $this->viewBuilder()->setOption('serialize', ['error']);
    //         return;
    //     }

    //     try {
    //         $entity = $this->LexicalEntries->get($id);
    //         if ($this->LexicalEntries->delete($entity)) {
    //             $success = $id;
    //         } else {
    //             $failed = $id;
    //         }
    //     } catch (\Exception $e) {
    //         $failed = $id;
    //     }
    //     $this->response = $this->response->withType('application/json');
    //     $this->set(compact('success', 'failed'));
    //     $this->viewBuilder()->setOption('serialize', ['success', 'failed']);

    // }
    // public function delete($id = null)
    // {
    //     $this->request->allowMethod(['post', 'delete']);

    //     $success = '';
    //     $failed = '';
    //     $error = '';

    //     if (!$id) {
    //         $this->response = $this->response->withStatus(400);
    //         $this->set(['error' => 'Invalid or missing ID']);
    //         $this->viewBuilder()->setOption('serialize', ['error']);
    //         return;
    //     }

    //     try {
    //         $entity = $this->LexicalEntries->get($id);
    //         if ($this->LexicalEntries->delete($entity)) {
    //             $success = $id;
    //         } else {
    //             $failed = $id;
    //         }
    //     } catch (\Exception $e) {
    //         $failed = $id;
    //     }
    //     $this->response = $this->response->withType('application/json');
    //     $this->viewBuilder()->disableAutoLayout();
    //     $this->set([
    //         'success' => $success ? true : false,
    //         'id' => $success ?: null,
    //         'error' => $failed ? 'Delete failed' : null,
    //     ]);
    //     $this->viewBuilder()->setOption('serialize', ['success', 'id', 'error']);
    // }

// public function delete($id = null)
// {
//     $this->request->allowMethod(['post', 'delete']);
//     $this->viewBuilder()->disableAutoLayout();
//     $this->response = $this->response->withType('application/json');

//     $success = false;
//     $error = null;

//     if (!$id) {
//         $this->response = $this->response->withStatus(400);
//         $error = 'Invalid or missing ID';
//     } else {
//         try {
//             $entity = $this->LexicalEntries->get($id);
//             if ($this->LexicalEntries->delete($entity)) {
//                 $success = true;
//             } else {
//                 $error = 'Failed to delete entry';
//             }
//         } catch (\Exception $e) {
//             $error = $e->getMessage();
//         }
//     }

//     $this->set(compact('success', 'error'));
//     $this->viewBuilder()->setOption('serialize', ['success', 'error']);
// }
public function delete($id)
{
    $success = false;
    $error = null;
    $this->request->allowMethod(['post', 'delete']);
    $this->viewBuilder()->disableAutoLayout();
    $this->response = $this->response->withType('application/json');
    $entity = $this->LexicalEntries->get($id); // adjust table

    $success = $this->LexicalEntries->delete($entity);

    // If AJAX / JSON requested → return JSON
        $this->viewBuilder()->setClassName('Json');
        $this->set([
            'success' => $id,
            'error' => 'failed to delete properly',
        ]);
        $this->viewBuilder()->setOption('serialize', ['success', 'error']);
}

    public function addModal()
    {
        $this->request->allowMethod(['get']);
        $entity = $this->LexicalEntries->newEmptyEntity();
        $this->set(compact('entity'));
        $this->render('/LexicalEntries/modal_form', 'ajax');
    }

    public function editModal($id)
    {
        $this->request->allowMethod(['get']);
        $entity = $this->LexicalEntries->get($id);
        $this->set(compact('entity'));
        $this->render('/LexicalEntries/modal_form', 'ajax');
    }

    public function deleteMultiple()
    {
        $this->request->allowMethod(['post']);
        $this->autoRender = false; // We are returning JSON only

        $ids = $this->request->getData('ids');
        if (empty($ids) || !is_array($ids)) {
            $this->response = $this->response->withStatus(400);
            echo json_encode(['error' => 'Invalid or missing IDs']);
            return;
        }

        $success = [];
        $failed = [];

        foreach ($ids as $id) {
            try {
                $entity = $this->LexicalEntries->get($id);
                if ($this->LexicalEntries->delete($entity)) {
                    $success[] = $id;
                } else {
                    $failed[] = $id;
                }
            } catch (\Exception $e) {
                // Could not find or delete entity
                $failed[] = $id;
            }
        }

        $this->response = $this->response->withType('application/json');
        echo json_encode(compact('success', 'failed'));
    }
    protected function normalizeSearchAI(string $text): string
    {
        // Basic placeholder — use your Entity method if you prefer
        // Example: strip accents, trim, lowercase
        $text = mb_strtolower($text);
        $text = trim($text);
        // Here you would call your Entity's removeAccents() if available
        // For example:
        // $entity = $this->LexicalEntries->newEmptyEntity();
        // return $entity->removeAccents($text);

        // For now just return lowercased trimmed
        return $text;
    }


}
