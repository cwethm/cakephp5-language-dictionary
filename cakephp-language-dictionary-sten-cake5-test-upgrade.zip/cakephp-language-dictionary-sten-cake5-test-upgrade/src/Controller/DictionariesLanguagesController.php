<?php
declare(strict_types=1);

namespace LanguageDictionary\Controller;

use LanguageDictionary\Controller\AppController;

/**
 * DictionariesLanguages Controller
 *
 * @property \LanguageDictionary\Model\Table\DictionariesLanguagesTable $DictionariesLanguages
 */
class DictionariesLanguagesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $query = $this->DictionariesLanguages->find()
            ->contain(['Dictionaries', 'Languages']);
        $dictionariesLanguages = $this->paginate($query);

        $this->set(compact('dictionariesLanguages'));
    }

    /**
     * View method
     *
     * @param string|null $id Dictionaries Language id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $dictionariesLanguage = $this->DictionariesLanguages->get($id, contain: ['Dictionaries', 'Languages']);
        $this->set(compact('dictionariesLanguage'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $dictionariesLanguage = $this->DictionariesLanguages->newEmptyEntity();
        if ($this->request->is('post')) {
            $dictionariesLanguage = $this->DictionariesLanguages->patchEntity($dictionariesLanguage, $this->request->getData());
            if ($this->DictionariesLanguages->save($dictionariesLanguage)) {
                $this->Flash->success(__('The dictionaries language has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The dictionaries language could not be saved. Please, try again.'));
        }
        $dictionaries = $this->DictionariesLanguages->Dictionaries->find('list', limit: 200)->all();
        $languages = $this->DictionariesLanguages->Languages->find('list', limit: 200)->all();
        $this->set(compact('dictionariesLanguage', 'dictionaries', 'languages'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Dictionaries Language id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $dictionariesLanguage = $this->DictionariesLanguages->get($id, contain: []);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $dictionariesLanguage = $this->DictionariesLanguages->patchEntity($dictionariesLanguage, $this->request->getData());
            if ($this->DictionariesLanguages->save($dictionariesLanguage)) {
                $this->Flash->success(__('The dictionaries language has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The dictionaries language could not be saved. Please, try again.'));
        }
        $dictionaries = $this->DictionariesLanguages->Dictionaries->find('list', limit: 200)->all();
        $languages = $this->DictionariesLanguages->Languages->find('list', limit: 200)->all();
        $this->set(compact('dictionariesLanguage', 'dictionaries', 'languages'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Dictionaries Language id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $dictionariesLanguage = $this->DictionariesLanguages->get($id);
        if ($this->DictionariesLanguages->delete($dictionariesLanguage)) {
            $this->Flash->success(__('The dictionaries language has been deleted.'));
        } else {
            $this->Flash->error(__('The dictionaries language could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
