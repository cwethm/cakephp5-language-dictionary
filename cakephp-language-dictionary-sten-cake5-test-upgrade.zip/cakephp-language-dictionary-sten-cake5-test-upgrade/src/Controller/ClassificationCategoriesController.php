<?php
declare(strict_types=1);

namespace LanguageDictionary\Controller;

use LanguageDictionary\Controller\AppController;

/**
 * ClassificationCategories Controller
 *
 * @property \LanguageDictionary\Model\Table\ClassificationCategoriesTable $ClassificationCategories
 */
class ClassificationCategoriesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $query = $this->ClassificationCategories->find()
            ->contain(['ParentClassificationCategories']);
        $classificationCategories = $this->paginate($query);

        $this->set(compact('classificationCategories'));
    }

    /**
     * View method
     *
     * @param string|null $id Classification Category id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $classificationCategory = $this->ClassificationCategories->get($id, contain: ['ParentClassificationCategories', 'Senses', 'ChildClassificationCategories']);
        $this->set(compact('classificationCategory'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $classificationCategory = $this->ClassificationCategories->newEmptyEntity();
        if ($this->request->is('post')) {
            $classificationCategory = $this->ClassificationCategories->patchEntity($classificationCategory, $this->request->getData());
            if ($this->ClassificationCategories->save($classificationCategory)) {
                $this->Flash->success(__('The classification category has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The classification category could not be saved. Please, try again.'));
        }
        $parentClassificationCategories = $this->ClassificationCategories->ParentClassificationCategories->find('list', limit: 200)->all();
        $senses = $this->ClassificationCategories->Senses->find('list', limit: 200)->all();
        $this->set(compact('classificationCategory', 'parentClassificationCategories', 'senses'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Classification Category id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $classificationCategory = $this->ClassificationCategories->get($id, contain: ['Senses']);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $classificationCategory = $this->ClassificationCategories->patchEntity($classificationCategory, $this->request->getData());
            if ($this->ClassificationCategories->save($classificationCategory)) {
                $this->Flash->success(__('The classification category has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The classification category could not be saved. Please, try again.'));
        }
        $parentClassificationCategories = $this->ClassificationCategories->ParentClassificationCategories->find('list', limit: 200)->all();
        $senses = $this->ClassificationCategories->Senses->find('list', limit: 200)->all();
        $this->set(compact('classificationCategory', 'parentClassificationCategories', 'senses'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Classification Category id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $classificationCategory = $this->ClassificationCategories->get($id);
        if ($this->ClassificationCategories->delete($classificationCategory)) {
            $this->Flash->success(__('The classification category has been deleted.'));
        } else {
            $this->Flash->error(__('The classification category could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
